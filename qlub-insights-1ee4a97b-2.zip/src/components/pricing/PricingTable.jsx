import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, AlertTriangle, CheckCircle, HelpCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function PricingTable({ pricingData, onEdit, isLoading }) {
  const getStatusColor = (status) => {
    switch(status) {
      case 'confirmed': return 'bg-green-100 text-green-800 border-green-200';
      case 'estimated': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'missing': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'confirmed': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'estimated': return <HelpCircle className="w-4 h-4 text-blue-600" />;
      case 'missing': return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      default: return null;
    }
  };

  const formatRate = (price) => {
    if (price.explicit_rate) return price.explicit_rate;
    if (price.placeholder_rate) return price.placeholder_rate;
    return 'Not disclosed';
  };

  const formatBenchmark = (price) => {
    if (price.currency === '%') {
      return `${price.uae_benchmark_min}-${price.uae_benchmark_max}%`;
    } else if (price.currency === 'AED') {
      return `AED ${price.uae_benchmark_min}-${price.uae_benchmark_max}`;
    }
    return `${price.uae_benchmark_min}-${price.uae_benchmark_max} ${price.currency}`;
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-3">
          Qlub Pricing Structure Analysis
        </CardTitle>
        <p className="text-slate-600">
          Comprehensive breakdown of fees, charges, and UAE market benchmarks
        </p>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead className="font-semibold">Fee Type</TableHead>
                <TableHead className="font-semibold">Qlub Rate</TableHead>
                <TableHead className="font-semibold">UAE Benchmark</TableHead>
                <TableHead className="font-semibold">Frequency</TableHead>
                <TableHead className="font-semibold">Status</TableHead>
                <TableHead className="font-semibold">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8" /></TableCell>
                  </TableRow>
                ))
              ) : (
                pricingData.map((price) => (
                  <TableRow key={price.id} className="hover:bg-slate-50">
                    <TableCell className="font-medium">
                      {price.fee_type}
                    </TableCell>
                    <TableCell>
                      <div className={price.status === 'missing' ? 'text-amber-600 font-medium' : ''}>
                        {formatRate(price)}
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-600">
                      {formatBenchmark(price)}
                    </TableCell>
                    <TableCell>
                      <span className="capitalize">{price.frequency}</span>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(price.status)}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(price.status)}
                          {price.status}
                        </div>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEdit(price)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {!isLoading && pricingData.length === 0 && (
          <div className="text-center py-12">
            <AlertTriangle className="w-12 h-12 mx-auto text-slate-400 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No pricing data available</h3>
            <p className="text-slate-600">Add pricing information to begin analysis</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}