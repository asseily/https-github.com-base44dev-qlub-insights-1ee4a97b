import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function BenchmarkComparison({ pricingData }) {
  const getComparisonStatus = (price) => {
    // Since Qlub rates are mostly missing, we can't make real comparisons
    // This is more of a market positioning analysis
    if (price.status === 'missing') return 'unknown';
    
    const midBenchmark = (price.uae_benchmark_min + price.uae_benchmark_max) / 2;
    // For estimated rates, we'd need to parse and compare, but for now return neutral
    return 'neutral';
  };

  const getComparisonIcon = (status) => {
    switch(status) {
      case 'above': return <TrendingUp className="w-4 h-4 text-red-500" />;
      case 'below': return <TrendingDown className="w-4 h-4 text-green-500" />;
      case 'neutral': return <Minus className="w-4 h-4 text-blue-500" />;
      default: return <Minus className="w-4 h-4 text-slate-400" />;
    }
  };

  const getComparisonColor = (status) => {
    switch(status) {
      case 'above': return 'text-red-600 bg-red-50';
      case 'below': return 'text-green-600 bg-green-50';
      case 'neutral': return 'text-blue-600 bg-blue-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl">UAE Market Benchmark Comparison</CardTitle>
        <p className="text-slate-600">
          How Qlub's pricing positions against UAE restaurant payment solutions market
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {pricingData.map((price) => {
            const status = getComparisonStatus(price);
            const progressValue = price.status === 'missing' ? 50 : 
                                 (price.uae_benchmark_min / price.uae_benchmark_max) * 100;
            
            return (
              <div key={price.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-slate-900">{price.fee_type}</h3>
                    <p className="text-sm text-slate-600">{price.frequency}</p>
                  </div>
                  <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${getComparisonColor(status)}`}>
                    {getComparisonIcon(status)}
                    <span className="text-sm font-medium">
                      {price.status === 'missing' ? 'No Data' : 'Market Rate'}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Market Range</span>
                    <span className="font-medium">
                      {price.currency === '%' ? 
                        `${price.uae_benchmark_min}-${price.uae_benchmark_max}%` :
                        `${price.currency} ${price.uae_benchmark_min}-${price.uae_benchmark_max}`
                      }
                    </span>
                  </div>
                  
                  <Progress 
                    value={progressValue} 
                    className="h-2"
                  />
                  
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500">Qlub Position</span>
                    <Badge variant={price.status === 'missing' ? 'destructive' : 'outline'}>
                      {price.status === 'missing' ? 'Not Disclosed' : 'Estimated'}
                    </Badge>
                  </div>
                </div>

                {price.status === 'missing' && (
                  <div className="mt-3 p-3 bg-amber-50 rounded-md">
                    <p className="text-sm text-amber-800">
                      <strong>Transparency Issue:</strong> Qlub does not publicly disclose this rate, 
                      making it difficult for restaurants to compare with competitors.
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-8 p-6 bg-blue-50 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Market Analysis Summary</h4>
          <div className="text-sm text-blue-800 space-y-2">
            <p>• <strong>Pricing Transparency Gap:</strong> Qlub's lack of public pricing creates barriers to adoption</p>
            <p>• <strong>Competitive Disadvantage:</strong> Prospects cannot easily compare against alternatives</p>
            <p>• <strong>Market Position:</strong> Likely positioned as premium solution based on feature set</p>
            <p>• <strong>Recommendation:</strong> Publish tiered pricing to improve market penetration</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}