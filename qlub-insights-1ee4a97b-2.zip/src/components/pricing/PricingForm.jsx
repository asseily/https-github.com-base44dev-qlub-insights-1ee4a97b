import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, XCircle } from "lucide-react";

export default function PricingForm({ price, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(price || {
    fee_type: '',
    explicit_rate: '',
    placeholder_rate: '',
    uae_benchmark_min: 0,
    uae_benchmark_max: 0,
    currency: 'AED',
    frequency: 'monthly',
    status: 'estimated'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl">
          {price ? 'Edit Pricing Data' : 'Add New Pricing Data'}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="fee_type">Fee Type</Label>
              <Input
                id="fee_type"
                value={formData.fee_type}
                onChange={(e) => setFormData(prev => ({...prev, fee_type: e.target.value}))}
                placeholder="e.g. Merchant Discount Rate"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => setFormData(prev => ({...prev, status: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="estimated">Estimated</SelectItem>
                  <SelectItem value="missing">Missing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="explicit_rate">Explicit Rate (if known)</Label>
              <Input
                id="explicit_rate"
                value={formData.explicit_rate}
                onChange={(e) => setFormData(prev => ({...prev, explicit_rate: e.target.value}))}
                placeholder="e.g. 2.5% or AED 200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="placeholder_rate">Placeholder/Estimated Rate</Label>
              <Input
                id="placeholder_rate"
                value={formData.placeholder_rate}
                onChange={(e) => setFormData(prev => ({...prev, placeholder_rate: e.target.value}))}
                placeholder="e.g. Estimated 2-3%"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="benchmark_min">UAE Benchmark Min</Label>
              <Input
                id="benchmark_min"
                type="number"
                step="0.01"
                value={formData.uae_benchmark_min}
                onChange={(e) => setFormData(prev => ({...prev, uae_benchmark_min: parseFloat(e.target.value)}))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="benchmark_max">UAE Benchmark Max</Label>
              <Input
                id="benchmark_max"
                type="number"
                step="0.01"
                value={formData.uae_benchmark_max}
                onChange={(e) => setFormData(prev => ({...prev, uae_benchmark_max: parseFloat(e.target.value)}))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select 
                value={formData.currency} 
                onValueChange={(value) => setFormData(prev => ({...prev, currency: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AED">AED</SelectItem>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="%">Percentage</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency</Label>
              <Select 
                value={formData.frequency} 
                onValueChange={(value) => setFormData(prev => ({...prev, frequency: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="one-time">One-time</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="per-transaction">Per Transaction</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <XCircle className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
            <Save className="w-4 h-4 mr-2" />
            {price ? 'Update' : 'Create'} Pricing Data
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}