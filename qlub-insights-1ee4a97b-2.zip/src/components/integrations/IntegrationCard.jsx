import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Edit3 } from "lucide-react";
import { PriorityBadge, StatusBadge } from "./IntegrationBadge";

export default function IntegrationCard({ item, onEdit }) {
  const first = (arr, n) => (Array.isArray(arr) ? arr.slice(0, n) : []);
  const moreCount = (arr, n) => (Array.isArray(arr) && arr.length > n ? arr.length - n : 0);

  return (
    <Card className="border-slate-200 hover:shadow-md transition-shadow">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="font-semibold text-slate-900">{item.integration_name}</div>
            <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span>{item.timeline || "Timeline TBD"}</span>
            </div>
          </div>
          <div className="flex gap-2">
            <PriorityBadge priority={item.priority} />
            <StatusBadge status={item.status} />
          </div>
        </div>

        {item.business_impact && (
          <p className="text-sm text-slate-700 line-clamp-2">{item.business_impact}</p>
        )}

        <div className="flex flex-wrap gap-1.5">
          {first(item.requirements, 2).map((r, i) => (
            <Badge key={i} variant="outline" className="text-xs">{r}</Badge>
          ))}
          {moreCount(item.requirements, 2) > 0 && (
            <Badge variant="outline" className="text-xs">+{moreCount(item.requirements, 2)} more</Badge>
          )}
        </div>

        <div className="flex items-center justify-between pt-1">
          <div className="flex flex-wrap gap-1.5">
            {first(item.target_customers, 2).map((t, i) => (
              <Badge key={i} className="bg-indigo-50 text-indigo-800 text-xs">{t}</Badge>
            ))}
          </div>
          <Button size="icon" variant="ghost" onClick={() => onEdit?.(item)} aria-label="Edit">
            <Edit3 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}