import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function IntegrationRequirementForm({ open, onOpenChange, initialData, onSubmit }) {
  const [form, setForm] = useState({
    integration_name: "",
    priority: "high",
    status: "planned",
    timeline: "",
    business_impact: "",
    requirements: "",
    technical_challenges: "",
    target_customers: ""
  });

  useEffect(() => {
    if (initialData) {
      setForm({
        integration_name: initialData.integration_name || "",
        priority: initialData.priority || "high",
        status: initialData.status || "planned",
        timeline: initialData.timeline || "",
        business_impact: initialData.business_impact || "",
        requirements: Array.isArray(initialData.requirements) ? initialData.requirements.join(", ") : (initialData.requirements || ""),
        technical_challenges: Array.isArray(initialData.technical_challenges) ? initialData.technical_challenges.join(", ") : (initialData.technical_challenges || ""),
        target_customers: Array.isArray(initialData.target_customers) ? initialData.target_customers.join(", ") : (initialData.target_customers || "")
      });
    } else {
      setForm({
        integration_name: "",
        priority: "high",
        status: "planned",
        timeline: "",
        business_impact: "",
        requirements: "",
        technical_challenges: "",
        target_customers: ""
      });
    }
  }, [initialData]);

  const parseList = (val) =>
    String(val || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

  const handleSave = () => {
    const payload = {
      integration_name: form.integration_name,
      priority: form.priority,
      status: form.status,
      timeline: form.timeline,
      business_impact: form.business_impact,
      requirements: parseList(form.requirements),
      technical_challenges: parseList(form.technical_challenges),
      target_customers: parseList(form.target_customers),
    };
    onSubmit(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{initialData ? "Edit Integration" : "Add Integration"}</DialogTitle>
        </DialogHeader>
        <div className="grid md:grid-cols-2 gap-4 py-2">
          <div className="space-y-2 md:col-span-2">
            <Label>Integration Name</Label>
            <Input
              value={form.integration_name}
              onChange={(e) => setForm({ ...form, integration_name: e.target.value })}
              placeholder="e.g., Oracle MICROS, Stripe, Talabat"
            />
          </div>

          <div className="space-y-2">
            <Label>Priority</Label>
            <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="planned">Planned</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="on-hold">On Hold</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Timeline</Label>
            <Input
              value={form.timeline}
              onChange={(e) => setForm({ ...form, timeline: e.target.value })}
              placeholder="e.g., Q4 2025, 8 weeks"
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label>Business Impact</Label>
            <Textarea
              rows={3}
              value={form.business_impact}
              onChange={(e) => setForm({ ...form, business_impact: e.target.value })}
              placeholder="What measurable outcome does this integration drive?"
            />
          </div>

          <div className="space-y-2">
            <Label>Requirements (comma-separated)</Label>
            <Textarea
              rows={3}
              value={form.requirements}
              onChange={(e) => setForm({ ...form, requirements: e.target.value })}
              placeholder="API access, OAuth, sandbox keys"
            />
          </div>

          <div className="space-y-2">
            <Label>Technical Challenges (comma-separated)</Label>
            <Textarea
              rows={3}
              value={form.technical_challenges}
              onChange={(e) => setForm({ ...form, technical_challenges: e.target.value })}
              placeholder="Rate limits, webhook retries, data mapping"
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label>Target Customers (comma-separated)</Label>
            <Textarea
              rows={2}
              value={form.target_customers}
              onChange={(e) => setForm({ ...form, target_customers: e.target.value })}
              placeholder="Enterprise, multi-location, quick-service"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}