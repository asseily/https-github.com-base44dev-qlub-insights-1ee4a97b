import React from "react";
import { Badge } from "@/components/ui/badge";

export function PriorityBadge({ priority }) {
  const map = {
    critical: "bg-red-100 text-red-800",
    high: "bg-amber-100 text-amber-800",
    medium: "bg-blue-100 text-blue-800",
    low: "bg-slate-100 text-slate-800",
  };
  const label = (priority || "").toString();
  return <Badge className={map[label] || "bg-slate-100 text-slate-800"}>{label || "—"}</Badge>;
}

export function StatusBadge({ status }) {
  const map = {
    planned: "bg-slate-100 text-slate-800",
    "in-progress": "bg-blue-100 text-blue-800",
    completed: "bg-emerald-100 text-emerald-800",
    "on-hold": "bg-amber-100 text-amber-800",
  };
  const label = (status || "").toString();
  return <Badge className={map[label] || "bg-slate-100 text-slate-800"}>{label || "—"}</Badge>;
}