import React, { useMemo } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import IntegrationCard from "./IntegrationCard";

const columns = [
  { id: "planned", title: "Planned" },
  { id: "in-progress", title: "In Progress" },
  { id: "completed", title: "Completed" },
  { id: "on-hold", title: "On Hold" },
];

export default function IntegrationKanban({ items, onStatusChange, onEdit }) {
  const grouped = useMemo(() => {
    const g = { planned: [], "in-progress": [], completed: [], "on-hold": [] };
    (items || []).forEach((it) => {
      const key = columns.find(c => c.id === it.status)?.id || "planned";
      g[key].push(it);
    });
    return g;
  }, [items]);

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result || {};
    if (!destination) return;
    const from = source?.droppableId;
    const to = destination?.droppableId;
    if (!from || !to || from === to) return;
    const item = (items || []).find((i) => i.id === draggableId);
    if (item && onStatusChange) onStatusChange(item, to);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {columns.map((col) => {
          const list = grouped[col.id] || [];
          return (
            <Droppable droppableId={col.id} key={col.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`rounded-xl border bg-white p-3 transition-all ${
                    snapshot.isDraggingOver ? "border-purple-300 bg-purple-50/50 ring-2 ring-purple-100" : "border-slate-200"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-slate-800">{col.title}</h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">{list.length}</span>
                  </div>
                  <div className="space-y-3 min-h-[60px]">
                    {list.map((it, idx) => (
                      <Draggable draggableId={it.id} index={idx} key={it.id}>
                        {(dragProvided, dragSnapshot) => (
                          <div
                            ref={dragProvided.innerRef}
                            {...dragProvided.draggableProps}
                            {...dragProvided.dragHandleProps}
                            className={`transition-transform ${dragSnapshot.isDragging ? "rotate-[1deg] scale-[1.01]" : ""}`}
                          >
                            <IntegrationCard item={it} onEdit={onEdit} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                </div>
              )}
            </Droppable>
          );
        })}
      </div>
    </DragDropContext>
  );
}