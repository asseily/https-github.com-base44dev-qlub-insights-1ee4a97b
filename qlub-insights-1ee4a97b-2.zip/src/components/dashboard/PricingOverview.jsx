import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PricingOverview({ pricing, isLoading }) {
  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center gap-3 text-xl">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          Pricing Structure
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="flex justify-between items-center">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-20" />
              </div>
            ))}
          </div>
        ) : pricing.length > 0 ? (
          <div className="space-y-4">
            {pricing.slice(0, 4).map((price) => (
              <div key={price.id} className="flex justify-between items-center p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-900">{price.fee_type}</span>
                  <Badge 
                    variant={price.status === 'confirmed' ? 'default' : 'secondary'}
                    className={price.status === 'missing' ? 'bg-amber-100 text-amber-800' : ''}
                  >
                    {price.status}
                  </Badge>
                </div>
                <span className="text-sm text-slate-600">
                  {price.explicit_rate || price.placeholder_rate || 'TBD'}
                </span>
              </div>
            ))}
            
            <div className="pt-4 border-t border-slate-100">
              <Link 
                to={createPageUrl("Pricing")} 
                className="text-sm text-emerald-600 hover:text-emerald-800 font-medium"
              >
                View pricing details →
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-500">
            <AlertTriangle className="w-8 h-8 mx-auto mb-3 text-amber-500" />
            <p className="mb-4">No pricing data available yet</p>
            <Link 
              to={createPageUrl("Pricing")} 
              className="text-sm text-blue-600 hover:text-blue-800 font-medium"
            >
              Add pricing structure →
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}