import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, CheckCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProductOverview({ modules, isLoading }) {
  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center gap-3 text-xl">
          <Package className="w-5 h-5 text-blue-600" />
          Product Suite Overview
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-4 w-full" />
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {modules.slice(0, 4).map((module) => (
              <div key={module.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                <CheckCircle className="w-4 h-4 text-emerald-500 mt-1 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-slate-900">{module.name}</h3>
                    <Badge variant="outline" className="text-xs">
                      {module.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {module.description}
                  </p>
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t border-slate-100">
              <Link 
                to={createPageUrl("ProductModules")} 
                className="text-sm text-blue-600 hover:text-blue-800 font-medium"
              >
                View all modules →
              </Link>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}