
import React from "react";
import { useEffect, useState, useMemo } from "react";
import { CustomerFeedback } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, ThumbsUp, MessageSquare, TrendingUp, TrendingDown, AlertCircle, Heart, Lightbulb } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function FeedbackInsights({ restaurant }) {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("30d");
  const [minRating, setMinRating] = useState("all");
  const [expandedComments, setExpandedComments] = useState({}); // NEW: track expanded comments

  const restaurantId = restaurant?.id;

  useEffect(() => {
    const load = async () => {
      if (!restaurantId) return;
      setLoading(true);
      const data = await CustomerFeedback.filter({ restaurant_id: restaurantId }, "-created_date", 300);
      setFeedback(data);
      setLoading(false);
    };
    load();
  }, [restaurantId]);

  const stats = useMemo(() => {
    if (!feedback.length) {
      return {
        avgRating: 0,
        avgFood: 0,
        avgService: 0,
        avgAtmosphere: 0,
        recommendRate: 0,
        count: 0,
        trend: "flat",
        highlights: [],
        improvements: [],
        recentComments: []
      };
    }

    const avg = (arr) => (arr.length ? arr.reduce((s, n) => s + (Number(n) || 0), 0) / arr.length : 0);

    const avgRating = avg(feedback.map((f) => f.rating));
    const avgFood = avg(feedback.map((f) => f.food_rating));
    const avgService = avg(feedback.map((f) => f.service_rating));
    const avgAtmosphere = avg(feedback.map((f) => f.atmosphere_rating));
    const recommendRate = (feedback.filter((f) => f.would_recommend).length / feedback.length) * 100;

    // Simple 7-day trend: compare last 3 days average vs previous 3 days
    const sortByDate = [...feedback].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    const recent6 = sortByDate.slice(0, 6);
    const a1 = avg(recent6.slice(0, 3).map((f) => f.rating)); // Use the defined `avg` function
    const a2 = avg(recent6.slice(3, 6).map((f) => f.rating)); // Use the defined `avg` function
    const trend = a1 > a2 + 0.05 ? "up" : a1 < a2 - 0.05 ? "down" : "flat";

    const countTags = (key) => {
      const map = {};
      feedback.forEach((f) => {
        (Array.isArray(f[key]) ? f[key] : []).forEach((t) => {
          map[t] = (map[t] || 0) + 1;
        });
      });
      return Object.entries(map)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([label, count]) => ({ label, count }));
    };

    const highlights = countTags("experience_highlights");
    const improvements = countTags("improvement_areas");

    const recentComments = sortByDate
      .filter((f) => f.comment)
      .slice(0, 5)
      .map((f) => ({
        comment: f.comment,
        rating: f.rating,
        date: f.created_date
      }));

    return {
      avgRating,
      avgFood,
      avgService,
      avgAtmosphere,
      recommendRate,
      count: feedback.length,
      trend,
      highlights,
      improvements,
      recentComments
    };
  }, [feedback]);

  const series = useMemo(() => {
    const days =  period === "7d" ? 7 : period === "90d" ? 90 : 30;
    const cutoff = new Date(Date.now() - days*24*60*60*1000);
    const filtered = feedback.filter(f => new Date(f.created_date) >= cutoff);
    const map = {};
    filtered.forEach(f => {
      const d = new Date(f.created_date);
      const key = `${d.getFullYear()}-${(d.getMonth()+1).toString().padStart(2,"0")}-${d.getDate().toString().padStart(2,"0")}`;
      if (!map[key]) map[key] = [];
      map[key].push(Number(f.rating) || 0);
    });
    return Object.entries(map).sort(([a],[b]) => a.localeCompare(b)).map(([date, arr]) => ({
      date, rating: arr.length ? arr.reduce((s,n)=>s+n,0)/arr.length : 0
    }));
  }, [feedback, period]);

  // NEW: custom tooltip for chart
  const ChartTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    const date = new Date(label);
    const dateStr = isNaN(date.getTime())
      ? label
      : date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const value = Number(payload[0].value || 0).toFixed(2);
    return (
      <div className="bg-white border border-slate-200 rounded-md p-2 text-xs shadow-sm">
        <div className="text-slate-500">{dateStr}</div>
        <div className="font-semibold text-slate-900">Avg Rating: {value}</div>
      </div>
    );
  };

  if (!restaurantId) return null;

  const toggleExpand = (key) => {
    setExpandedComments((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const formatTick = (d) => {
    const dt = new Date(d);
    return isNaN(dt.getTime())
      ? d
      : dt.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-purple-600" />
          Feedback Insights
        </CardTitle>
        <div className="mt-2 flex items-center gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7d</SelectItem>
              <SelectItem value="30d">Last 30d</SelectItem>
              <SelectItem value="90d">Last 90d</SelectItem>
            </SelectContent>
          </Select>
          <Select value={minRating} onValueChange={setMinRating}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All ratings</SelectItem>
              <SelectItem value="4">Only 4★+</SelectItem>
              <SelectItem value="3">Only 3★+</SelectItem>
              <SelectItem value="2">Only 2★+</SelectItem>
              <SelectItem value="1">Only 1★+</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={series}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={formatTick} interval="preserveStartEnd" />
              <YAxis domain={[0,5]} ticks={[0,1,2,3,4,5]} />
              <Tooltip content={<ChartTooltip />} />
              <Line type="monotone" dataKey="rating" stroke="#8B5CF6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-4 rounded-lg border bg-white">
            <div className="text-xs text-slate-500 mb-1">Avg Rating</div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-500" />
              <div className="text-xl font-semibold">{stats.avgRating.toFixed(1)}</div>
            </div>
          </div>
          <div className="p-4 rounded-lg border bg-white">
            <div className="text-xs text-slate-500 mb-1">Food</div>
            <div className="text-xl font-semibold">{stats.avgFood.toFixed(1)}</div>
          </div>
          <div className="p-4 rounded-lg border bg-white">
            <div className="text-xs text-slate-500 mb-1">Service</div>
            <div className="text-xl font-semibold">{stats.avgService.toFixed(1)}</div>
          </div>
          <div className="p-4 rounded-lg border bg-white">
            <div className="text-xs text-slate-500 mb-1">Atmosphere</div>
            <div className="text-xl font-semibold">{stats.avgAtmosphere.toFixed(1)}</div>
          </div>
          <div className="p-4 rounded-lg border bg-white">
            <div className="text-xs text-slate-500 mb-1">Would Recommend</div>
            <div className="flex items-center gap-2">
              <ThumbsUp className="w-4 h-4 text-emerald-600" />
              <div className="text-xl font-semibold">{Math.round(stats.recommendRate)}%</div>
            </div>
          </div>
        </div>

        {/* Trend */}
        <div className="flex items-center gap-2">
          {stats.trend === "up" && (
            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200" variant="outline">
              <TrendingUp className="w-4 h-4 mr-1" /> Trending up
            </Badge>
          )}
          {stats.trend === "down" && (
            <Badge className="bg-amber-100 text-amber-800 border-amber-200" variant="outline">
              <TrendingDown className="w-4 h-4 mr-1" /> Trending down
            </Badge>
          )}
          {stats.trend === "flat" && (
            <Badge className="bg-slate-100 text-slate-700 border-slate-200" variant="outline">
              <AlertCircle className="w-4 h-4 mr-1" /> Stable
            </Badge>
          )}
          <span className="text-xs text-slate-500">{stats.count} feedback entries</span>
        </div>

        {/* Highlights and Improvements */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
              <Heart className="w-4 h-4 text-emerald-600" />
              What guests loved
            </div>
            <div className="flex flex-wrap gap-2">
              {stats.highlights.length ? (
                stats.highlights.map((h) => (
                  <Badge key={h.label} variant="outline" className="capitalize bg-emerald-50 text-emerald-700 border-emerald-200 flex items-center gap-1">
                    <Heart className="w-3 h-3" />
                    {h.label} • {h.count}
                  </Badge>
                ))
              ) : (
                <div className="text-sm text-slate-500">No highlights yet.</div>
              )}
            </div>
          </div>
          <div>
            <div className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-600" />
              Needs improvement
            </div>
            <div className="flex flex-wrap gap-2">
              {stats.improvements.length ? (
                stats.improvements.map((h) => (
                  <Badge key={h.label} variant="outline" className="capitalize bg-amber-50 text-amber-800 border-amber-200 flex items-center gap-1">
                    <Lightbulb className="w-3 h-3" />
                    {h.label} • {h.count}
                  </Badge>
                ))
              ) : (
                <div className="text-sm text-slate-500">No improvement themes yet.</div>
              )}
            </div>
          </div>
        </div>

        {/* Recent comments */}
        <div>
          <div className="font-semibold text-slate-900 mb-3">Recent comments</div>
          <div className="space-y-3">
            {loading ? (
              <div className="text-sm text-slate-500">Loading feedback...</div>
            ) : (() => {
              const min = minRating === "all" ? 0 : Number(minRating);
              const comments = feedback
                .filter(f => (f.comment && (Number(f.rating)||0) >= min))
                .sort((a,b)=> new Date(b.created_date) - new Date(a.created_date))
                .slice(0, 5);
              return comments.length ? comments.map((f, idx) => {
                const key = `${f.created_date}-${idx}`;
                const expanded = !!expandedComments[key];
                const text = expanded
                  ? f.comment
                  : (f.comment.length > 160 ? `${f.comment.slice(0, 160)}…` : f.comment);
                return (
                  <div key={key} className="p-3 rounded-lg border bg-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-amber-600">
                        <Star className="w-4 h-4" />
                        <span className="text-sm font-medium">{(Number(f.rating)||0).toFixed(1)}</span>
                      </div>
                      <div className="text-xs text-slate-500">
                        {f.created_date ? new Date(f.created_date).toLocaleDateString() : ""}
                      </div>
                    </div>
                    <div className="mt-2 text-slate-700 text-sm">{text}</div>
                    {f.comment.length > 160 && (
                      <button
                        className="mt-1 text-xs text-blue-600 hover:text-blue-800"
                        onClick={() => toggleExpand(key)}
                      >
                        Show {expanded ? "less" : "more"}
                      </button>
                    )}
                  </div>
                );
              }) : (
                <div className="text-sm text-slate-500">No comments yet.</div>
              );
            })()}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
