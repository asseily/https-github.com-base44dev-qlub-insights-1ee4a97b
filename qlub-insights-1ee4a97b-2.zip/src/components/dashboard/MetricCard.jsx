import React from 'react';
import { Card, CardHeader, CardTitle } from "@/components/ui/card";

export default function MetricCard({ title, value, icon: Icon, bgColor, description }) {
  return (
    <Card className="relative overflow-hidden hover:shadow-lg transition-all duration-300">
      <div className={`absolute top-0 right-0 w-24 h-24 transform translate-x-6 -translate-y-6 ${bgColor} rounded-full opacity-10`} />
      <CardHeader className="p-6">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <CardTitle className="text-3xl font-bold text-slate-900">
              {value}
            </CardTitle>
            <p className="text-xs text-slate-400">{description}</p>
          </div>
          <div className={`p-3 rounded-xl ${bgColor} bg-opacity-20`}>
            <Icon className={`w-5 h-5 ${bgColor.replace('bg-', 'text-')}`} />
          </div>
        </div>
      </CardHeader>
    </Card>
  );
}