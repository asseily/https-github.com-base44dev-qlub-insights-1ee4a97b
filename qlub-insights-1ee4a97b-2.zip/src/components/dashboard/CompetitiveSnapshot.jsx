import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function CompetitiveSnapshot({ competitors, isLoading }) {
  const getPositionIcon = (position) => {
    switch(position) {
      case 'leader': return <TrendingUp className="w-4 h-4 text-emerald-500" />;
      case 'challenger': return <TrendingUp className="w-4 h-4 text-blue-500" />;
      default: return <TrendingDown className="w-4 h-4 text-slate-400" />;
    }
  };

  const getPositionColor = (position) => {
    switch(position) {
      case 'leader': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'challenger': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'follower': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="flex items-center gap-3 text-xl">
          <Users className="w-5 h-5 text-purple-600" />
          Competitive Landscape
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="grid md:grid-cols-2 gap-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="p-4 border rounded-lg space-y-2">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-3 w-full" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {competitors.slice(0, 4).map((competitor) => (
              <div key={competitor.id} className="p-4 border border-slate-200 rounded-xl hover:border-slate-300 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">{competitor.competitor_name}</h3>
                  {getPositionIcon(competitor.market_position)}
                </div>
                
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="outline" className="text-xs">
                    {competitor.region}
                  </Badge>
                  <Badge className={getPositionColor(competitor.market_position)}>
                    {competitor.market_position}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm">
                  {competitor.strengths?.slice(0, 2).map((strength, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-slate-600">{strength}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}