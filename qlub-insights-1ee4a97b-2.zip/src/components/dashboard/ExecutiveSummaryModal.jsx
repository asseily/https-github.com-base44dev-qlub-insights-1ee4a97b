import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, TrendingUp, AlertTriangle, CheckCircle, Target, Download } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ExecutiveSummaryModal({ isOpen, onClose, summary }) {
  if (!isOpen) return null;

  const handleDownloadSummary = () => {
    const summaryText = `
# Qlub.io Executive Summary

## Business Overview
${summary.overview}

## Key Strengths
${summary.key_strengths?.map(strength => `• ${strength}`).join('\n') || 'No strengths identified'}

## Market Opportunities
${summary.opportunities?.map(opp => `• ${opp}`).join('\n') || 'No opportunities identified'}

## Critical Challenges
${summary.challenges?.map(challenge => `• ${challenge}`).join('\n') || 'No challenges identified'}

## Strategic Recommendations
${summary.recommendations?.map(rec => `• ${rec}`).join('\n') || 'No recommendations available'}

## Market Position Assessment
${summary.market_position}

## Priority Actions
${summary.priority_actions?.map(action => `• ${action}`).join('\n') || 'No priority actions defined'}

---
Generated on: ${new Date().toLocaleDateString()}
    `.trim();

    const blob = new Blob([summaryText], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Qlub_Executive_Summary_${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        >
          {/* Header */}
          <CardHeader className="bg-gradient-to-r from-blue-900 to-amber-600 text-white rounded-t-2xl">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl flex items-center gap-3">
                  <TrendingUp className="w-6 h-6" />
                  Executive Summary
                </CardTitle>
                <p className="text-blue-100 mt-2">Strategic Overview & Key Insights</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleDownloadSummary}
                  className="text-white hover:bg-white/20 rounded-full"
                >
                  <Download className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-white hover:bg-white/20 rounded-full"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-8 space-y-8">
            {/* Business Overview */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                Business Overview
              </h3>
              <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                <p className="text-slate-700 leading-relaxed">{summary.overview}</p>
              </div>
            </div>

            {/* Key Insights Grid */}
            <div className="grid md:grid-cols-2 gap-8">
              {/* Strengths */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                  Key Strengths
                </h3>
                <div className="space-y-3">
                  {summary.key_strengths?.map((strength, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-emerald-50 rounded-lg">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 flex-shrink-0" />
                      <p className="text-sm text-slate-700">{strength}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Opportunities */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Market Opportunities
                </h3>
                <div className="space-y-3">
                  {summary.opportunities?.map((opportunity, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                      <p className="text-sm text-slate-700">{opportunity}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Challenges */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                Critical Challenges
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {summary.challenges?.map((challenge, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-slate-700">{challenge}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Position */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                Market Position Assessment
              </h3>
              <div className="p-6 bg-purple-50 rounded-xl border border-purple-200">
                <p className="text-slate-700 leading-relaxed">{summary.market_position}</p>
              </div>
            </div>

            {/* Recommendations */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Strategic Recommendations
              </h3>
              <div className="space-y-3">
                {summary.recommendations?.map((recommendation, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                      {idx + 1}
                    </div>
                    <p className="text-sm text-slate-700 font-medium">{recommendation}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Priority Actions */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-5 h-5 text-red-600" />
                Priority Actions
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {summary.priority_actions?.map((action, idx) => (
                  <div key={idx} className="p-4 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className="bg-red-600 text-white text-xs">
                        HIGH
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-700 font-medium">{action}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>

          {/* Footer */}
          <div className="p-6 bg-slate-50 rounded-b-2xl border-t border-slate-200">
            <div className="flex justify-between items-center">
              <div className="text-sm text-slate-500">
                Generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={handleDownloadSummary}>
                  <Download className="w-4 h-4 mr-2" />
                  Download Summary
                </Button>
                <Button onClick={onClose} className="bg-blue-600 hover:bg-blue-700">
                  Close
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}