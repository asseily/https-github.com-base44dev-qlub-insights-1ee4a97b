
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Plus, Minus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ItemCustomizationModal({ item, onClose, onAddToCart, brandColor }) {
  const [selectedModifiers, setSelectedModifiers] = useState({});
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [quantity, setQuantity] = useState(1);

  if (!item) return null; // Ensure item is available before rendering

  // Helper to determine if the modal is open or not based on item prop
  const isOpen = !!item;

  const handleModifierChange = (modifierName, optionName, singleChoice) => {
    setSelectedModifiers(prev => {
      const prevSelections = prev[modifierName] || [];
      const option = item.modifiers
        .find(mod => mod.name === modifierName)
        .options.find(opt => opt.name === optionName);

      if (!option) return prev; // Should not happen if data is consistent

      if (singleChoice) {
        // For single choice modifiers, replace any existing selection with the new one
        return {
          ...prev,
          [modifierName]: [option] // Store as an array with one element
        };
      } else {
        // For multi-choice modifiers, toggle the option
        if (prevSelections.some(mod => mod.name === optionName)) {
          // If already selected, remove it
          return {
            ...prev,
            [modifierName]: prevSelections.filter(mod => mod.name !== optionName)
          };
        } else {
          // If not selected, add it
          return {
            ...prev,
            [modifierName]: [...prevSelections, option]
          };
        }
      }
    });
  };

  const calculatePrice = () => {
    let modifierPriceSum = 0;
    Object.values(selectedModifiers).forEach(optionsArray => {
      if (Array.isArray(optionsArray)) {
        optionsArray.forEach(option => {
          if (option && typeof option.price_change === 'number') {
            modifierPriceSum += option.price_change;
          }
        });
      }
    });
    return (item.price + modifierPriceSum) * quantity;
  };

  const handleAddToCartClick = () => {
    const modifiersList = Object.entries(selectedModifiers)
      .flatMap(([modifierName, options]) =>
        Array.isArray(options) ? options.map(option => ({
          modifier_name: modifierName,
          option_name: option.name,
          price_change: option.price_change || 0
        })) : []
      );

    // FIX: pass quantity properly in the signature (item, quantity, selectedModifiers, specialInstructions)
    onAddToCart(item, quantity, modifiersList, specialInstructions);

    onClose();
  };

  const totalPrice = calculatePrice(); // Use the corrected calculatePrice function

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <header className="p-4 border-b relative">
              <h2 className="text-xl font-bold text-center">{item.name}</h2>
              <Button variant="ghost" size="icon" className="absolute top-2 right-2 rounded-full" onClick={onClose}>
                <X className="w-5 h-5" />
              </Button>
            </header>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {item.image_url && (
                <img src={item.image_url} alt={item.name} className="w-full h-48 object-cover rounded-lg" />
              )}
              <p className="text-slate-600">{item.description}</p>
              {item.modifiers?.map((modifier, index) => (
                <div key={index} className="space-y-3">
                  <h3 className="font-semibold">{modifier.name} {modifier.single_choice ? "(Select one)" : "(Select multiple)"}</h3>
                  <div className="space-y-2">
                    {modifier.options.map((option, optIndex) => (
                      <div key={optIndex} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <Label htmlFor={`${modifier.name}-${option.name}`} className="flex items-center gap-3 cursor-pointer flex-1">
                          {modifier.single_choice ? (
                            <RadioGroupItem
                              value={option.name}
                              id={`${modifier.name}-${option.name}`}
                              checked={selectedModifiers[modifier.name]?.[0]?.name === option.name}
                              onClick={() => handleModifierChange(modifier.name, option.name, true)}
                              style={{ borderColor: brandColor }}
                              // Adding onValueChange for RadioGroupItem compatibility if it were within a RadioGroup
                              // For standalone use with onClick, this is fine, but often RadioGroupItem needs its parent RadioGroup's handler.
                              // Since we're handling onClick directly on RadioGroupItem here, it bypasses the RadioGroup's internal state.
                            />
                          ) : (
                            <Checkbox
                              id={`${modifier.name}-${option.name}`}
                              checked={selectedModifiers[modifier.name]?.some(m => m.name === option.name)}
                              onCheckedChange={() => handleModifierChange(modifier.name, option.name, false)}
                              style={{ borderColor: brandColor }}
                            />
                          )}
                          <span>{option.name}</span>
                        </Label>
                        {option.price_change !== 0 && (
                          <span className="text-sm text-slate-500">
                            {option.price_change > 0 ? '+' : ''}AED {option.price_change.toFixed(2)}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <div className="space-y-2">
                <h3 className="font-semibold">Special Instructions</h3>
                <Textarea
                  placeholder="Any special requests? (e.g., no onions, extra spicy)"
                  value={specialInstructions}
                  onChange={e => setSpecialInstructions(e.target.value)}
                  className="resize-none h-20"
                />
              </div>

              {item.allergens?.length > 0 && (
                <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <p className="text-sm text-orange-800">
                    <strong>Allergen Warning:</strong> Contains {item.allergens.join(', ')}
                  </p>
                </div>
              )}
            </div>

            <footer className="p-4 border-t bg-slate-50/50 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => setQuantity(q => Math.max(1, q - 1))} className="rounded-full">
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="font-bold text-lg w-10 text-center">{quantity}</span>
                <Button variant="outline" size="icon" onClick={() => setQuantity(q => q + 1)} className="rounded-full">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <Button className="flex-1 h-12 text-lg rounded-xl" onClick={handleAddToCartClick} style={{ backgroundColor: brandColor }}>
                Add to Cart - AED {totalPrice.toFixed(2)}
              </Button>
            </footer>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
