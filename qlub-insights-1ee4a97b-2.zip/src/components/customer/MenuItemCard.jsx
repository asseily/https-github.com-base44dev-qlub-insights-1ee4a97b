import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import { motion } from "framer-motion";

import ItemCustomizationModal from "./ItemCustomizationModal";

export default function MenuItemCard({ item, onAddToCart }) {
  const [showCustomization, setShowCustomization] = useState(false);

  const handleQuickAdd = () => {
    if (item.modifiers && item.modifiers.length > 0) {
      setShowCustomization(true);
    } else {
      onAddToCart(item);
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.02 }}
        className="w-full"
      >
        <Card className="bg-white/95 backdrop-blur-sm hover:bg-white transition-all duration-200 overflow-hidden">
          <CardContent className="p-0">
            <div className="flex gap-4 p-4">
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 text-lg">{item.name}</h3>
                  <div className="text-right">
                    <p className="font-bold text-purple-600 text-lg">AED {item.price.toFixed(2)}</p>
                  </div>
                </div>
                
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {item.dietary_info?.map((diet, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                        {diet}
                      </Badge>
                    ))}
                    {item.featured && (
                      <Badge className="bg-yellow-500 text-black text-xs">Popular</Badge>
                    )}
                  </div>
                  
                  <Button
                    onClick={handleQuickAdd}
                    size="sm"
                    className="bg-purple-600 hover:bg-purple-700 rounded-full px-4"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add
                  </Button>
                </div>

                {item.allergens?.length > 0 && (
                  <div className="mt-2">
                    <p className="text-xs text-orange-600">
                      Allergens: {item.allergens.join(', ')}
                    </p>
                  </div>
                )}
              </div>
              
              {item.image_url && (
                <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                  <img 
                    src={item.image_url} 
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {showCustomization && (
        <ItemCustomizationModal
          item={item}
          isOpen={showCustomization}
          onClose={() => setShowCustomization(false)}
          onAddToCart={onAddToCart}
        />
      )}
    </>
  );
}