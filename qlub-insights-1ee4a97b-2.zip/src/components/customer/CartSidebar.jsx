
import React from 'react';
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { X, Plus, Minus, ShoppingCart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Order, PaymentLink } from "@/api/entities";
import { createPageUrl } from "@/utils";

export default function CartSidebar({
  isOpen,
  onClose,
  cart,
  restaurant,
  updateCartItemQuantity,
  setCart,
  brandColor,
  table
}) {

  // The outline indicated to keep calculateSubtotal, adapting it for potential new modifier structure
  // while preserving its core logic of including modifier price changes.
  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => {
      let modifierPrice = 0;
      // Check if item.selectedModifiers is the new object-of-arrays structure
      if (item.selectedModifiers && typeof item.selectedModifiers === 'object' && !Array.isArray(item.selectedModifiers)) {
        modifierPrice = Object.values(item.selectedModifiers).flat().reduce((modSum, mod) => modSum + (mod.price_change || 0), 0);
      } else if (Array.isArray(item.selectedModifiers)) {
        // Fallback to old array structure
        modifierPrice = item.selectedModifiers.reduce((modSum, mod) => modSum + (mod.price_change || 0), 0);
      }
      return sum + ((item.price + modifierPrice) * item.quantity);
    }, 0);
  };

  const subtotal = calculateSubtotal();
  const tax = subtotal * ((restaurant.settings?.tax_rate || 5) / 100);
  const serviceCharge = subtotal * ((restaurant.settings?.service_charge || 0) / 100);
  const total = subtotal + tax + serviceCharge;

  const handleCheckout = async () => {
    if (!restaurant?.id || cart.length === 0) {
      onClose();
      return;
    }

    // 1) Create order
    const itemsPayload = cart.map(ci => {
      let selectedModifiersForPayload = [];
      if (ci.selectedModifiers) {
        if (Array.isArray(ci.selectedModifiers)) {
          selectedModifiersForPayload = ci.selectedModifiers;
        } else if (typeof ci.selectedModifiers === 'object') {
          selectedModifiersForPayload = Object.values(ci.selectedModifiers).flat();
        }
      }

      return {
        menu_item_id: ci.id,
        quantity: ci.quantity,
        selected_modifiers: selectedModifiersForPayload,
        special_instructions: ci.specialInstructions || ""
      };
    });

    const payloadTotals = {
      subtotal,
      tax_amount: tax,
      service_charge: serviceCharge,
      tip_amount: 0,
      total
    };

    const newOrder = await Order.create({
      restaurant_id: restaurant.id,
      table_id: table?.id || "",
      items: itemsPayload,
      ...payloadTotals,
      status: "pending",
      payment_status: "unpaid"
    });

    // 2) Create a payment link for this order
    const pl = await PaymentLink.create({
      restaurant_id: restaurant.id,
      order_id: newOrder.id,
      amount: total,
      currency: restaurant.settings?.currency || "AED",
      link_type: "one_time",
      status: "active",
      reference: `Order ${newOrder.id}`
    });

    const url = window.location.origin + createPageUrl(`PaymentPortal?payment_link_id=${pl.id}`);
    await PaymentLink.update(pl.id, { generated_url: url });

    // 3) Navigate to payment page, clear cart
    setCart([]);
    onClose();
    window.location.href = url;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <header className="p-4 border-b flex items-center justify-between">
              <h2 className="text-xl font-bold">Your Order</h2>
              <Button variant="ghost" size="icon" className="rounded-full" onClick={onClose}>
                <X className="w-5 h-5" />
              </Button>
            </header>

            {cart.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
                <ShoppingCart className="w-16 h-16 text-slate-300 mb-4" />
                <h3 className="font-semibold text-lg mb-2">Your cart is empty</h3>
                <p className="text-slate-500">Add some delicious items from the menu to get started.</p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {cart.map(item => {
                  let itemModifierPrice = 0;
                  if (item.selectedModifiers && typeof item.selectedModifiers === 'object' && !Array.isArray(item.selectedModifiers)) {
                    itemModifierPrice = Object.values(item.selectedModifiers).flat().reduce((modSum, mod) => modSum + (mod.price_change || 0), 0);
                  } else if (Array.isArray(item.selectedModifiers)) {
                    itemModifierPrice = item.selectedModifiers.reduce((modSum, mod) => modSum + (mod.price_change || 0), 0);
                  }
                  const itemTotalPrice = (item.price + itemModifierPrice) * item.quantity;

                  return (
                    <div key={item.cartItemId} className="flex gap-4">
                      {item.image_url && <img src={item.image_url} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />}
                      <div className="flex-1">
                        <h4 className="font-semibold">{item.name}</h4>
                        <p className="text-sm text-slate-500">AED {item.price.toFixed(2)}</p> {/* Base item price */}
                        {item.selectedModifiers && typeof item.selectedModifiers === 'object' && !Array.isArray(item.selectedModifiers) && Object.values(item.selectedModifiers).flat().map((mod, i) => (
                          <p key={i} className="text-xs text-slate-400 pl-2">
                            • {mod.option_name}
                            {mod.price_change !== 0 && ` (+AED ${mod.price_change.toFixed(2)})`}
                          </p>
                        ))}
                         {item.specialInstructions && (
                          <p className="text-xs text-slate-500 mt-1">Note: {item.specialInstructions}</p>
                        )}
                      </div>
                      <div className="flex flex-col items-end justify-between">
                        <div className="flex items-center gap-1">
                          <Button variant="outline" size="icon" className="w-6 h-6" onClick={() => updateCartItemQuantity(item.cartItemId, item.quantity - 1)}><Minus className="w-3 h-3" /></Button>
                          <span className="font-bold w-6 text-center">{item.quantity}</span>
                          <Button variant="outline" size="icon" className="w-6 h-6" onClick={() => updateCartItemQuantity(item.cartItemId, item.quantity + 1)}><Plus className="w-3 h-3" /></Button>
                        </div>
                        <span className="font-bold">AED {itemTotalPrice.toFixed(2)}</span> {/* Total for this item, including modifiers */}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {cart.length > 0 && (
              <footer className="p-4 border-t bg-slate-50/50 space-y-4">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between"><span>Subtotal</span><span>AED {subtotal.toFixed(2)}</span></div>
                  <div className="flex justify-between text-slate-500"><span>Taxes</span><span>AED {tax.toFixed(2)}</span></div>
                  {serviceCharge > 0 && <div className="flex justify-between text-slate-500"><span>Service Charge</span><span>AED {serviceCharge.toFixed(2)}</span></div>}
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>AED {total.toFixed(2)}</span>
                </div>
                <Button className="w-full h-12 text-lg" onClick={handleCheckout} style={{ backgroundColor: brandColor }}>
                  Proceed to Checkout
                </Button>
              </footer>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
