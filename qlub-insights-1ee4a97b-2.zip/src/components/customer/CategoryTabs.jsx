import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function CategoryTabs({ categories, activeCategory, setActiveCategory, brandColor }) {
  const tabsRef = useRef(null);

  useEffect(() => {
    const activeTab = tabsRef.current?.querySelector(`[data-category="${activeCategory}"]`);
    if (activeTab) {
      activeTab.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [activeCategory]);
  
  return (
    <div ref={tabsRef} className="overflow-x-auto whitespace-nowrap px-4 border-t border-slate-200 hide-scrollbar">
      {categories.map(category => (
        <button
          key={category}
          onClick={() => setActiveCategory(category)}
          data-category={category}
          className={`relative py-3 px-4 text-sm font-medium transition-colors capitalize ${
            activeCategory === category ? 'text-slate-900' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          {category.replace('_', ' ')}
          {activeCategory === category && (
            <motion.div
              layoutId="category-underline"
              className="absolute bottom-0 left-0 right-0 h-0.5"
              style={{ backgroundColor: brandColor }}
              initial={false}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            />
          )}
        </button>
      ))}
    </div>
  );
}