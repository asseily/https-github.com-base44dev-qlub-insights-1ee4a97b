
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { CheckCircle2, Download, Star } from "lucide-react";

export default function PaymentSuccessOverlay({
  open,
  onClose,
  amount,
  currency = "AED",
  restaurantName = "Payment",
  orderId,
  receiptEmail,
  autoRedirectInSeconds = 2,
  onGiveFeedback
}) {
  const [rating, setRating] = React.useState(5);
  const [comment, setComment] = React.useState("");
  const [animate, setAnimate] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setAnimate(false), 800);
    return () => clearTimeout(t);
  }, []);

  if (!open) return null;

  const fmt = (v) => `${currency} ${Number(v || 0).toFixed(2)}`;

  const downloadReceipt = () => {
    const title = `Receipt - ${restaurantName} - ${new Date().toLocaleString()}`;
    const html = `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>${title}</title>
          <style>
            body { font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; padding: 24px; color: #0f172a; }
            h1 { margin: 0 0 8px 0; font-size: 20px; }
            .muted { color: #64748b; }
            table { width: 100%; margin-top: 16px; border-collapse: collapse; }
            td { padding: 6px 0; font-size: 14px; }
            .total { font-weight: 700; font-size: 16px; }
          </style>
        </head>
        <body>
          <h1>${restaurantName}</h1>
          <div class="muted">${new Date().toLocaleString()}</div>
          <table>
            <tr><td>Order</td><td style="text-align:right">#${orderId || "—"}</td></tr>
            <tr><td>Amount</td><td style="text-align:right">${fmt(amount)}</td></tr>
            <tr><td>Receipt emailed to</td><td style="text-align:right">${receiptEmail || "—"}</td></tr>
          </table>
          <div style="margin-top: 24px;" class="muted">Thank you for your payment!</div>
          <script>window.onload = () => setTimeout(() => window.print(), 100);</script>
        </body>
      </html>
    `;
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(html);
    w.document.close();
    w.focus();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
      {/* Subtle one-time pop animation */}
      <style>{`
        @keyframes pop-in { 
          0% { transform: scale(0.85); opacity: 0; } 
          60% { transform: scale(1.08); opacity: 1; } 
          100% { transform: scale(1); } 
        }
        .animate-pop { animation: pop-in 450ms ease-out; }
      `}</style>
      <Card className="max-w-lg w-full shadow-2xl border-0 bg-gradient-to-br from-white to-slate-50">
        <CardHeader className="text-center">
          <div className={`mx-auto w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mb-3 ${animate ? "animate-pop" : ""}`}>
            <CheckCircle2 className="w-9 h-9 text-emerald-600" />
          </div>
          <CardTitle className="text-2xl">Payment Successful</CardTitle>
          <div className="text-slate-500 text-sm mt-1">
            {restaurantName} • {fmt(amount)}{receiptEmail ? ` • Receipt sent to ${receiptEmail}` : ""}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Redirecting in {autoRedirectInSeconds}s...
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div>
            <div className="text-sm font-medium mb-2">Quick Feedback</div>
            <div className="flex items-center gap-1 mb-2">
              {[1,2,3,4,5].map((i) => (
                <button
                  key={i}
                  onClick={() => setRating(i)}
                  className={`p-1 transition ${i <= rating ? "text-amber-500" : "text-slate-300"} hover:scale-110`}
                  aria-label={`Rate ${i} star${i>1?"s":""}`}
                  type="button"
                >
                  <Star className="w-6 h-6 fill-current cursor-pointer" />
                </button>
              ))}
            </div>
            <textarea
              rows={3}
              className="w-full border rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-200"
              placeholder="Tell us about your experience..."
              value={comment}
              onChange={(e)=>setComment(e.target.value)}
            />
            <div className="flex gap-2 mt-2">
              <Button size="sm" className="bg-purple-600 hover:bg-purple-700" onClick={() => onGiveFeedback?.(rating, comment)}>
                Submit Feedback
              </Button>
              <Button size="sm" variant="outline" onClick={downloadReceipt}>
                <Download className="w-4 h-4 mr-2" /> Download Receipt
              </Button>
            </div>
          </div>
          <Separator />
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" onClick={onClose}>Close</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
