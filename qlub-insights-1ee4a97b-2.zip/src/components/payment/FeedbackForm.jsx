import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Star, Loader2, ThumbsUp } from "lucide-react";
import { motion } from "framer-motion";

export default function FeedbackForm({ restaurant, order, onComplete, brandColor }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    // In a real app, you would save this to a Feedback entity.
    console.log({ rating, comment, customerName, customerEmail });
    await new Promise(res => setTimeout(res, 1000)); // Simulate API call
    setIsSubmitting(false);
    setSubmitted(true);
    if (onComplete) {
      onComplete();
    }
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center p-8"
      >
        <ThumbsUp className="w-16 h-16 mx-auto mb-4 text-green-500" />
        <h2 className="text-2xl font-bold mb-2">Thank you for your feedback!</h2>
        <p className="text-slate-600">We appreciate you taking the time to share your thoughts.</p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
    >
      <Card className="max-w-2xl mx-auto shadow-xl border-0">
        <CardHeader className="text-center">
          <Star className="w-12 h-12 mx-auto mb-4" style={{color: brandColor}}/>
          <CardTitle className="text-3xl font-bold text-slate-900">
            How was your experience at {restaurant.name}?
          </CardTitle>
          <p className="text-slate-600">Your feedback helps us improve.</p>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="p-8 space-y-8">
            <div className="text-center space-y-4">
              <Label className="text-lg font-semibold">Your Overall Rating</Label>
              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.div key={star} whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                    <Star
                      className={`w-10 h-10 cursor-pointer transition-colors ${
                        star <= rating ? 'text-amber-400' : 'text-slate-300'
                      }`}
                      fill={star <= rating ? 'currentColor' : 'none'}
                      onClick={() => setRating(star)}
                    />
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-lg font-semibold">Tell us more</Label>
              <Textarea
                placeholder="What did you like or dislike? How can we improve?"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="h-32"
              />
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="customer_name">Your Name</Label>
                <Input
                  id="customer_name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Jane Doe"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="customer_email">Your Email</Label>
                <Input
                  id="customer_email"
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="jane.d@example.com"
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full h-12 text-lg" disabled={isSubmitting} style={{backgroundColor: brandColor}}>
              {isSubmitting ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                'Submit Feedback'
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </motion.div>
  );
}