import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard, Smartphone, ShieldCheck } from "lucide-react";

export default function PaymentMethodSelector({ paymentMethod, onMethodChange, brandColor }) {
  const methods = [
    { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
    { id: 'digital_wallet', name: 'Digital Wallet', icon: Smartphone },
  ];

  return (
    <Card className="shadow-lg border-0">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <ShieldCheck className="w-5 h-5" style={{color: brandColor}}/>
          Choose Payment Method
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {methods.map((method) => (
            <Button
              key={method.id}
              variant={paymentMethod === method.id ? 'default' : 'outline'}
              onClick={() => onMethodChange(method.id)}
              className={`p-4 h-auto flex flex-col gap-2 ${
                paymentMethod === method.id ? 'text-white hover:opacity-90' : ''
              }`}
              style={paymentMethod === method.id ? {backgroundColor: brandColor} : {}}
            >
              <method.icon className="w-6 h-6 mb-1" />
              <span className="font-medium">{method.name}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}