
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, X, Users, Calculator, Equal } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function BillSplitter({ order, splitDetails, onSplitChange, brandColor }) {
  const [splitMethod, setSplitMethod] = useState('equal'); // 'equal' or 'custom'
  const [numberOfPeople, setNumberOfPeople] = useState(2);
  const [customSplits, setCustomSplits] = useState([
    { customer_name: '', amount: 0, items: [] }
  ]);

  const generateEqualSplit = useCallback(() => {
    const totalAmount = order.total || 0;
    const amountPerPerson = totalAmount / numberOfPeople;
    
    const equalSplits = Array.from({ length: numberOfPeople }, (_, index) => ({
      customer_name: `Person ${index + 1}`,
      amount: amountPerPerson,
      items: [],
      payment_status: 'pending'
    }));
    
    onSplitChange(equalSplits);
  }, [order.total, numberOfPeople, onSplitChange]);

  useEffect(() => {
    if (splitMethod === 'equal') {
      generateEqualSplit();
    } else {
      onSplitChange(customSplits.filter(split => split.customer_name && split.amount > 0));
    }
  }, [splitMethod, generateEqualSplit, customSplits, onSplitChange]);

  const addCustomSplit = () => {
    setCustomSplits(prev => [
      ...prev,
      { customer_name: '', amount: 0, items: [] }
    ]);
  };

  const removeCustomSplit = (index) => {
    setCustomSplits(prev => prev.filter((_, i) => i !== index));
  };

  const updateCustomSplit = (index, field, value) => {
    setCustomSplits(prev => prev.map((split, i) => 
      i === index ? { ...split, [field]: value } : split
    ));
  };

  const getTotalSplitAmount = () => {
    return customSplits.reduce((sum, split) => sum + (split.amount || 0), 0);
  };

  const getRemainingAmount = () => {
    return (order.total || 0) - getTotalSplitAmount();
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Users className="w-5 h-5" style={{color: brandColor}} />
          Split the Bill
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Split Method Selection */}
        <div className="space-y-4">
          <Label className="text-base font-semibold">How would you like to split?</Label>
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={splitMethod === 'equal' ? 'default' : 'outline'}
              onClick={() => setSplitMethod('equal')}
              className={`p-4 h-auto flex flex-col gap-2 ${
                splitMethod === 'equal' ? 'text-white hover:opacity-90' : ''
              }`}
              style={splitMethod === 'equal' ? {backgroundColor: brandColor} : {}}
            >
              <Equal className="w-6 h-6" />
              <span className="font-medium">Split Equally</span>
              <span className="text-xs opacity-70">Divide bill evenly</span>
            </Button>
            <Button
              variant={splitMethod === 'custom' ? 'default' : 'outline'}
              onClick={() => setSplitMethod('custom')}
              className={`p-4 h-auto flex flex-col gap-2 ${
                splitMethod === 'custom' ? 'text-white hover:opacity-90' : ''
              }`}
               style={splitMethod === 'custom' ? {backgroundColor: brandColor} : {}}
            >
              <Calculator className="w-6 h-6" />
              <span className="font-medium">Custom Split</span>
              <span className="text-xs opacity-70">Set custom amounts</span>
            </Button>
          </div>
        </div>

        <Separator />

        {/* Equal Split */}
        {splitMethod === 'equal' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-4">
              <Label htmlFor="people">Number of people:</Label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setNumberOfPeople(Math.max(2, numberOfPeople - 1))}
                  disabled={numberOfPeople <= 2}
                >
                  -
                </Button>
                <Input
                  id="people"
                  type="number"
                  min="2"
                  max="20"
                  value={numberOfPeople}
                  onChange={(e) => setNumberOfPeople(Math.max(2, parseInt(e.target.value) || 2))}
                  className="w-20 text-center"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setNumberOfPeople(Math.min(20, numberOfPeople + 1))}
                  disabled={numberOfPeople >= 20}
                >
                  +
                </Button>
              </div>
            </div>

            <div className="rounded-lg p-4 text-center" style={{backgroundColor: `${brandColor}1A`}}>
              <p className="text-sm mb-1" style={{color: brandColor}}>Amount per person</p>
              <p className="text-2xl font-bold" style={{color: brandColor}}>
                AED {((order.total || 0) / numberOfPeople).toFixed(2)}
              </p>
            </div>
          </motion.div>
        )}

        {/* Custom Split */}
        {splitMethod === 'custom' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold">Custom Amounts</Label>
              <Button variant="outline" size="sm" onClick={addCustomSplit}>
                <Plus className="w-4 h-4 mr-1" />
                Add Person
              </Button>
            </div>

            <AnimatePresence>
              {customSplits.map((split, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex gap-3 items-center p-4 bg-slate-50 rounded-lg"
                >
                  <div className="flex-1">
                    <Input
                      placeholder="Person's name"
                      value={split.customer_name}
                      onChange={(e) => updateCustomSplit(index, 'customer_name', e.target.value)}
                      className="mb-2"
                    />
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-slate-600">AED</span>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        value={split.amount || ''}
                        onChange={(e) => updateCustomSplit(index, 'amount', parseFloat(e.target.value) || 0)}
                        className="flex-1"
                      />
                    </div>
                  </div>
                  
                  {customSplits.length > 1 && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => removeCustomSplit(index)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Split Summary */}
            <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
              <div className="flex justify-between text-sm">
                <span>Total Bill:</span>
                <span className="font-medium">AED {(order.total || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Amount Split:</span>
                <span className="font-medium">AED {getTotalSplitAmount().toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm font-semibold">
                <span>Remaining:</span>
                <span className={getRemainingAmount() === 0 ? 'text-green-600' : 'text-amber-600'}>
                  AED {getRemainingAmount().toFixed(2)}
                </span>
              </div>
              
              {getRemainingAmount() !== 0 && (
                <div className="text-xs text-amber-600 text-center">
                  {getRemainingAmount() > 0 
                    ? 'Add more amounts to cover the full bill' 
                    : 'Split amounts exceed the total bill'
                  }
                </div>
              )}
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
