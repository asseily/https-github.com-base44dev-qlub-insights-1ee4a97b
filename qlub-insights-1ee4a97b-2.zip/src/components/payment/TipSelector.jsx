
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, Smile, Coffee } from "lucide-react";
import { motion } from "framer-motion";

export default function TipSelector({ orderTotal, tipAmount, onTipChange, restaurant, brandColor }) {
  const tipSuggestions = restaurant?.settings?.tip_suggestions || [10, 15, 20];
  const customTipPercentage = orderTotal > 0 ? (tipAmount / orderTotal) * 100 : 0;

  const calculateTipAmount = (percentage) => {
    return (orderTotal * percentage) / 100;
  };

  const setTipByPercentage = (percentage) => {
    onTipChange(calculateTipAmount(percentage));
  };

  const setCustomTip = (amount) => {
    onTipChange(Math.max(0, amount));
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Heart className="w-5 h-5 text-red-500" />
          Add a Tip
          <span className="text-sm font-normal text-slate-500">(Optional)</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Tip Message */}
        <div className="text-center p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg">
          <Smile className="w-8 h-8 mx-auto mb-2 text-amber-600" />
          <p className="text-sm text-slate-700">
            Show your appreciation for great service at <span className="font-semibold">{restaurant.name}</span>
          </p>
        </div>

        {/* Quick Tip Buttons */}
        <div className="space-y-4">
          <Label className="text-base font-semibold">Quick Tip Options</Label>
          <div className="grid grid-cols-3 gap-3">
            {tipSuggestions.map((percentage) => {
              const amount = calculateTipAmount(percentage);
              const isSelected = Math.abs(tipAmount - amount) < 0.01;
              
              return (
                <motion.div key={percentage} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant={isSelected ? 'default' : 'outline'}
                    onClick={() => setTipByPercentage(percentage)}
                    className={`h-16 flex flex-col gap-1 ${
                      isSelected ? 'text-white hover:opacity-90' : ''
                    }`}
                    style={isSelected ? {backgroundColor: brandColor} : {}}
                  >
                    <span className="text-lg font-bold">{percentage}%</span>
                    <span className="text-xs opacity-70">AED {amount.toFixed(2)}</span>
                  </Button>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Custom Tip */}
        <div className="space-y-3">
          <Label className="text-base font-semibold">Custom Tip Amount</Label>
          <div className="flex gap-3">
            <div className="flex-1">
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-600">
                  AED
                </span>
                <Input
                  type="number"
                  step="0.50"
                  min="0"
                  placeholder="0.00"
                  value={tipAmount || ''}
                  onChange={(e) => setCustomTip(parseFloat(e.target.value) || 0)}
                  className="pl-12 text-lg font-medium"
                />
              </div>
              {tipAmount > 0 && (
                <p className="text-xs text-slate-500 mt-1">
                  {customTipPercentage.toFixed(1)}% of your bill
                </p>
              )}
            </div>
            
            {tipAmount > 0 && (
              <Button
                variant="outline"
                onClick={() => setCustomTip(0)}
                className="px-4"
              >
                Clear
              </Button>
            )}
          </div>
        </div>

        {/* Tip Appreciation */}
        {tipAmount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center p-4 bg-green-50 rounded-lg border border-green-200"
          >
            <Coffee className="w-6 h-6 mx-auto mb-2 text-green-600" />
            <p className="text-sm text-green-800 font-medium">
              Thank you for your generosity! 
              <br />
              <span className="text-xs">Your tip goes directly to the service staff</span>
            </p>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
