
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Receipt, Loader2, Lock } from "lucide-react";

export default function PaymentSummary({ 
  order, 
  tipAmount, 
  paymentType, 
  splitDetails, 
  onPayment, 
  isProcessing, 
  customerInfo,
  brandColor // Added brandColor prop
}) {
  // Calculate the base total of the order (items + any fixed charges/taxes included in order.total), before tip.
  // The outline refers to this as 'subtotal' in the display.
  const subtotal = order.total || 0; 
  
  // Calculate the final total including the tip amount
  const total = subtotal + tipAmount;

  // Helper function to sum up amounts assigned in a split payment
  const getTotalSplitAmount = () => {
    return splitDetails.reduce((sum, split) => sum + (Number(split.amount) || 0), 0);
  };

  // Helper function to calculate the remaining amount to be assigned/paid in a split payment
  const getRemainingAmount = () => {
    return total - getTotalSplitAmount();
  };

  // Determine if the pay button should be disabled
  const isPayButtonDisabled = isProcessing || 
                             (paymentType === 'split' && getRemainingAmount() !== 0) || // For split, ensure all amount is assigned
                             !customerInfo.email; // Customer email is required to proceed

  return (
    <Card className="shadow-xl border-2" style={{borderColor: brandColor}}>
      <CardHeader className="text-white rounded-t-lg" style={{backgroundColor: brandColor}}>
        <CardTitle className="flex items-center justify-between">
          <span>Your Bill</span>
          <Receipt className="w-5 h-5" />
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {/* Simplified bill breakdown section */}
        <div className="space-y-2 text-sm text-slate-600">
          <div className="flex justify-between">
            <span>Subtotal</span> {/* This 'Subtotal' represents the order's total before tip */}
            <span>AED {subtotal.toFixed(2)}</span>
          </div>
          {tipAmount > 0 && (
            <div className="flex justify-between">
              <span>Tip</span>
              <span>AED {tipAmount.toFixed(2)}</span>
            </div>
          )}
        </div>
        <Separator />
        
        {/* Conditional rendering for split vs. normal payment summary */}
        {paymentType === 'split' ? (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-800">Split Summary</h4>
            <div className="space-y-2 text-sm text-slate-600">
              <div className="flex justify-between">
                <span>Total Bill</span> {/* Total bill for split context, typically including tip */}
                <span>AED {total.toFixed(2)}</span> {/* Should reflect the 'total' including tip */}
              </div>
              <div className="flex justify-between">
                <span>Amount Assigned</span>
                <span>AED {getTotalSplitAmount().toFixed(2)}</span>
              </div>
            </div>
            <Separator />
            <div className="flex justify-between text-lg font-bold text-slate-900">
              <span>Remaining</span>
              <span className={getRemainingAmount() === 0 ? 'text-green-600' : 'text-amber-600'}>
                AED {getRemainingAmount().toFixed(2)}
              </span>
            </div>
          </div>
        ) : (
          <div className="flex justify-between text-xl font-bold text-slate-900">
            <span>Total to Pay</span>
            <span style={{color: brandColor}}>AED {total.toFixed(2)}</span>
          </div>
        )}

        {/* Message displayed if customer email is missing */}
        {!customerInfo.email && (
          <p className="text-xs text-red-600 text-center">Please enter your email to proceed.</p>
        )}

        {/* Pay Button */}
        <Button 
          onClick={onPayment}
          disabled={isPayButtonDisabled}
          className="w-full h-12 text-lg"
          style={{backgroundColor: brandColor}} // Apply brandColor to button background
        >
          {isProcessing ? (
            <Loader2 className="w-6 h-6 animate-spin" />
          ) : (
            `Pay AED ${paymentType === 'split' ? getTotalSplitAmount().toFixed(2) : total.toFixed(2)}`
          )}
        </Button>
        {/* Secure payment information */}
        <p className="text-xs text-slate-500 text-center flex items-center justify-center gap-1">
          <Lock className="w-3 h-3" /> Secure Payment via Qlub
        </p>
      </CardContent>
    </Card>
  );
}
