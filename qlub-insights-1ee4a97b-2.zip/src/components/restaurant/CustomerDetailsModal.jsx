
import React, { useState, useEffect, useCallback } from 'react';
import { Order, CustomerFeedback } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DollarSign, ShoppingCart, Star, Clock, Mail, Phone } from "lucide-react";
import { format } from 'date-fns';
import { Separator } from '@/components/ui/separator';

export default function CustomerDetailsModal({ customer, isOpen, onClose, restaurantId }) {
  const [orders, setOrders] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadCustomerData = useCallback(async () => {
    if (!customer) return; // Add check to prevent errors if customer is null/undefined
    setIsLoading(true);
    try {
      const [orderData, feedbackData] = await Promise.all([
        Order.filter({ restaurant_id: restaurantId, customer_email: customer.email }, '-created_date', 10),
        CustomerFeedback.filter({ restaurant_id: restaurantId, customer_email: customer.email }, '-created_date', 5)
      ]);
      setOrders(orderData);
      setFeedback(feedbackData);
    } catch (error) {
      console.error("Error loading customer details:", error);
    }
    setIsLoading(false);
  }, [restaurantId, customer]); // Dependencies for useCallback

  useEffect(() => {
    if (isOpen) { // Only load data when the modal is open
      loadCustomerData();
    }
  }, [isOpen, loadCustomerData]); // Dependencies for useEffect

  if (!customer) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="text-2xl">{customer.name?.[0] || 'C'}</AvatarFallback>
            </Avatar>
            <div>
              <DialogTitle className="text-2xl">{customer.name}</DialogTitle>
              <DialogDescription>{customer.email}</DialogDescription>
              <div className="mt-2">
                {customer.tags?.map(tag => <Badge key={tag} variant="secondary" className="capitalize">{tag}</Badge>)}
              </div>
            </div>
          </div>
        </DialogHeader>
        <div className="grid md:grid-cols-3 gap-6 mt-4 max-h-[70vh] overflow-y-auto p-1">
          {/* Left Column - Stats */}
          <div className="md:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Lifetime Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3"><DollarSign className="w-4 h-4 text-slate-500" /><span>Total Spent</span></div>
                  <span className="font-bold">AED {customer.total_spent.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3"><ShoppingCart className="w-4 h-4 text-slate-500" /><span>Total Orders</span></div>
                  <span className="font-bold">{customer.order_count}</span>
                </div>
                 <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3"><Clock className="w-4 h-4 text-slate-500" /><span>Last Visit</span></div>
                  <span className="font-bold">{format(new Date(customer.last_visit_date), 'MMM d, yyyy')}</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contact Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                 <div className="flex items-center gap-3"><Mail className="w-4 h-4 text-slate-500" /><span>{customer.email}</span></div>
                 {customer.phone && <div className="flex items-center gap-3"><Phone className="w-4 h-4 text-slate-500" /><span>{customer.phone}</span></div>}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - History */}
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader><CardTitle className="text-lg">Recent Orders</CardTitle></CardHeader>
              <CardContent>
                {isLoading ? <p>Loading...</p> : orders.length > 0 ? (
                  <ul className="space-y-3">
                    {orders.map(order => (
                      <li key={order.id} className="flex justify-between items-center text-sm">
                        <div>
                          <p className="font-medium">Order #{order.id.slice(-6)}</p>
                          <p className="text-slate-500">{order.items.length} items</p>
                        </div>
                        <div>
                           <p className="font-semibold">AED {order.total.toFixed(2)}</p>
                           <p className="text-slate-500 text-right">{format(new Date(order.created_date), 'MMM d')}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : <p className="text-slate-500 text-center py-4">No recent orders found.</p>}
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-lg">Recent Feedback</CardTitle></CardHeader>
              <CardContent>
                 {isLoading ? <p>Loading...</p> : feedback.length > 0 ? (
                  <ul className="space-y-4">
                    {feedback.map(fb => (
                      <li key={fb.id}>
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => <Star key={i} className={`w-4 h-4 ${i < fb.rating ? 'text-amber-400' : 'text-slate-300'}`} fill={i < fb.rating ? 'currentColor' : 'none'} />)}
                          </div>
                          <p className="text-xs text-slate-500">{format(new Date(fb.created_date), 'MMM d, yyyy')}</p>
                        </div>
                        <p className="text-sm text-slate-600 bg-slate-50 p-2 rounded-md">{fb.comment}</p>
                      </li>
                    ))}
                  </ul>
                ) : <p className="text-slate-500 text-center py-4">No feedback submitted.</p>}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
