import React, { useState, useEffect } from "react";
import { Promotion } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon, Save, X } from "lucide-react";
import { format } from "date-fns";

export default function PromotionFormModal({ isOpen, onClose, promotion, restaurantId, onSave }) {
  const [form, setForm] = useState({
    code: "",
    description: "",
    discount_type: "percentage",
    discount_value: 10,
    is_active: true,
    valid_from: null,
    valid_to: null,
    usage_limit: "",
  });

  useEffect(() => {
    if (promotion) {
      setForm({
        code: promotion.code || "",
        description: promotion.description || "",
        discount_type: promotion.discount_type || "percentage",
        discount_value: promotion.discount_value ?? 10,
        is_active: promotion.is_active ?? true,
        valid_from: promotion.valid_from ? new Date(promotion.valid_from) : null,
        valid_to: promotion.valid_to ? new Date(promotion.valid_to) : null,
        usage_limit: promotion.usage_limit ?? "",
      });
    } else {
      setForm({
        code: "",
        description: "",
        discount_type: "percentage",
        discount_value: 10,
        is_active: true,
        valid_from: null,
        valid_to: null,
        usage_limit: "",
      });
    }
  }, [promotion]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    const payload = {
      code: form.code.trim(),
      description: form.description,
      discount_type: form.discount_type,
      discount_value: Number(form.discount_value) || 0,
      is_active: !!form.is_active,
      valid_from: form.valid_from ? new Date(form.valid_from).toISOString() : null,
      valid_to: form.valid_to ? new Date(form.valid_to).toISOString() : null,
      usage_limit: form.usage_limit !== "" ? Number(form.usage_limit) : null,
      ...(restaurantId ? { restaurant_id: restaurantId } : {}),
    };

    if (promotion?.id) {
      await Promotion.update(promotion.id, payload);
    } else {
      await Promotion.create(payload);
    }
    onSave?.();
    onClose?.();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose?.()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{promotion ? "Edit Promotion" : "Create Promotion"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Code</Label>
              <Input name="code" value={form.code} onChange={handleChange} placeholder="SUMMER20" />
            </div>
            <div className="space-y-2">
              <Label>Discount Type</Label>
              <Select value={form.discount_type} onValueChange={(v) => setForm((p) => ({ ...p, discount_type: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Percentage (%)</SelectItem>
                  <SelectItem value="fixed_amount">Fixed Amount (AED)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Discount Value</Label>
              <Input
                type="number"
                name="discount_value"
                value={form.discount_value}
                onChange={handleChange}
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label>Usage Limit (optional)</Label>
              <Input
                type="number"
                name="usage_limit"
                value={form.usage_limit}
                onChange={handleChange}
                min="0"
                placeholder="e.g. 100"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              placeholder="Describe the promotion"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Valid From</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {form.valid_from ? format(form.valid_from, "PP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Calendar
                    mode="single"
                    selected={form.valid_from}
                    onSelect={(d) => setForm((p) => ({ ...p, valid_from: d }))}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label>Valid To</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {form.valid_to ? format(form.valid_to, "PP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Calendar
                    mode="single"
                    selected={form.valid_to}
                    onSelect={(d) => setForm((p) => ({ ...p, valid_to: d }))}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="flex items-center justify-between border rounded-md p-3">
            <div>
              <Label className="block">Active</Label>
              <p className="text-xs text-slate-500">Toggle to enable or pause the promotion.</p>
            </div>
            <Switch checked={!!form.is_active} onCheckedChange={(v) => setForm((p) => ({ ...p, is_active: v }))} />
          </div>
        </div>

        <DialogFooter className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}