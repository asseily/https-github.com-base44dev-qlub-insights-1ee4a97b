
import React, { useEffect, useState, useCallback } from "react";
import { PaymentLink, Payment, Order } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { createPageUrl } from "@/utils";
import {
  Plus,
  Copy,
  Share2,
  Link as LinkIcon,
  Download,
  Loader2,
  Trash2,
  RefreshCw,
  Filter,
  Mail,
  MessageSquare
} from "lucide-react";

export default function PaymentLinksManager({ restaurant }) {
  const [links, setLinks] = useState([]);
  const [payments, setPayments] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");
  const currency = restaurant?.settings?.currency || "AED";

  const [form, setForm] = useState({
    amount: "",
    currency: restaurant?.settings?.currency || "AED",
    link_type: "one_time",
    reference: "",
    description: "",
    order_id: "", // use empty string for "None"
    max_usage: 1,
    expires_at: ""
  });

  const buildShareUrl = (id) => {
    return window.location.origin + createPageUrl(`PaymentPortal?payment_link_id=${id}`);
  };

  const load = useCallback(async () => {
    if (!restaurant?.id) return;
    setIsLoading(true);
    const [linksData, paymentsData, ordersData] = await Promise.all([
      PaymentLink.filter({ restaurant_id: restaurant.id }, "-created_date", 500),
      Payment.filter({ restaurant_id: restaurant.id }, "-created_date", 500),
      Order.filter({ restaurant_id: restaurant.id }, "-created_date", 300)
    ]);
    setLinks(linksData);
    setPayments(paymentsData);
    setOrders(ordersData);
    setIsLoading(false);
  }, [restaurant?.id]);

  useEffect(() => {
    load();
  }, [load]);

  if (isLoading) {
    return (
      <div className="py-16 flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-600">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>Loading payment links...</span>
        </div>
      </div>
    );
  }

  const createLink = async () => {
    if (!restaurant?.id) return;
    setCreating(true);
    const payload = {
      restaurant_id: restaurant.id,
      amount: Number(form.amount || 0),
      currency: form.currency || "AED",
      link_type: form.link_type || "one_time",
      status: "active",
      reference: form.reference || undefined,
      description: form.description || undefined,
      order_id: form.order_id ? form.order_id : undefined, // empty string treated as undefined
      max_usage: Number(form.max_usage || 1),
      expires_at: form.expires_at ? new Date(form.expires_at).toISOString() : undefined
    };
    const created = await PaymentLink.create(payload);
    const shareUrl = buildShareUrl(created.id);
    await PaymentLink.update(created.id, { generated_url: shareUrl });
    setForm({
      amount: "",
      currency: restaurant?.settings?.currency || "AED",
      link_type: "one_time",
      reference: "",
      description: "",
      order_id: "",
      max_usage: 1,
      expires_at: ""
    });
    setCreating(false);
    load();
  };

  const cancelLink = async (link) => {
    await PaymentLink.update(link.id, { ...link, status: "cancelled" });
    load();
  };

  const copyToClipboard = async (text) => {
    await navigator.clipboard.writeText(text);
    alert("Copied to clipboard");
  };

  const shareLink = async (url) => {
    if (navigator.share) {
      try {
        await navigator.share({ title: "Payment Link", text: "Please complete the payment:", url });
        return;
      } catch (error) {
        // Fallback to copy if share fails or is cancelled
        console.error("Web Share API failed:", error);
      }
    }
    copyToClipboard(url);
  };

  const emailLink = (url) => {
    const subject = encodeURIComponent("Payment Link");
    const body = encodeURIComponent(`Please complete your payment here: ${url}`);
    window.open(`mailto:?subject=${subject}&body=${body}`, "_blank");
  };

  const whatsappLink = (url) => {
    const text = encodeURIComponent(`Please complete your payment here: ${url}`);
    window.open(`https://wa.me/?text=${text}`, "_blank");
  };

  const filteredLinks = links.filter((l) => {
    const matchesStatus = statusFilter === "all" ? true : l.status === statusFilter;
    const term = search.trim().toLowerCase();
    const matchesSearch = !term
      ? true
      : (l.reference || "").toLowerCase().includes(term) ||
        (l.description || "").toLowerCase().includes(term) ||
        (l.generated_url || "").toLowerCase().includes(term) ||
        (l.id || "").toLowerCase().includes(term);
    return matchesStatus && matchesSearch;
  });

  const exportLinksCSV = () => {
    const headers = [
      "ID",
      "Status",
      "Amount",
      "Currency",
      "Type",
      "Reference",
      "Description",
      "Order ID",
      "Max Usage",
      "Usage Count",
      "URL",
      "Created",
      "Expires At"
    ];
    const rows = filteredLinks.map((l) => [
      l.id,
      l.status,
      (l.amount ?? 0).toFixed(2),
      l.currency || "",
      l.link_type || "",
      l.reference || "",
      l.description || "",
      l.order_id || "",
      l.max_usage ?? "",
      l.usage_count ?? 0,
      l.generated_url || buildShareUrl(l.id),
      l.created_date ? new Date(l.created_date).toLocaleString() : "",
      l.expires_at ? new Date(l.expires_at).toLocaleString() : ""
    ]);
    const csv =
      [headers, ...rows]
        .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
        .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `payment_links_${restaurant?.name?.replace(/\s+/g, "_") || "export"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportPaymentsCSV = () => {
    const headers = [
      "Payment ID",
      "Order ID",
      "Amount",
      "Tip",
      "Method",
      "Status",
      "Created"
    ];
    const rows = payments.map((p) => [
      p.id,
      p.order_id || "",
      (p.amount ?? 0).toFixed(2),
      (p.tip_amount ?? 0).toFixed(2),
      p.payment_method || "",
      p.status || "",
      p.created_date ? new Date(p.created_date).toLocaleString() : ""
    ]);
    const csv =
      [headers, ...rows]
        .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
        .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `payments_${restaurant?.name?.replace(/\s+/g, "_") || "export"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const statusBadge = (s) => {
    switch (s) {
      case "active":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "paid":
        return "bg-emerald-100 text-emerald-800 border-emerald-200";
      case "expired":
        return "bg-amber-100 text-amber-800 border-amber-200";
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Payment Links</h2>
          <p className="text-slate-600 text-lg">Create, share, and track payment links.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={load}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" onClick={exportLinksCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export Links CSV
          </Button>
        </div>
      </div>

      <Tabs defaultValue="manage" className="space-y-6">
        <TabsList className="bg-white p-1 shadow-sm border border-slate-200 rounded-lg">
          <TabsTrigger value="manage">Manage Links</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
        </TabsList>

        <TabsContent value="manage" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-purple-600" />
                Create Payment Link
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    value={form.amount}
                    onChange={(e) => setForm({ ...form, amount: e.target.value })}
                    placeholder="Enter amount"
                  />
                </div>
                <div>
                  <Label>Currency</Label>
                  <Input
                    value={form.currency}
                    onChange={(e) => setForm({ ...form, currency: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Link Type</Label>
                  <Select
                    value={form.link_type}
                    onValueChange={(v) => setForm({ ...form, link_type: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="one_time">One-time</SelectItem>
                      <SelectItem value="multi_use">Multi-use</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Max Usage</Label>
                  <Input
                    type="number"
                    min="1"
                    value={form.max_usage}
                    onChange={(e) => setForm({ ...form, max_usage: e.target.value })}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Link Reference (optional)</Label>
                  <Input
                    value={form.reference}
                    onChange={(e) => setForm({ ...form, reference: e.target.value })}
                    placeholder="Internal reference"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Description (optional)</Label>
                  <Input
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Shown to customer"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Expiration (optional)</Label>
                  <Input
                    type="datetime-local"
                    value={form.expires_at}
                    onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Attach to Order (optional)</Label>
                  <Select
                    value={form.order_id}
                    onValueChange={(v) => setForm({ ...form, order_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select an order (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      {orders.slice(0, 100).map((o) => (
                        <SelectItem key={o.id} value={o.id}>
                          #{o.id.slice(-5)} · {o.status} · {currency} {(o.total ?? o.subtotal ?? 0).toFixed(2)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  className="bg-purple-600 hover:bg-purple-700"
                  onClick={createLink}
                  disabled={creating || !form.amount}
                >
                  {creating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                  {creating ? "Creating..." : "Generate Payment Link"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-slate-600" />
                Links
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="flex-1">
                  <Input
                    placeholder="Search by reference, description, or URL..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="grid gap-4">
                {filteredLinks.length === 0 && (
                  <div className="text-slate-500 text-sm">No payment links found.</div>
                )}
                {filteredLinks.map((l) => {
                  const url = l.generated_url || buildShareUrl(l.id);
                  const isExpired = l.expires_at ? new Date(l.expires_at).getTime() < Date.now() : false;
                  return (
                    <div key={l.id} className="rounded-lg border p-4 bg-white flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge className={statusBadge(l.status)} variant="outline">
                            {l.status}
                          </Badge>
                          {isExpired && (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                              expired
                            </Badge>
                          )}
                          <span className="text-slate-900 font-semibold">
                            {currency} {(l.amount ?? 0).toFixed(2)} {l.currency || ""}
                          </span>
                          <span className="text-xs text-slate-500">· {l.link_type}</span>
                        </div>
                        <div className="text-sm text-slate-600">
                          {l.reference || "No reference"} · {l.description || "No description"}
                        </div>
                        <div className="text-xs text-slate-500 break-all">
                          {url}
                        </div>
                        {l.expires_at && (
                          <div className="text-xs text-slate-500">
                            Expires: {new Date(l.expires_at).toLocaleString()}
                          </div>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" onClick={() => window.open(url, "_blank")}>
                          <LinkIcon className="w-4 h-4 mr-1" /> Open
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => copyToClipboard(url)}>
                          <Copy className="w-4 h-4 mr-1" /> Copy
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => shareLink(url)}>
                          <Share2 className="w-4 h-4 mr-1" /> Share
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => whatsappLink(url)}>
                          <MessageSquare className="w-4 h-4 mr-1" /> WhatsApp
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => emailLink(url)}>
                          <Mail className="w-4 h-4 mr-1" /> Email
                        </Button>
                        {l.status === "active" && (
                          <Button variant="destructive" size="sm" onClick={() => cancelLink(l)}>
                            <Trash2 className="w-4 h-4 mr-1" /> Cancel
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-slate-900">Transaction Tracking</h3>
            <Button variant="outline" onClick={exportPaymentsCSV}>
              <Download className="w-4 h-4 mr-2" />
              Export Payments CSV
            </Button>
          </div>

          <Card className="shadow-lg">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="text-left p-3">Payment ID</th>
                      <th className="text-left p-3">Order</th>
                      <th className="text-right p-3">Amount</th>
                      <th className="text-right p-3">Tip</th>
                      <th className="text-left p-3">Method</th>
                      <th className="text-left p-3">Status</th>
                      <th className="text-left p-3">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-6 text-center text-slate-500">No transactions yet.</td>
                      </tr>
                    )}
                    {payments.map((p) => (
                      <tr key={p.id} className="border-t">
                        <td className="p-3 font-mono">{p.id.slice(-8)}</td>
                        <td className="p-3">{p.order_id ? `#${p.order_id.slice(-5)}` : "-"}</td>
                        <td className="p-3 text-right">{currency} {(p.amount ?? 0).toFixed(2)}</td>
                        <td className="p-3 text-right">{currency} {(p.tip_amount ?? 0).toFixed(2)}</td>
                        <td className="p-3 capitalize">{p.payment_method?.replace("_"," ") || "-"}</td>
                        <td className="p-3">
                          <Badge variant="outline" className={p.status === "completed" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-slate-50 text-slate-700 border-slate-200"}>
                            {p.status}
                          </Badge>
                        </td>
                        <td className="p-3">{p.created_date ? new Date(p.created_date).toLocaleString() : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
