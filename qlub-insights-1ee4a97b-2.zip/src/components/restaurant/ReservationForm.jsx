import React, { useEffect, useState } from "react";
import { Reservation } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon, Save, X } from "lucide-react";
import { format } from "date-fns";

export default function ReservationForm({ reservation, restaurant, tables, onClose, onSave }) {
  const [form, setForm] = useState({
    customer_name: "",
    customer_phone: "",
    customer_email: "",
    party_size: 2,
    reservation_date: null, // date object
    reservation_time: "19:00",
    table_preference: "",
    special_requests: "",
    status: "pending",
  });

  useEffect(() => {
    if (reservation) {
      const d = reservation.reservation_date ? new Date(reservation.reservation_date) : null;
      const timeStr = d ? `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}` : "19:00";
      setForm({
        customer_name: reservation.customer_name || "",
        customer_phone: reservation.customer_phone || "",
        customer_email: reservation.customer_email || "",
        party_size: reservation.party_size ?? 2,
        reservation_date: d,
        reservation_time: timeStr,
        table_preference: reservation.table_preference || "",
        special_requests: reservation.special_requests || "",
        status: reservation.status || "pending",
      });
    } else {
      setForm({
        customer_name: "",
        customer_phone: "",
        customer_email: "",
        party_size: 2,
        reservation_date: null,
        reservation_time: "19:00",
        table_preference: "",
        special_requests: "",
        status: "pending",
      });
    }
  }, [reservation]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  const buildReservationDateTimeISO = () => {
    if (!form.reservation_date) return null;
    const [h, m] = (form.reservation_time || "19:00").split(":").map(Number);
    const d = new Date(form.reservation_date);
    d.setHours(h);
    d.setMinutes(m);
    d.setSeconds(0);
    d.setMilliseconds(0);
    return d.toISOString();
  };

  const handleSubmit = async () => {
    const payload = {
      restaurant_id: restaurant?.id,
      customer_name: form.customer_name.trim(),
      customer_phone: form.customer_phone.trim(),
      customer_email: form.customer_email.trim() || null,
      party_size: Number(form.party_size) || 1,
      reservation_date: buildReservationDateTimeISO(),
      table_preference: form.table_preference || null,
      special_requests: form.special_requests || null,
      status: form.status,
      source: "website",
    };

    if (reservation?.id) {
      await Reservation.update(reservation.id, payload);
    } else {
      await Reservation.create(payload);
    }
    onSave?.();
    onClose?.();
  };

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose?.()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{reservation ? "Edit Reservation" : "New Reservation"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input name="customer_name" value={form.customer_name} onChange={handleChange} />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input name="customer_phone" value={form.customer_phone} onChange={handleChange} />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Email (optional)</Label>
              <Input type="email" name="customer_email" value={form.customer_email} onChange={handleChange} />
            </div>
            <div className="space-y-2">
              <Label>Party Size</Label>
              <Input type="number" name="party_size" min="1" value={form.party_size} onChange={handleChange} />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {form.reservation_date ? format(form.reservation_date, "PP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Calendar
                    mode="single"
                    selected={form.reservation_date}
                    onSelect={(d) => setForm((p) => ({ ...p, reservation_date: d }))}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label>Time</Label>
              <Input type="time" name="reservation_time" value={form.reservation_time} onChange={handleChange} />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Table Preference (optional)</Label>
            <Input name="table_preference" value={form.table_preference} onChange={handleChange} placeholder="Window, booth, etc." />
          </div>

          <div className="space-y-2">
            <Label>Special Requests</Label>
            <Textarea name="special_requests" value={form.special_requests} onChange={handleChange} placeholder="Allergies, occasions, etc." />
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm((p) => ({ ...p, status: v }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">pending</SelectItem>
                <SelectItem value="confirmed">confirmed</SelectItem>
                <SelectItem value="cancelled">cancelled</SelectItem>
                <SelectItem value="no_show">no_show</SelectItem>
                <SelectItem value="completed">completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}