import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, XCircle, Users, MapPin } from "lucide-react";

export default function TableForm({ table, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(table || {
    table_number: '',
    capacity: 4,
    location: '',
    status: 'available'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="shadow-xl border-0 bg-gradient-to-br from-white to-slate-50">
      <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-lg">
        <CardTitle className="text-xl flex items-center gap-3">
          <Users className="w-6 h-6" />
          {table ? 'Edit Table' : 'Add New Table'}
        </CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6 p-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="table_number" className="text-sm font-semibold text-slate-700">
                Table Number
              </Label>
              <Input
                id="table_number"
                value={formData.table_number}
                onChange={(e) => setFormData(prev => ({...prev, table_number: e.target.value}))}
                placeholder="e.g. T01, A5, 101"
                className="text-lg py-3"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="capacity" className="text-sm font-semibold text-slate-700">
                Seating Capacity
              </Label>
              <Select 
                value={formData.capacity.toString()} 
                onValueChange={(value) => setFormData(prev => ({...prev, capacity: parseInt(value)}))}
              >
                <SelectTrigger className="py-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16].map(num => (
                    <SelectItem key={num} value={num.toString()}>
                      {num} {num === 1 ? 'Guest' : 'Guests'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="location" className="text-sm font-semibold text-slate-700">
                Location Description
              </Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({...prev, location: e.target.value}))}
                placeholder="e.g. Window side, Private booth, Terrace"
                className="py-3"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status" className="text-sm font-semibold text-slate-700">
                Initial Status
              </Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => setFormData(prev => ({...prev, status: value}))}
              >
                <SelectTrigger className="py-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">🟢 Available</SelectItem>
                  <SelectItem value="occupied">🔴 Occupied</SelectItem>
                  <SelectItem value="reserved">🔵 Reserved</SelectItem>
                  <SelectItem value="cleaning">🟡 Cleaning</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Preview */}
          <div className="p-6 bg-slate-50 rounded-xl border-2 border-slate-200">
            <h4 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Table Preview
            </h4>
            <div className="bg-white p-4 rounded-lg border border-slate-200">
              <div className="flex justify-between items-center">
                <div>
                  <h5 className="font-bold text-lg">Table {formData.table_number || '[Number]'}</h5>
                  <p className="text-slate-600">{formData.location || 'No location specified'}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-600">Capacity</p>
                  <p className="font-bold">{formData.capacity} guests</p>
                </div>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              * A unique QR code will be automatically generated for this table
            </p>
          </div>
        </CardContent>

        <CardFooter className="flex justify-end gap-4 p-8 bg-slate-50 rounded-b-lg">
          <Button type="button" variant="outline" onClick={onCancel} className="px-8">
            <XCircle className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-purple-600 hover:bg-purple-700 px-8">
            <Save className="w-4 h-4 mr-2" />
            {table ? 'Update Table' : 'Create Table'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}