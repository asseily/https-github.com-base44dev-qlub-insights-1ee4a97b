
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table as UITable, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Plus, Building2, Edit, ToggleLeft, ToggleRight, Download } from "lucide-react";
import { Location } from "@/api/entities";
import LocationForm from "./LocationForm";

export default function LocationManagement({ restaurant, locations, refreshData }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const activeCount = locations.filter(l => l.is_active).length;

  const toggleActive = async (loc) => {
    await Location.update(loc.id, { ...loc, is_active: !loc.is_active });
    refreshData();
  };

  // NEW: Export locations to CSV
  const exportLocationsCSV = () => {
    const headers = ["Name", "Address", "Phone", "Manager Email", "Active", "Operating Hours (Mon-Sun)", "Delivery Radius (km)", "Accepts Reservations"];
    const rows = locations.map(l => {
      const hours = l.settings?.operating_hours || {};
      const hoursStr = [
        hours.monday || "", hours.tuesday || "", hours.wednesday || "",
        hours.thursday || "", hours.friday || "", hours.saturday || "", hours.sunday || ""
      ].join("|");
      return [
        l.location_name || "",
        l.address || "",
        l.phone || "",
        l.manager_email || "",
        l.is_active ? "Yes" : "No",
        hoursStr,
        l.settings?.delivery_radius != null ? l.settings.delivery_radius : "",
        l.settings?.accepts_reservations ? "Yes" : "No"
      ];
    });
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `locations_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Locations</h2>
          <p className="text-slate-600 text-lg">Manage multiple branches for your restaurant</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportLocationsCSV}>
            <Download className="w-4 h-4 mr-2" /> Export CSV
          </Button>
          <Button onClick={() => setShowForm(true)} className="bg-purple-600 hover:bg-purple-700">
            <Plus className="w-4 h-4 mr-2" /> Add Location
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm">Active Locations</p>
              <p className="text-2xl font-bold">{activeCount}</p>
            </div>
            <Building2 className="w-8 h-8 text-emerald-500" />
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm">Total Locations</p>
              <p className="text-2xl font-bold">{locations.length}</p>
            </div>
            <MapPin className="w-8 h-8 text-blue-500" />
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <p className="text-slate-600 text-sm mb-1">Reservation Acceptance</p>
            <p className="text-slate-900 font-semibold">Per-location settings supported</p>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Location Directory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <UITable>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead>Name</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Manager</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {locations.map(loc => (
                  <TableRow key={loc.id}>
                    <TableCell className="font-medium">{loc.location_name}</TableCell>
                    <TableCell className="max-w-xs truncate">{loc.address}</TableCell>
                    <TableCell>{loc.phone || "—"}</TableCell>
                    <TableCell>{loc.manager_email || "—"}</TableCell>
                    <TableCell>
                      <Badge className={loc.is_active ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-800"}>
                        {loc.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => { setEditing(loc); setShowForm(true); }}>
                          <Edit className="w-4 h-4 mr-1" /> Edit
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => toggleActive(loc)}>
                          {loc.is_active ? <ToggleLeft className="w-4 h-4" /> : <ToggleRight className="w-4 h-4" />}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {locations.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-slate-500">No locations yet. Click "Add Location" to create your first branch.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </UITable>
          </div>
        </CardContent>
      </Card>

      {showForm && (
        <LocationForm
          restaurant={restaurant}
          location={editing}
          onClose={() => { setShowForm(false); setEditing(null); }}
          onSaved={refreshData}
        />
      )}
    </div>
  );
}
