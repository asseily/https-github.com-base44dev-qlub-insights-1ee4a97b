import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  Users, 
  DollarSign, 
  MessageSquare,
  ChevronRight,
  AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";
import { formatDistance } from "date-fns";

export default function OrderCard({ order, onStatusChange, onClick, getStatusColor }) {
  const getTimeElapsed = () => {
    return formatDistance(new Date(order.created_date), new Date(), { addSuffix: true });
  };

  const getNextStatus = () => {
    switch(order.status) {
      case 'pending': return 'confirmed';
      case 'confirmed': return 'preparing';
      case 'preparing': return 'ready';
      case 'ready': return 'served';
      default: return null;
    }
  };

  const getStatusAction = () => {
    switch(order.status) {
      case 'pending': return 'Confirm Order';
      case 'confirmed': return 'Start Preparing';
      case 'preparing': return 'Mark Ready';
      case 'ready': return 'Mark Served';
      default: return null;
    }
  };

  const isUrgent = () => {
    const elapsed = new Date() - new Date(order.created_date);
    const minutes = elapsed / (1000 * 60);
    return minutes > 15 && ['pending', 'confirmed', 'preparing'].includes(order.status);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card 
        className={`shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden ${
          isUrgent() ? 'ring-2 ring-red-400 ring-opacity-60' : ''
        }`}
        onClick={onClick}
      >
        <CardHeader className="bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <span className="font-mono text-purple-600">#{order.id.slice(-6)}</span>
                {isUrgent() && <AlertTriangle className="w-4 h-4 text-red-500" />}
              </CardTitle>
              <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>Table {order.table_id}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{getTimeElapsed()}</span>
                </div>
              </div>
            </div>
            <Badge className={getStatusColor(order.status)}>
              {order.status.replace('_', ' ')}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-4">
          {/* Customer Info */}
          <div className="flex justify-between items-center">
            <span className="font-medium text-slate-900">
              {order.customer_name || 'Guest'}
            </span>
            <div className="flex items-center gap-1 text-emerald-600 font-bold">
              <DollarSign className="w-4 h-4" />
              <span>AED {order.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Order Items Summary */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-700">
              Items ({order.items?.length || 0})
            </h4>
            <div className="space-y-1">
              {order.items?.slice(0, 2).map((item, idx) => (
                <div key={idx} className="flex justify-between items-center text-sm">
                  <span className="text-slate-600">
                    {item.quantity}x {item.menu_item_name || 'Item'}
                  </span>
                  {item.special_instructions && (
                    <MessageSquare className="w-3 h-3 text-amber-500" />
                  )}
                </div>
              ))}
              {order.items?.length > 2 && (
                <p className="text-xs text-slate-500">
                  +{order.items.length - 2} more items
                </p>
              )}
            </div>
          </div>

          {/* Order Notes */}
          {order.notes && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-start gap-2">
                <MessageSquare className="w-4 h-4 text-amber-600 mt-0.5" />
                <p className="text-sm text-amber-800">{order.notes}</p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4 border-t border-slate-100">
            {getNextStatus() && (
              <Button
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onStatusChange(order.id, getNextStatus());
                }}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                {getStatusAction()}
              </Button>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                onClick();
              }}
              className="px-3"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Payment Status */}
          {order.payment_status !== 'paid' && (
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Payment Status:</span>
              <Badge variant="outline" className="text-xs">
                {order.payment_status}
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}