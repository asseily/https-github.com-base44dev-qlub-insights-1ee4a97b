import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  ChefHat, 
  AlertTriangle, 
  CheckCircle,
  Timer,
  MessageSquare,
  Play,
  Pause,
  Users
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistance } from "date-fns";

export default function KitchenDisplaySystem({ orders, onStatusChange, getStatusColor }) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedOrders, setSelectedOrders] = useState([]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const kitchenOrders = orders.filter(order => 
    ['confirmed', 'preparing', 'ready'].includes(order.status)
  ).sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  const getOrderPriority = (order) => {
    const elapsed = new Date() - new Date(order.created_date);
    const minutes = elapsed / (1000 * 60);
    
    if (minutes > 20) return 'urgent';
    if (minutes > 15) return 'high';
    if (minutes > 10) return 'medium';
    return 'normal';
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'urgent': return 'bg-red-100 border-red-300 text-red-800';
      case 'high': return 'bg-amber-100 border-amber-300 text-amber-800';
      case 'medium': return 'bg-blue-100 border-blue-300 text-blue-800';
      default: return 'bg-slate-100 border-slate-300 text-slate-800';
    }
  };

  const toggleOrderSelection = (orderId) => {
    setSelectedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    );
  };

  const bulkStatusChange = (newStatus) => {
    selectedOrders.forEach(orderId => {
      onStatusChange(orderId, newStatus);
    });
    setSelectedOrders([]);
  };

  const getTimeElapsed = (orderDate) => {
    return formatDistance(new Date(orderDate), currentTime, { addSuffix: true });
  };

  const getOrdersByStatus = (status) => {
    return kitchenOrders.filter(order => order.status === status);
  };

  return (
    <div className="space-y-8">
      {/* Kitchen Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
            <ChefHat className="w-8 h-8 text-purple-600" />
            Kitchen Display System
          </h2>
          <p className="text-slate-600">
            {kitchenOrders.length} active orders • Updated {currentTime.toLocaleTimeString()}
          </p>
        </div>
        
        {selectedOrders.length > 0 && (
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="text-sm">
              {selectedOrders.length} selected
            </Badge>
            <Button
              size="sm"
              onClick={() => bulkStatusChange('preparing')}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Play className="w-4 h-4 mr-1" />
              Start All
            </Button>
            <Button
              size="sm"
              onClick={() => bulkStatusChange('ready')}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle className="w-4 h-4 mr-1" />
              Complete All
            </Button>
          </div>
        )}
      </div>

      {/* Kitchen Board - Kanban Style */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* New Orders Column */}
        <div className="space-y-4">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Timer className="w-5 h-5" />
                New Orders ({getOrdersByStatus('confirmed').length})
              </CardTitle>
            </CardHeader>
          </Card>
          
          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            <AnimatePresence>
              {getOrdersByStatus('confirmed').map((order) => (
                <KitchenOrderCard
                  key={order.id}
                  order={order}
                  priority={getOrderPriority(order)}
                  isSelected={selectedOrders.includes(order.id)}
                  onSelect={() => toggleOrderSelection(order.id)}
                  onStatusChange={onStatusChange}
                  getTimeElapsed={getTimeElapsed}
                  getPriorityColor={getPriorityColor}
                  actionLabel="Start Cooking"
                  nextStatus="preparing"
                />
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Preparing Column */}
        <div className="space-y-4">
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <ChefHat className="w-5 h-5" />
                In Kitchen ({getOrdersByStatus('preparing').length})
              </CardTitle>
            </CardHeader>
          </Card>
          
          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            <AnimatePresence>
              {getOrdersByStatus('preparing').map((order) => (
                <KitchenOrderCard
                  key={order.id}
                  order={order}
                  priority={getOrderPriority(order)}
                  isSelected={selectedOrders.includes(order.id)}
                  onSelect={() => toggleOrderSelection(order.id)}
                  onStatusChange={onStatusChange}
                  getTimeElapsed={getTimeElapsed}
                  getPriorityColor={getPriorityColor}
                  actionLabel="Mark Ready"
                  nextStatus="ready"
                />
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Ready for Service Column */}
        <div className="space-y-4">
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Ready to Serve ({getOrdersByStatus('ready').length})
              </CardTitle>
            </CardHeader>
          </Card>
          
          <div className="space-y-4 max-h-[600px] overflow-y-auto">
            <AnimatePresence>
              {getOrdersByStatus('ready').map((order) => (
                <KitchenOrderCard
                  key={order.id}
                  order={order}
                  priority={getOrderPriority(order)}
                  isSelected={selectedOrders.includes(order.id)}
                  onSelect={() => toggleOrderSelection(order.id)}
                  onStatusChange={onStatusChange}
                  getTimeElapsed={getTimeElapsed}
                  getPriorityColor={getPriorityColor}
                  actionLabel="Mark Served"
                  nextStatus="served"
                  showPulse={getOrderPriority(order) === 'urgent'}
                />
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

function KitchenOrderCard({
  order,
  priority,
  isSelected,
  onSelect,
  onStatusChange,
  getTimeElapsed,
  getPriorityColor,
  actionLabel,
  nextStatus,
  showPulse = false
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      layout
    >
      <Card 
        className={`cursor-pointer transition-all duration-300 ${
          isSelected ? 'ring-2 ring-purple-500 shadow-lg' : 'hover:shadow-md'
        } ${getPriorityColor(priority)} ${showPulse ? 'animate-pulse' : ''}`}
        onClick={onSelect}
      >
        <CardContent className="p-4">
          {/* Order Header */}
          <div className="flex justify-between items-start mb-3">
            <div>
              <h3 className="font-mono text-lg font-bold">#{order.id.slice(-6)}</h3>
              <div className="flex items-center gap-3 text-sm opacity-80">
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>Table {order.table_id}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{getTimeElapsed(order.created_date)}</span>
                </div>
              </div>
            </div>
            
            {priority === 'urgent' && (
              <AlertTriangle className="w-5 h-5 text-red-600" />
            )}
          </div>

          {/* Customer Name */}
          <p className="font-medium mb-3">{order.customer_name || 'Guest'}</p>

          {/* Order Items */}
          <div className="space-y-2 mb-4">
            {order.items?.map((item, idx) => (
              <div key={idx} className="bg-white/50 rounded p-2">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <span className="font-medium">
                      {item.quantity}x {item.menu_item_name || 'Item'}
                    </span>
                    
                    {/* Modifiers */}
                    {item.selected_modifiers?.length > 0 && (
                      <div className="mt-1 space-y-1">
                        {item.selected_modifiers.map((mod, modIdx) => (
                          <p key={modIdx} className="text-xs opacity-75">
                            + {mod.modifier_name}: {mod.option_name}
                          </p>
                        ))}
                      </div>
                    )}

                    {/* Special Instructions */}
                    {item.special_instructions && (
                      <div className="mt-1 p-1 bg-amber-100 border border-amber-300 rounded text-xs">
                        <div className="flex items-start gap-1">
                          <MessageSquare className="w-3 h-3 text-amber-600 mt-0.5" />
                          <span className="text-amber-800">{item.special_instructions}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Notes */}
          {order.notes && (
            <div className="mb-4 p-2 bg-amber-100 border border-amber-300 rounded">
              <div className="flex items-start gap-2">
                <MessageSquare className="w-3 h-3 text-amber-600 mt-0.5" />
                <p className="text-xs text-amber-800">{order.notes}</p>
              </div>
            </div>
          )}

          {/* Action Button */}
          <Button
            size="sm"
            className="w-full"
            onClick={(e) => {
              e.stopPropagation();
              onStatusChange(order.id, nextStatus);
            }}
            variant={priority === 'urgent' ? 'destructive' : 'default'}
          >
            {actionLabel}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}