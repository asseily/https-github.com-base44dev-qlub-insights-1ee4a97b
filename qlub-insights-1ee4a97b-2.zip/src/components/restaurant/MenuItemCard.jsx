import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  Eye, 
  EyeOff, 
  Star, 
  DollarSign,
  Image as ImageIcon,
  AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";

export default function MenuItemCard({ item, onEdit, onToggleAvailability }) {
  const getCategoryColor = (category) => {
    switch(category) {
      case 'appetizers': return 'bg-green-100 text-green-800 border-green-200';
      case 'mains': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'desserts': return 'bg-pink-100 text-pink-800 border-pink-200';
      case 'drinks': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'sides': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card className={`shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden ${
        !item.available ? 'opacity-75' : ''
      }`}>
        {/* Image Header */}
        <div className="relative h-48 bg-gradient-to-br from-slate-100 to-slate-200">
          {item.image_url ? (
            <img 
              src={item.image_url} 
              alt={item.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <ImageIcon className="w-12 h-12 text-slate-400" />
            </div>
          )}
          
          {/* Status Badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            {item.featured && (
              <Badge className="bg-amber-500 text-white shadow-lg">
                <Star className="w-3 h-3 mr-1" />
                Featured
              </Badge>
            )}
            <Badge className={getCategoryColor(item.category)}>
              {item.category}
            </Badge>
          </div>

          <div className="absolute top-3 right-3">
            <Badge 
              className={item.available 
                ? 'bg-green-500 text-white shadow-lg' 
                : 'bg-red-500 text-white shadow-lg'
              }
            >
              {item.available ? 'Available' : 'Unavailable'}
            </Badge>
          </div>
        </div>

        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-start justify-between">
            <span className={!item.available ? 'text-slate-500' : ''}>{item.name}</span>
            <div className="flex items-center gap-1 text-emerald-600 font-bold">
              <DollarSign className="w-4 h-4" />
              <span>AED {item.price.toFixed(2)}</span>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Description */}
          <p className={`text-sm ${!item.available ? 'text-slate-400' : 'text-slate-600'} line-clamp-2`}>
            {item.description}
          </p>

          {/* Allergens & Dietary Info */}
          <div className="space-y-2">
            {item.allergens?.length > 0 && (
              <div className="flex flex-wrap gap-1">
                <span className="text-xs text-red-600 font-medium mr-1">Allergens:</span>
                {item.allergens.slice(0, 3).map((allergen, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs bg-red-50 text-red-700 border-red-200">
                    {allergen}
                  </Badge>
                ))}
                {item.allergens.length > 3 && (
                  <span className="text-xs text-red-600">+{item.allergens.length - 3} more</span>
                )}
              </div>
            )}

            {item.dietary_info?.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {item.dietary_info.slice(0, 2).map((diet, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                    {diet}
                  </Badge>
                ))}
                {item.dietary_info.length > 2 && (
                  <span className="text-xs text-green-600">+{item.dietary_info.length - 2} more</span>
                )}
              </div>
            )}
          </div>

          {/* Modifiers Info */}
          {item.modifiers?.length > 0 && (
            <div className="p-2 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-xs text-blue-800">
                <span className="font-medium">Customizable:</span> {item.modifiers.length} option group{item.modifiers.length > 1 ? 's' : ''}
              </p>
            </div>
          )}

          {/* Warnings */}
          {!item.available && (
            <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg border border-red-200">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <p className="text-xs text-red-800">Currently unavailable for orders</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4 border-t border-slate-100">
            <Button
              size="sm"
              onClick={() => onEdit(item)}
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700"
            >
              <Edit className="w-4 h-4 mr-1" />
              Edit
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onToggleAvailability(item)}
              className={`px-3 ${
                item.available 
                  ? 'text-red-600 hover:bg-red-50 border-red-200' 
                  : 'text-green-600 hover:bg-green-50 border-green-200'
              }`}
            >
              {item.available ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}