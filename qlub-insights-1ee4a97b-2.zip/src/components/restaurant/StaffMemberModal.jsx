import React, { useEffect, useState } from "react";
import { Staff } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Calendar as CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";

const ROLES = ["manager", "chef", "waiter", "cashier", "host", "kitchen_assistant"];
const STATUSES = ["active", "inactive", "on_leave"];

export default function StaffMemberModal({ isOpen, onClose, staff, restaurant, onSave }) {
  const [form, setForm] = useState({
    employee_id: "",
    full_name: "",
    email: "",
    phone: "",
    role: "waiter",
    hourly_rate: "",
    hire_date: null,
    status: "active",
  });

  useEffect(() => {
    if (staff) {
      setForm({
        employee_id: staff.employee_id || "",
        full_name: staff.full_name || "",
        email: staff.email || "",
        phone: staff.phone || "",
        role: staff.role || "waiter",
        hourly_rate: staff.hourly_rate ?? "",
        hire_date: staff.hire_date ? new Date(staff.hire_date) : null,
        status: staff.status || "active",
      });
    } else {
      setForm({
        employee_id: "",
        full_name: "",
        email: "",
        phone: "",
        role: "waiter",
        hourly_rate: "",
        hire_date: null,
        status: "active",
      });
    }
  }, [staff]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };

  const handleSubmit = async () => {
    const payload = {
      employee_id: form.employee_id.trim(),
      full_name: form.full_name.trim(),
      email: form.email.trim(),
      phone: form.phone,
      role: form.role,
      hourly_rate: form.hourly_rate !== "" ? Number(form.hourly_rate) : null,
      hire_date: form.hire_date ? new Date(form.hire_date).toISOString().slice(0, 10) : null, // date-only
      status: form.status,
      restaurant_id: restaurant?.id,
    };
    if (staff?.id) {
      await Staff.update(staff.id, payload);
    } else {
      await Staff.create(payload);
    }
    onSave?.();
    onClose?.();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose?.()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{staff ? "Edit Staff Member" : "Add Staff Member"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Employee ID</Label>
              <Input name="employee_id" value={form.employee_id} onChange={handleChange} placeholder="EMP-001" />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm((p) => ({ ...p, role: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r} value={r}>
                      {r.replace("_", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input name="full_name" value={form.full_name} onChange={handleChange} placeholder="John Doe" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" name="email" value={form.email} onChange={handleChange} placeholder="john@qlub.com" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input name="phone" value={form.phone} onChange={handleChange} placeholder="+971 50 000 0000" />
            </div>
            <div className="space-y-2">
              <Label>Hourly Rate (AED)</Label>
              <Input type="number" name="hourly_rate" value={form.hourly_rate} onChange={handleChange} />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Hire Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="w-4 h-4 mr-2" />
                    {form.hire_date ? format(form.hire_date, "PP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Calendar
                    mode="single"
                    selected={form.hire_date}
                    onSelect={(d) => setForm((p) => ({ ...p, hire_date: d }))}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm((p) => ({ ...p, status: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s.replace("_", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <DialogFooter className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-purple-600 hover:bg-purple-700">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}