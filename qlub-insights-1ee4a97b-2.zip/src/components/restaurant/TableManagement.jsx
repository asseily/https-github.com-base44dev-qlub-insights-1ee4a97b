
import React, { useState } from 'react';
import { Table } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  Edit, 
  QrCode,
  Users,
  MapPin,
  RefreshCw,
  Filter,
  Eye,
  Settings,
  Download // NEW
} from "lucide-react";

import { createPageUrl } from "@/utils";

import TableForm from "./TableForm";

export default function TableManagement({ restaurant, tables, refreshData }) {
  const [showForm, setShowForm] = useState(false);
  const [editingTable, setEditingTable] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const handleSubmit = async (tableData) => {
    // Generate unique QR code
    const qrCode = `QR_${tableData.table_number}_${restaurant.name.replace(/\s+/g, '_').toUpperCase()}_${Date.now()}`;
    
    const fullTableData = {
      ...tableData,
      restaurant_id: restaurant.id,
      qr_code: qrCode
    };

    if (editingTable) {
      await Table.update(editingTable.id, fullTableData);
    } else {
      await Table.create(fullTableData);
    }
    
    setShowForm(false);
    setEditingTable(null);
    refreshData();
  };

  const handleEdit = (table) => {
    setEditingTable(table);
    setShowForm(true);
  };

  const handleStatusChange = async (table, newStatus) => {
    await Table.update(table.id, { ...table, status: newStatus });
    refreshData();
  };

  const filteredTables = tables.filter(table => {
    const matchesSearch =
      (table.table_number || '').toLowerCase().includes((searchTerm || '').toLowerCase()) ||
      (table.location || '').toLowerCase().includes((searchTerm || '').toLowerCase());
    const matchesStatus = statusFilter === "all" || table.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status) => {
    switch(status) {
      case 'available': return 'bg-green-100 text-green-800 border-green-200';
      case 'occupied': return 'bg-red-100 text-red-800 border-red-200';
      case 'reserved': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cleaning': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const statusOptions = [
    { value: 'available', label: 'Available', color: 'text-green-600' },
    { value: 'occupied', label: 'Occupied', color: 'text-red-600' },
    { value: 'reserved', label: 'Reserved', color: 'text-blue-600' },
    { value: 'cleaning', label: 'Cleaning', color: 'text-amber-600' }
  ];

  // NEW: export tables CSV (based on current filters)
  const exportTablesCSV = () => {
    const headers = ["Table Number","Location","Capacity","Status","QR Code","ID"];
    const rows = filteredTables.map(t => ([
      t.table_number || "",
      t.location || "",
      t.capacity != null ? t.capacity : "",
      t.status || "",
      t.qr_code || "",
      t.id || ""
    ]));
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tables_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportQRMagnetsCSV = () => {
    const headers = ["Table Number", "Location", "Menu URL"];
    const origin = window.location.origin;
    const rows = filteredTables.map(t => {
      const relative = createPageUrl(
        `CustomerMenu?restaurant_id=${restaurant.id}&restaurant=${encodeURIComponent(restaurant.name)}&table=${t.id}&table_number=${encodeURIComponent(t.table_number)}`
      );
      const url = relative.startsWith('http') ? relative : origin + relative;
      return [
        t.table_number || "",
        t.location || "",
        url
      ];
    });
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `table_qr_menu_links_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Table Management</h2>
          <p className="text-slate-600 text-lg">Manage your restaurant tables and QR codes</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" onClick={exportTablesCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export Tables CSV
          </Button>
          <Button variant="outline" onClick={exportQRMagnetsCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export QR Links CSV
          </Button>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Table
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Available Tables</p>
                <p className="text-2xl font-bold">
                  {tables.filter(t => t.status === 'available').length}
                </p>
              </div>
              <Users className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">Occupied Tables</p>
                <p className="text-2xl font-bold">
                  {tables.filter(t => t.status === 'occupied').length}
                </p>
              </div>
              <Users className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Reserved Tables</p>
                <p className="text-2xl font-bold">
                  {tables.filter(t => t.status === 'reserved').length}
                </p>
              </div>
              <Users className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Total Tables</p>
                <p className="text-2xl font-bold">{tables.length}</p>
              </div>
              <Settings className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by table number or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">Filter by status:</span>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {statusOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      <span className={option.color}>{option.label}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table Form */}
      {showForm && (
        <TableForm
          table={editingTable}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingTable(null);
          }}
        />
      )}

      {/* Tables Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTables.map(table => (
          <Card key={table.id} className="shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-slate-800 to-slate-900 text-white">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Table {table.table_number}
                  </CardTitle>
                  <p className="text-slate-300 text-sm flex items-center gap-1 mt-1">
                    <MapPin className="w-3 h-3" />
                    {table.location || 'No location set'}
                  </p>
                </div>
                <Badge className={getStatusColor(table.status)}>
                  {table.status}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="p-6 space-y-4">
              {/* Table Info */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Capacity:</span>
                  <span className="font-semibold">{table.capacity} guests</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">QR Code:</span>
                  <Badge variant="outline" className="text-xs">
                    Generated
                  </Badge>
                </div>
              </div>

              {/* Status Actions */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Quick Status Change:</label>
                <div className="grid grid-cols-2 gap-2">
                  {statusOptions.map(option => (
                    <Button
                      key={option.value}
                      size="sm"
                      variant={table.status === option.value ? "default" : "outline"}
                      onClick={() => handleStatusChange(table, option.value)}
                      className={`text-xs ${table.status === option.value ? 'bg-purple-600' : option.color}`}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4 border-t border-slate-100">
                <Button
                  size="sm"
                  onClick={() => handleEdit(table)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700"
                >
                  <Edit className="w-4 h-4 mr-1" />
                  Edit
                </Button>
                
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    // Deep-link to RestaurantDashboard QR Generator tab with this table preselected
                    window.location.href = createPageUrl(`RestaurantDashboard?tab=qrcodes&table_id=${table.id}`);
                  }}
                >
                  <QrCode className="w-4 h-4 mr-1" />
                  QR Code
                </Button>
              </div>

              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={() => {
                  const url = createPageUrl(
                    `CustomerMenu?restaurant_id=${restaurant.id}&restaurant=${restaurant.name}&table=${table.id}&table_number=${table.table_number}`
                  );
                  window.open(url, "_blank");
                }}
              >
                <Eye className="w-4 h-4 mr-2" />
                Preview Menu
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTables.length === 0 && (
        <Card className="shadow-lg">
          <CardContent className="text-center py-12">
            <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">
              {tables.length === 0 ? "No tables configured" : "No tables match your filters"}
            </h3>
            <p className="text-slate-600 mb-6">
              {tables.length === 0 
                ? "Start by adding your first table to enable QR code ordering"
                : "Try adjusting your search terms or filters"
              }
            </p>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add First Table
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
