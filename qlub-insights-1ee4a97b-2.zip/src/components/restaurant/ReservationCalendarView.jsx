import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as DayPicker } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { format, isSameDay } from "date-fns";
import { Calendar as CalendarIcon, Users, Clock, Phone, Mail } from "lucide-react";

export default function ReservationCalendarView({ reservations = [], restaurant, onDateSelect }) {
  const [selected, setSelected] = React.useState(new Date());

  const getStatusColor = (status) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "no_show":
        return "bg-gray-100 text-gray-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  const dayReservations = React.useMemo(() => {
    return reservations
      .filter((r) => r.reservation_date && isSameDay(new Date(r.reservation_date), selected))
      .sort((a, b) => new Date(a.reservation_date) - new Date(b.reservation_date));
  }, [reservations, selected]);

  const handleSelect = (date) => {
    const d = date || new Date();
    setSelected(d);
    onDateSelect && onDateSelect(d);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-purple-600" />
            Calendar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DayPicker
            mode="single"
            selected={selected}
            onSelect={handleSelect}
            initialFocus
          />
          <div className="mt-4 text-sm text-slate-600">
            {restaurant?.name ? `${restaurant.name} · ` : ""}{format(selected, "EEEE, MMM d, yyyy")}
          </div>
        </CardContent>
      </Card>

      <Card className="h-full">
        <CardHeader>
          <CardTitle>
            {dayReservations.length} reservation{dayReservations.length !== 1 ? "s" : ""} on {format(selected, "MMM d")}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dayReservations.length === 0 ? (
            <div className="text-center py-10 text-slate-500">
              <CalendarIcon className="w-10 h-10 mx-auto mb-3 opacity-60" />
              No reservations for this day
            </div>
          ) : (
            <div className="space-y-4">
              {dayReservations.map((r) => (
                <div key={r.id} className="border rounded-lg p-4 hover:bg-slate-50 transition">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-slate-500" />
                        <span className="font-medium">{format(new Date(r.reservation_date), "h:mm a")}</span>
                      </div>
                      <div className="font-semibold">{r.customer_name}</div>
                      <div className="flex items-center gap-3 text-sm text-slate-600">
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {r.party_size} guests
                        </span>
                        {r.customer_phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {r.customer_phone}
                          </span>
                        )}
                        {r.customer_email && (
                          <span className="flex items-center gap-1">
                            <Mail className="w-4 h-4" />
                            {r.customer_email}
                          </span>
                        )}
                      </div>
                    </div>
                    <Badge className={getStatusColor(r.status)}>{r.status}</Badge>
                  </div>
                  {r.special_requests && (
                    <div className="mt-2 text-sm text-slate-600">
                      Note: {r.special_requests}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}