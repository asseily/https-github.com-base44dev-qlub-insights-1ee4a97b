
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Users,
  Clock,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download
} from 'lucide-react';
import { format } from 'date-fns';

import DailyBriefing from './DailyBriefing';
import FeedbackInsights from '../dashboard/FeedbackInsights';

export default function RestaurantOverview({ restaurant, orders, menuItems, customers, refreshData }) {
  const currency = restaurant?.settings?.currency || 'AED';
  const recentOrders = orders.slice(0, 5);
  const topCustomers = [...customers].sort((a, b) => (b.total_spent || 0) - (a.total_spent || 0)).slice(0, 5);

  const getOrderStatusColor = (status) => {
    switch(status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-amber-100 text-amber-800';
      case 'preparing': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  // Export helpers
  const exportRecentOrdersCSV = () => {
    const headers = ["Customer","Status",`Total (${currency})`,"Time"];
    const rows = recentOrders.map(o => ([
      o.customer_name || "Guest",
      o.status || "",
      Number(o.total || 0).toFixed(2),
      o.created_date ? new Date(o.created_date).toLocaleTimeString() : ""
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `recent_orders_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportTopCustomersCSV = () => {
    const headers = ["Name","Orders",`Total Spent (${currency})`];
    const rows = topCustomers.map(c => ([
      c.name || "",
      c.order_count ?? 0,
      Number(c.total_spent || 0).toFixed(2)
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `top_customers_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* AI Daily Briefing */}
      <DailyBriefing
        restaurant={restaurant}
        orders={orders}
      />

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currency} {orders.reduce((sum, o) => sum + (o.total || 0), 0).toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">+20.1% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <BarChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orders.length}</div>
            <p className="text-xs text-muted-foreground">+180.1% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+{customers.length}</div>
            <p className="text-xs text-muted-foreground">+19% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Order Value</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currency} {(orders.reduce((sum, o) => sum + (o.total || 0), 0) / (orders.length || 1)).toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">+5.2% from last month</p>
          </CardContent>
        </Card>
      </div>

      {/* Feedback Insights */}
      <FeedbackInsights restaurant={restaurant} />

      {/* Recent Orders and Top Customers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Orders</CardTitle>
              <Button variant="outline" size="sm" onClick={exportRecentOrdersCSV} className="flex items-center gap-2">
                <Download className="w-4 h-4" /> Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {recentOrders.length === 0 ? (
              <div className="text-center text-slate-500 py-10">No orders yet today.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentOrders.map(order => (
                    <TableRow key={order.id}>
                      <TableCell>{order.customer_name || 'Guest'}</TableCell>
                      <TableCell>
                        <Badge className={getOrderStatusColor(order.status)}>{order.status}</Badge>
                      </TableCell>
                      <TableCell>{currency} {Number(order.total || 0).toFixed(2)}</TableCell>
                      <TableCell>{order.created_date ? format(new Date(order.created_date), 'p') : ''}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Top Customers</CardTitle>
              <Button variant="outline" size="sm" onClick={exportTopCustomersCSV} className="flex items-center gap-2">
                <Download className="w-4 h-4" /> Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {topCustomers.length === 0 ? (
              <div className="text-center text-slate-500 py-10">No customers data yet.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Orders</TableHead>
                    <TableHead>Total Spent</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topCustomers.map(customer => (
                    <TableRow key={customer.id}>
                      <TableCell>{customer.name}</TableCell>
                      <TableCell>{customer.order_count ?? 0}</TableCell>
                      <TableCell>{currency} {Number(customer.total_spent || 0).toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
