import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, X, Save, XCircle, Upload, Image as ImageIcon } from "lucide-react";
import { UploadFile } from "@/api/integrations";

export default function MenuItemForm({ item, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(item || {
    name: '',
    description: '',
    price: 0,
    category: 'appetizers',
    image_url: '',
    allergens: [],
    dietary_info: [],
    modifiers: [],
    available: true,
    featured: false
  });

  const [isUploading, setIsUploading] = useState(false);
  const [newAllergen, setNewAllergen] = useState('');
  const [newDietary, setNewDietary] = useState('');
  const [newModifier, setNewModifier] = useState({ name: '', options: [] });
  const [newOption, setNewOption] = useState({ name: '', price_change: 0 });

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, image_url: file_url }));
    } catch (error) {
      console.error("Error uploading image:", error);
    }
    setIsUploading(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addItem = (field, value, setter) => {
    if (value.trim()) {
      setFormData(prev => ({
        ...prev,
        [field]: [...(prev[field] || []), value.trim()]
      }));
      setter('');
    }
  };

  const removeItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const addModifier = () => {
    if (newModifier.name && newModifier.options.length > 0) {
      setFormData(prev => ({
        ...prev,
        modifiers: [...(prev.modifiers || []), { ...newModifier }]
      }));
      setNewModifier({ name: '', options: [] });
    }
  };

  const addOptionToModifier = () => {
    if (newOption.name) {
      setNewModifier(prev => ({
        ...prev,
        options: [...prev.options, { ...newOption }]
      }));
      setNewOption({ name: '', price_change: 0 });
    }
  };

  return (
    <Card className="shadow-xl border-0 bg-gradient-to-br from-white to-slate-50">
      <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-lg">
        <CardTitle className="text-xl flex items-center gap-3">
          <ImageIcon className="w-6 h-6" />
          {item ? 'Edit Menu Item' : 'Add New Menu Item'}
        </CardTitle>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-8 p-8">
          {/* Image Upload */}
          <div className="space-y-4">
            <Label className="text-lg font-semibold text-slate-900">Item Image</Label>
            <div className="flex flex-col items-center gap-4">
              {formData.image_url ? (
                <div className="relative">
                  <img 
                    src={formData.image_url} 
                    alt="Menu item"
                    className="w-48 h-32 object-cover rounded-xl shadow-lg"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 rounded-full"
                    onClick={() => setFormData(prev => ({ ...prev, image_url: '' }))}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <div className="w-48 h-32 border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center bg-slate-50">
                  <ImageIcon className="w-12 h-12 text-slate-400" />
                </div>
              )}
              
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={isUploading}
                />
                <Button type="button" variant="outline" disabled={isUploading}>
                  <Upload className="w-4 h-4 mr-2" />
                  {isUploading ? 'Uploading...' : 'Upload Image'}
                </Button>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-semibold text-slate-700">Item Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                placeholder="e.g. Grilled Salmon"
                className="text-lg py-3"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="price" className="text-sm font-semibold text-slate-700">Price (AED)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData(prev => ({...prev, price: parseFloat(e.target.value) || 0}))}
                className="text-lg py-3"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="category" className="text-sm font-semibold text-slate-700">Category</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => setFormData(prev => ({...prev, category: value}))}
              >
                <SelectTrigger className="py-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="appetizers">🥗 Appetizers</SelectItem>
                  <SelectItem value="mains">🍽️ Main Courses</SelectItem>
                  <SelectItem value="desserts">🍰 Desserts</SelectItem>
                  <SelectItem value="drinks">🥤 Beverages</SelectItem>
                  <SelectItem value="sides">🍟 Sides</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="available"
                  checked={formData.available}
                  onCheckedChange={(checked) => setFormData(prev => ({...prev, available: checked}))}
                />
                <Label htmlFor="available" className="text-sm font-medium">Available for ordering</Label>
              </div>
              
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="featured"
                  checked={formData.featured}
                  onCheckedChange={(checked) => setFormData(prev => ({...prev, featured: checked}))}
                />
                <Label htmlFor="featured" className="text-sm font-medium">Featured item</Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-semibold text-slate-700">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
              placeholder="Describe the dish, ingredients, cooking method..."
              className="h-24 resize-none"
              required
            />
          </div>

          {/* Allergens */}
          <div className="space-y-4">
            <Label className="text-sm font-semibold text-slate-700">Allergens</Label>
            <div className="flex gap-2">
              <Input
                value={newAllergen}
                onChange={(e) => setNewAllergen(e.target.value)}
                placeholder="e.g. Nuts, Dairy, Gluten"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('allergens', newAllergen, setNewAllergen))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('allergens', newAllergen, setNewAllergen)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.allergens?.map((allergen, idx) => (
                <Badge key={idx} variant="outline" className="gap-1 bg-red-50 text-red-700 border-red-200">
                  {allergen}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('allergens', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Dietary Info */}
          <div className="space-y-4">
            <Label className="text-sm font-semibold text-slate-700">Dietary Information</Label>
            <div className="flex gap-2">
              <Input
                value={newDietary}
                onChange={(e) => setNewDietary(e.target.value)}
                placeholder="e.g. Vegan, Vegetarian, Gluten-Free"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('dietary_info', newDietary, setNewDietary))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('dietary_info', newDietary, setNewDietary)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.dietary_info?.map((info, idx) => (
                <Badge key={idx} variant="outline" className="gap-1 bg-green-50 text-green-700 border-green-200">
                  {info}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('dietary_info', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Modifiers */}
          <div className="space-y-6">
            <Label className="text-sm font-semibold text-slate-700">Customization Options</Label>
            
            {/* Add New Modifier */}
            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-4 space-y-4">
                <Input
                  placeholder="Modifier name (e.g. Size, Spice Level)"
                  value={newModifier.name}
                  onChange={(e) => setNewModifier(prev => ({...prev, name: e.target.value}))}
                />
                
                <div className="space-y-2">
                  <Label className="text-xs font-medium text-slate-600">Options</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Option name"
                      value={newOption.name}
                      onChange={(e) => setNewOption(prev => ({...prev, name: e.target.value}))}
                    />
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Price change"
                      value={newOption.price_change}
                      onChange={(e) => setNewOption(prev => ({...prev, price_change: parseFloat(e.target.value) || 0}))}
                      className="w-32"
                    />
                    <Button type="button" size="sm" onClick={addOptionToModifier}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {newModifier.options.map((option, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {option.name} {option.price_change !== 0 && `(+${option.price_change} AED)`}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button type="button" size="sm" onClick={addModifier} disabled={!newModifier.name || newModifier.options.length === 0}>
                  Add Modifier
                </Button>
              </CardContent>
            </Card>

            {/* Existing Modifiers */}
            {formData.modifiers?.map((modifier, modIdx) => (
              <Card key={modIdx} className="border-slate-200">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-slate-900">{modifier.name}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setFormData(prev => ({
                          ...prev,
                          modifiers: prev.modifiers.filter((_, i) => i !== modIdx)
                        }));
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {modifier.options.map((option, optIdx) => (
                      <Badge key={optIdx} variant="outline" className="text-xs">
                        {option.name} {option.price_change !== 0 && `(+${option.price_change} AED)`}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>

        <CardFooter className="flex justify-end gap-4 p-8 bg-slate-50 rounded-b-lg">
          <Button type="button" variant="outline" onClick={onCancel} className="px-8">
            <XCircle className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-purple-600 hover:bg-purple-700 px-8">
            <Save className="w-4 h-4 mr-2" />
            {item ? 'Update Item' : 'Create Item'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}