
import React, { useState } from 'react';
import { Promotion } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, TicketPercent, Edit, Download } from "lucide-react"; // Added Download icon
import { format } from 'date-fns';

import PromotionFormModal from "./PromotionFormModal";

export default function PromotionManagement({ restaurant, promotions, refreshData }) {
  const [showForm, setShowForm] = useState(false);
  const [editingPromotion, setEditingPromotion] = useState(null);
  const currency = restaurant?.settings?.currency || 'AED';
  
  const handleToggleActive = async (promo) => {
    await Promotion.update(promo.id, { ...promo, is_active: !promo.is_active });
    refreshData();
  };
  
  const handleEdit = (promo) => {
    setEditingPromotion(promo);
    setShowForm(true);
  };
  
  const handleAddNew = () => {
    setEditingPromotion(null);
    setShowForm(true);
  };

  // NEW: Export promotions to CSV
  const exportPromotionsCSV = () => {
    const headers = ["Code","Description","Discount Type","Discount Value","Active","Valid From","Valid To","Usage Limit","Times Used"];
    const rows = promotions.map(p => ([
      p.code || "",
      p.description || "",
      p.discount_type || "",
      p.discount_value != null ? p.discount_value : "",
      p.is_active ? "Yes" : "No",
      p.valid_from ? new Date(p.valid_from).toLocaleString() : "",
      p.valid_to ? new Date(p.valid_to).toLocaleString() : "",
      p.usage_limit != null ? p.usage_limit : "",
      p.times_used != null ? p.times_used : ""
    ]));
    // Escape double quotes by doubling them, then wrap each field in double quotes
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `promotions_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Promotions & Discounts</h2>
          <p className="text-slate-600 text-lg">Create and manage special offers for your customers</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportPromotionsCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button onClick={handleAddNew}>
            <Plus className="w-4 h-4 mr-2" />
            Create Promotion
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle>Active & Upcoming Promotions</CardTitle></CardHeader>
        <CardContent>
           <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Code</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Discount</TableHead>
                <TableHead>Validity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {promotions.length > 0 ? promotions.map(promo => (
                <TableRow key={promo.id}>
                  <TableCell><Badge variant="outline">{promo.code}</Badge></TableCell>
                  <TableCell>{promo.description}</TableCell>
                  <TableCell>
                    {promo.discount_type === 'percentage' 
                      ? `${promo.discount_value}%` 
                      : `${currency} ${Number(promo.discount_value || 0).toFixed(2)}`}
                  </TableCell>
                  <TableCell>
                    {format(new Date(promo.valid_from), 'MMM d')} - {format(new Date(promo.valid_to), 'MMM d, yyyy')}
                  </TableCell>
                   <TableCell>
                     <Switch 
                        checked={promo.is_active} 
                        onCheckedChange={() => handleToggleActive(promo)}
                      />
                  </TableCell>
                  <TableCell>
                     <Button variant="ghost" size="icon" onClick={() => handleEdit(promo)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                  <TableCell colSpan={6} className="text-center py-12">
                    <TicketPercent className="w-12 h-12 mx-auto text-slate-300 mb-4" />
                    <h3 className="font-semibold text-lg">No Promotions Yet</h3>
                    <p className="text-slate-500">Click "Create Promotion" to add your first offer.</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {showForm && (
        <PromotionFormModal
          isOpen={showForm}
          onClose={() => setShowForm(false)}
          promotion={editingPromotion}
          restaurantId={restaurant.id}
          onSave={() => {
            setShowForm(false);
            refreshData();
          }}
        />
      )}
    </div>
  );
}
