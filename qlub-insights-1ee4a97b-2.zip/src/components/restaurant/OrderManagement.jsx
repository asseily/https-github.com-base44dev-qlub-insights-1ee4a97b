
import React, { useState, useEffect, useCallback } from 'react';
import { Order } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Search, 
  Filter,
  Eye,
  MessageSquare,
  Timer,
  DollarSign,
  Users,
  Bell,
  ChefHat,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import OrderCard from "./OrderCard";
import OrderDetailsModal from "./OrderDetailsModal";
import KitchenDisplaySystem from "./KitchenDisplaySystem";

export default function OrderManagement({ restaurant, orders, refreshData }) {
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("active");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  const [activeTab, setActiveTab] = useState("orders");
  const currency = restaurant?.settings?.currency || 'AED';

  const filterOrders = useCallback(() => {
    let filtered = orders;

    // Filter by status
    if (statusFilter === "active") {
      filtered = filtered.filter(order => 
        ['pending', 'confirmed', 'preparing', 'ready'].includes(order.status)
      );
    } else if (statusFilter === "completed") {
      filtered = filtered.filter(order => 
        ['served', 'paid'].includes(order.status)
      );
    } else if (statusFilter === "cancelled") {
      filtered = filtered.filter(order => order.status === 'cancelled');
    } else if (statusFilter === "all") {
      // No status filter applied, show all orders
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(order =>
        (order.customer_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        String(order.id || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        String(order.table_id || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredOrders(filtered);
  }, [orders, searchTerm, statusFilter]);

  useEffect(() => {
    filterOrders();
  }, [filterOrders]);

  const updateOrderStatus = async (orderId, newStatus) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    await Order.update(orderId, { 
      ...order, 
      status: newStatus,
      ...(newStatus === 'served' && { served_at: new Date().toISOString() })
    });

    // Optional: POS sync via backend if enabled
    if (restaurant?.settings?.pos_sync_mode === 'backend') {
      await fetch("/api/pos/sync-order-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          restaurant_id: restaurant.id,
          order_id: orderId,
          status: newStatus,
          table_id: order.table_id || null,
          totals: {
            subtotal: order.subtotal ?? 0,
            tax: order.tax_amount ?? 0,
            service_charge: order.service_charge ?? 0,
            tip: order.tip_amount ?? 0,
            total: order.total ?? 0
          },
          items: Array.isArray(order.items) ? order.items : []
        })
      });
    }

    refreshData();
  };

  const handleOrderClick = (order) => {
    setSelectedOrder(order);
    setShowOrderDetails(true);
  };

  const getOrderStatusColor = (status) => {
    switch(status) {
      case 'pending': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'preparing': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'ready': return 'bg-green-100 text-green-800 border-green-200';
      case 'served': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'paid': return 'bg-slate-100 text-slate-800 border-slate-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getOrderStats = () => {
    const activeOrders = orders.filter(o => ['pending', 'confirmed', 'preparing', 'ready'].includes(o.status));
    const todayOrders = orders.filter(order => {
      const today = new Date().toDateString();
      return new Date(order.created_date).toDateString() === today;
    });
    const todayRevenue = todayOrders.reduce((sum, order) => sum + (order.total || 0), 0);
    const avgOrderValue = todayOrders.length ? (todayRevenue / todayOrders.length) : 0;

    return { activeOrders: activeOrders.length, todayOrders: todayOrders.length, todayRevenue, avgOrderValue };
  };

  const stats = getOrderStats();

  // CSV export for filtered orders
  const exportOrdersCSV = () => {
    const headers = ["Order ID","Status","Created At","Customer","Table","Subtotal","Tax","Service","Tip","Total","Items Count"];
    const rows = filteredOrders.map(o => ([
      o.id,
      o.status,
      o.created_date ? new Date(o.created_date).toLocaleString() : "",
      o.customer_name || "Guest",
      o.table_id || "",
      (o.subtotal ?? 0).toFixed(2),
      (o.tax_amount ?? 0).toFixed(2),
      (o.service_charge ?? 0).toFixed(2),
      (o.tip_amount ?? 0).toFixed(2),
      (o.total ?? 0).toFixed(2),
      Array.isArray(o.items) ? o.items.reduce((n,i)=>n+(i.quantity||0),0) : 0
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `orders_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Order Management</h2>
          <p className="text-slate-600 text-lg">Real-time order tracking and kitchen operations</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportOrdersCSV} className="flex items-center gap-2">
            <Download className="w-4 h-4" /> Export CSV
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Notifications
            {stats.activeOrders > 0 && (
              <Badge className="bg-red-500 text-white">
                {stats.activeOrders}
              </Badge>
            )}
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="shadow-lg bg-gradient-to-br from-amber-500 to-amber-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-100 text-sm">Active Orders</p>
                <p className="text-2xl font-bold">{stats.activeOrders}</p>
              </div>
              <Clock className="w-8 h-8 text-amber-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Today's Orders</p>
                <p className="text-2xl font-bold">{stats.todayOrders}</p>
              </div>
              <Users className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-100 text-sm">Today's Revenue</p>
                <p className="text-2xl font-bold">{currency} {stats.todayRevenue.toFixed(0)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-emerald-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Avg Order Value</p>
                <p className="text-2xl font-bold">{currency} {stats.avgOrderValue.toFixed(0)}</p>
              </div>
              <ChefHat className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white p-1 shadow-sm border border-slate-200 rounded-lg">
          <TabsTrigger value="orders" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Order Management
          </TabsTrigger>
          <TabsTrigger value="kitchen" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Kitchen Display
          </TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="space-y-6">
          {/* Search and Filters */}
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by order ID, customer name, or table..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-slate-400" />
                    <span className="text-sm text-slate-600">Filter:</span>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active Orders</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                      <SelectItem value="all">All Orders</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Orders Grid */}
          <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredOrders.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  onStatusChange={updateOrderStatus}
                  onClick={() => handleOrderClick(order)}
                  getStatusColor={getOrderStatusColor}
                />
              ))}
            </AnimatePresence>
          </div>

          {filteredOrders.length === 0 && (
            <Card className="shadow-lg">
              <CardContent className="text-center py-12">
                <Clock className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">No orders found</h3>
                <p className="text-slate-600">
                  {orders.length === 0 ? "No orders have been placed yet" : "Try adjusting your filters"}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="kitchen">
          <KitchenDisplaySystem 
            orders={filteredOrders}
            onStatusChange={updateOrderStatus}
            getStatusColor={getOrderStatusColor}
          />
        </TabsContent>
      </Tabs>

      {/* Order Details Modal */}
      {showOrderDetails && selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          isOpen={showOrderDetails}
          onClose={() => setShowOrderDetails(false)}
          onStatusChange={updateOrderStatus}
          getStatusColor={getOrderStatusColor}
        />
      )}
    </div>
  );
}
