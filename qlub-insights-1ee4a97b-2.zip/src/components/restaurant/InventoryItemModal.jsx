import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InventoryItem } from "@/api/entities";
import { X, Save, Package } from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";

export default function InventoryItemModal({ isOpen, onClose, item, restaurant, onSave }) {
  const [formData, setFormData] = useState(item || {
    name: '',
    category: 'ingredients',
    current_stock: 0,
    minimum_stock: 0,
    unit: '',
    cost_per_unit: 0,
    supplier: '',
    expiry_date: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const itemData = {
      ...formData,
      restaurant_id: restaurant.id,
      status: formData.current_stock <= formData.minimum_stock ? 'low_stock' : 'in_stock'
    };

    if (item) {
      await InventoryItem.update(item.id, itemData);
    } else {
      await InventoryItem.create(itemData);
    }
    
    onSave();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <Card className="shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
              <CardTitle className="flex items-center gap-3">
                <Package className="w-6 h-6" />
                {item ? 'Edit Inventory Item' : 'Add New Inventory Item'}
              </CardTitle>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="p-6 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Item Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                      placeholder="e.g., Tomatoes"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select 
                      value={formData.category} 
                      onValueChange={(value) => setFormData(prev => ({...prev, category: value}))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ingredients">Ingredients</SelectItem>
                        <SelectItem value="beverages">Beverages</SelectItem>
                        <SelectItem value="supplies">Supplies</SelectItem>
                        <SelectItem value="equipment">Equipment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="current_stock">Current Stock</Label>
                    <Input
                      id="current_stock"
                      type="number"
                      value={formData.current_stock}
                      onChange={(e) => setFormData(prev => ({...prev, current_stock: parseFloat(e.target.value) || 0}))}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="minimum_stock">Minimum Stock</Label>
                    <Input
                      id="minimum_stock"
                      type="number"
                      value={formData.minimum_stock}
                      onChange={(e) => setFormData(prev => ({...prev, minimum_stock: parseFloat(e.target.value) || 0}))}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit</Label>
                    <Input
                      id="unit"
                      value={formData.unit}
                      onChange={(e) => setFormData(prev => ({...prev, unit: e.target.value}))}
                      placeholder="kg, liters, pieces"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="cost_per_unit">Cost per Unit (AED)</Label>
                    <Input
                      id="cost_per_unit"
                      type="number"
                      step="0.01"
                      value={formData.cost_per_unit}
                      onChange={(e) => setFormData(prev => ({...prev, cost_per_unit: parseFloat(e.target.value) || 0}))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="supplier">Supplier</Label>
                    <Input
                      id="supplier"
                      value={formData.supplier}
                      onChange={(e) => setFormData(prev => ({...prev, supplier: e.target.value}))}
                      placeholder="Supplier name"
                    />
                  </div>
                </div>

                {formData.category === 'ingredients' && (
                  <div className="space-y-2">
                    <Label htmlFor="expiry_date">Expiry Date</Label>
                    <Input
                      id="expiry_date"
                      type="date"
                      value={formData.expiry_date}
                      onChange={(e) => setFormData(prev => ({...prev, expiry_date: e.target.value}))}
                    />
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end gap-3 bg-slate-50 rounded-b-lg">
                <Button type="button" variant="outline" onClick={onClose}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  <Save className="w-4 h-4 mr-2" />
                  {item ? 'Update' : 'Create'} Item
                </Button>
              </CardFooter>
            </form>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}