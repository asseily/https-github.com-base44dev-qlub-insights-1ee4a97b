
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Users, Eye, Mail, Download } from "lucide-react";
import CustomerDetailsModal from './CustomerDetailsModal';
import SendPromoModal from './SendPromoModal';

export default function CustomerManagement({ restaurant, customers, promotions, refreshData }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isPromoModalOpen, setIsPromoModalOpen] = useState(false);
  const currency = restaurant?.settings?.currency || 'AED';

  const filteredCustomers = customers.filter(c =>
    (c.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.email || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  // CSV export for filtered customers
  const exportCustomersCSV = () => {
    const headers = ["Name","Email","Phone","Visits",`Total Spent (${currency})`,"Last Visit","Tags"];
    const rows = filteredCustomers.map(c => ([
      c.name || "",
      c.email || "",
      c.phone || "",
      c.order_count ?? 0,
      (c.total_spent ?? 0).toFixed(2),
      c.last_visit_date ? new Date(c.last_visit_date).toLocaleDateString() : "",
      (c.tags || []).join("|")
    ]));
    // Format values to be CSV safe (handle commas and quotes)
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `customers_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleViewDetails = (customer) => {
    setSelectedCustomer(customer);
    setIsDetailsModalOpen(true);
  };
  
  const handleOpenPromoModal = (customer) => {
    setSelectedCustomer(customer);
    setIsPromoModalOpen(true);
  };

  return (
    <>
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Users className="w-6 h-6 text-purple-600" />
                Customer Relationship Management
              </CardTitle>
              <CardDescription>
                View and manage your customer database. Total: {customers.length} customers.
              </CardDescription>
            </div>
            <div className="flex w-full md:w-auto gap-3">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search customers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" onClick={exportCustomersCSV} className="whitespace-nowrap">
                <Download className="w-4 h-4 mr-2" /> Export CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead className="text-center">Visits</TableHead>
                  <TableHead className="text-right">Total Spent</TableHead>
                  <TableHead>Last Visit</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      No customers found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCustomers.map(customer => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-medium">{customer.name}</TableCell>
                      <TableCell>{customer.email}</TableCell>
                      <TableCell className="text-center">{customer.order_count ?? 0}</TableCell>
                      <TableCell className="text-right">{currency} {Number(customer.total_spent || 0).toFixed(2)}</TableCell>
                      <TableCell>{customer.last_visit_date ? new Date(customer.last_visit_date).toLocaleDateString() : '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {customer.tags?.map(tag => (
                            <Badge key={tag} variant="outline">{tag}</Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex gap-2 justify-center">
                          <Button variant="ghost" size="icon" onClick={() => handleViewDetails(customer)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleOpenPromoModal(customer)}>
                            <Mail className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      {selectedCustomer && (
        <>
          <CustomerDetailsModal
            customer={selectedCustomer}
            isOpen={isDetailsModalOpen}
            onClose={() => setIsDetailsModalOpen(false)}
            restaurantId={restaurant.id}
          />
          <SendPromoModal
            customer={selectedCustomer}
            restaurant={restaurant}
            promotions={promotions}
            isOpen={isPromoModalOpen}
            onClose={() => setIsPromoModalOpen(false)}
          />
        </>
      )}
    </>
  );
}
