
import React, { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mail, Plus, Send, Edit3, Star, Users } from "lucide-react";
import { EmailCampaign, Customer } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import EmailCampaignForm from "./EmailCampaignForm";

export default function EmailMarketing({ restaurant, customers }) {
  const [campaigns, setCampaigns] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [testEmail, setTestEmail] = useState("");

  const load = useCallback(async () => {
    if (!restaurant?.id) return; // Add this check as restaurant.id is a dependency
    const data = await EmailCampaign.filter({ restaurant_id: restaurant.id }, '-created_date', 100);
    setCampaigns(data);
  }, [restaurant?.id]); // Dependency for useCallback

  useEffect(() => {
    load(); // Call load directly
  }, [load]); // Add load as a dependency for useEffect

  const handleSave = async (form) => {
    const payload = {
      ...form,
      restaurant_id: restaurant.id,
      status: form.schedule_type === "immediate" ? "sending" : "scheduled"
    };
    if (editing) {
      await EmailCampaign.update(editing.id, payload);
    } else {
      await EmailCampaign.create(payload);
    }
    setShowForm(false);
    setEditing(null);
    load();
  };

  const sendTest = async (campaign) => {
    if (!testEmail) return;
    await SendEmail({
      to: testEmail,
      subject: `[TEST] ${campaign.subject}`,
      body: campaign.content || "(no content)"
    });
  };

  const audienceLabel = (a) => {
    switch(a) {
      case "vip_customers": return "VIP";
      case "regular_customers": return "Regulars";
      case "inactive_customers": return "Inactive";
      case "custom": return "Custom";
      default: return "All Customers";
    }
  };

  const totalRecipients = (a) => {
    switch(a) {
      case "vip_customers": return customers.filter(c => c.tags?.includes("VIP")).length;
      case "regular_customers": return customers.filter(c => c.order_count >= 3).length;
      case "inactive_customers": return customers.filter(c => {
        const last = c.last_visit_date ? new Date(c.last_visit_date) : null;
        if (!last) return true;
        const days = (Date.now() - last.getTime()) / (1000*60*60*24);
        return days > 60;
      }).length;
      case "custom": return 0;
      default: return customers.length;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Email Marketing</h2>
          <p className="text-slate-600 text-lg">Create campaigns and engage your customers</p>
        </div>
        <Button className="bg-purple-600 hover:bg-purple-700" onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> New Campaign
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Total Customers</p>
              <p className="text-2xl font-bold">{customers.length}</p>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">VIPs</p>
              <p className="text-2xl font-bold">{customers.filter(c => c.tags?.includes("VIP")).length}</p>
            </div>
            <Star className="w-8 h-8 text-emerald-500" />
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-6">
            <p className="text-sm text-slate-600 mb-1">Inactive (60+ days)</p>
            <p className="text-2xl font-bold">
              {customers.filter(c => {
                const last = c.last_visit_date ? new Date(c.last_visit_date) : null;
                if (!last) return true;
                const days = (Date.now() - last.getTime()) / (1000*60*60*24);
                return days > 60;
              }).length}
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <p className="text-sm text-slate-600 mb-2">Send Test Email</p>
            <div className="flex gap-2">
              <input className="border rounded px-3 py-2 flex-1" placeholder="you@company.com" value={testEmail} onChange={(e) => setTestEmail(e.target.value)} />
              <Button variant="outline" onClick={() => {
                if (campaigns[0]) sendTest(campaigns[0]);
              }}>
                <Send className="w-4 h-4 mr-1" /> Send
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead>Name</TableHead>
                  <TableHead>Audience</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sent</TableHead>
                  <TableHead>Open Rate</TableHead>
                  <TableHead>Click Rate</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map(c => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.campaign_name}</TableCell>
                    <TableCell>{audienceLabel(c.target_audience)} ({totalRecipients(c.target_audience)})</TableCell>
                    <TableCell>
                      <Badge className={
                        c.status === "sent" ? "bg-green-100 text-green-800" :
                        c.status === "scheduled" ? "bg-blue-100 text-blue-800" :
                        c.status === "sending" ? "bg-amber-100 text-amber-800" :
                        "bg-slate-100 text-slate-800"
                      }>
                        {c.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{c.sent_count || 0}</TableCell>
                    <TableCell>{c.open_rate ? `${c.open_rate}%` : "—"}</TableCell>
                    <TableCell>{c.click_rate ? `${c.click_rate}%` : "—"}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => { setEditing(c); setShowForm(true); }}>
                          <Edit3 className="w-4 h-4 mr-1" /> Edit
                        </Button>
                        <Button size="sm" onClick={() => sendTest(c)}>
                          <Mail className="w-4 h-4 mr-1" /> Test
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {campaigns.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-10 text-slate-500">
                      No campaigns yet. Click "New Campaign" to create your first email.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {showForm && (
        <EmailCampaignForm
          initial={editing}
          onCancel={() => { setShowForm(false); setEditing(null); }}
          onSubmit={handleSave}
        />
      )}
    </div>
  );
}
