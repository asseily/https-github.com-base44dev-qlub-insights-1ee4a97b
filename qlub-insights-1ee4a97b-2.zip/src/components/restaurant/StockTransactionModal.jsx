import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StockTransaction, InventoryItem, User } from "@/api/entities";
import { X, Save, TrendingUp, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";

export default function StockTransactionModal({ isOpen, onClose, item, restaurant, onSave }) {
  const [formData, setFormData] = useState({
    transaction_type: 'restock',
    quantity_change: 0,
    reason: '',
    cost: 0
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const user = await User.me();
    
    const transactionData = {
      ...formData,
      restaurant_id: restaurant.id,
      inventory_item_id: item.id,
      performed_by: user.email,
      quantity_change: formData.transaction_type === 'usage' || formData.transaction_type === 'waste' 
        ? -Math.abs(formData.quantity_change) 
        : Math.abs(formData.quantity_change)
    };

    await StockTransaction.create(transactionData);

    // Update inventory item stock
    const newStock = item.current_stock + transactionData.quantity_change;
    const newStatus = newStock <= item.minimum_stock 
      ? (newStock <= 0 ? 'out_of_stock' : 'low_stock')
      : 'in_stock';

    await InventoryItem.update(item.id, {
      ...item,
      current_stock: Math.max(0, newStock),
      status: newStatus,
      last_restocked: formData.transaction_type === 'restock' ? new Date().toISOString() : item.last_restocked
    });
    
    onSave();
    onClose();
  };

  if (!isOpen || !item) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-lg"
        >
          <Card className="shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
              <CardTitle className="flex items-center gap-3">
                {formData.transaction_type === 'restock' ? 
                  <TrendingUp className="w-6 h-6" /> : 
                  <TrendingDown className="w-6 h-6" />
                }
                Stock Transaction: {item.name}
              </CardTitle>
              <p className="text-blue-100">Current Stock: {item.current_stock} {item.unit}</p>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="transaction_type">Transaction Type</Label>
                  <Select 
                    value={formData.transaction_type} 
                    onValueChange={(value) => setFormData(prev => ({...prev, transaction_type: value}))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="restock">📦 Restock (Add Inventory)</SelectItem>
                      <SelectItem value="usage">📉 Usage (Normal consumption)</SelectItem>
                      <SelectItem value="waste">🗑️ Waste (Expired/damaged)</SelectItem>
                      <SelectItem value="adjustment">⚖️ Adjustment (Stock count correction)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity_change">
                    Quantity ({item.unit})
                    {formData.transaction_type === 'usage' || formData.transaction_type === 'waste' ? ' to Remove' : ' to Add'}
                  </Label>
                  <Input
                    id="quantity_change"
                    type="number"
                    step="0.1"
                    value={Math.abs(formData.quantity_change)}
                    onChange={(e) => setFormData(prev => ({...prev, quantity_change: parseFloat(e.target.value) || 0}))}
                    required
                    min="0"
                  />
                </div>

                {formData.transaction_type === 'restock' && (
                  <div className="space-y-2">
                    <Label htmlFor="cost">Total Cost (AED)</Label>
                    <Input
                      id="cost"
                      type="number"
                      step="0.01"
                      value={formData.cost}
                      onChange={(e) => setFormData(prev => ({...prev, cost: parseFloat(e.target.value) || 0}))}
                      min="0"
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="reason">Reason/Notes</Label>
                  <Textarea
                    id="reason"
                    value={formData.reason}
                    onChange={(e) => setFormData(prev => ({...prev, reason: e.target.value}))}
                    placeholder="Optional reason for this transaction..."
                    className="h-20"
                  />
                </div>

                {/* Preview */}
                <div className="p-4 bg-slate-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Transaction Preview</h4>
                  <div className="text-sm space-y-1">
                    <p>Current Stock: {item.current_stock} {item.unit}</p>
                    <p className={`font-medium ${
                      (formData.transaction_type === 'usage' || formData.transaction_type === 'waste') 
                        ? 'text-red-600' : 'text-green-600'
                    }`}>
                      {formData.transaction_type === 'usage' || formData.transaction_type === 'waste' ? '-' : '+'}
                      {Math.abs(formData.quantity_change)} {item.unit}
                    </p>
                    <p className="border-t pt-1">
                      New Stock: {
                        Math.max(0, item.current_stock + 
                        ((formData.transaction_type === 'usage' || formData.transaction_type === 'waste') 
                          ? -Math.abs(formData.quantity_change) 
                          : Math.abs(formData.quantity_change)))
                      } {item.unit}
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-3 bg-slate-50 rounded-b-lg">
                <Button type="button" variant="outline" onClick={onClose}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  <Save className="w-4 h-4 mr-2" />
                  Record Transaction
                </Button>
              </CardFooter>
            </form>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}