import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { SendEmail } from "@/api/integrations";
import { Loader2, Send } from "lucide-react";

export default function SendPromoModal({ customer, restaurant, promotions, isOpen, onClose }) {
  const [selectedPromoId, setSelectedPromoId] = useState('');
  const [customMessage, setCustomMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const handleSend = async () => {
    if (!selectedPromoId) {
      alert("Please select a promotion to send.");
      return;
    }
    
    setIsSending(true);
    try {
      const selectedPromo = promotions.find(p => p.id === selectedPromoId);
      const emailBody = `
        <div style="font-family: Arial, sans-serif; line-height: 1.6;">
          <h2 style="color: ${restaurant.settings?.brand_color || '#6D28D9'};">A Special Offer from ${restaurant.name}!</h2>
          <p>Hello ${customer.name},</p>
          <p>Thank you for being a valued customer. As a token of our appreciation, please enjoy this special offer on your next visit.</p>
          
          ${customMessage ? `<p><strong>A message from us:</strong><br/><i>${customMessage.replace(/\n/g, '<br/>')}</i></p>` : ''}

          <div style="background-color: #f8f9fa; border-left: 4px solid ${restaurant.settings?.brand_color || '#6D28D9'}; padding: 15px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Your Promotion:</strong> ${selectedPromo.description}</p>
            <p style="margin: 5px 0 0 0;">Use code:</p>
            <h3 style="margin: 0; font-size: 24px; letter-spacing: 2px;">${selectedPromo.code}</h3>
          </div>
          
          <p>We look forward to seeing you soon!</p>
          <p>Best regards,<br/>The team at ${restaurant.name}</p>
        </div>
      `;

      await SendEmail({
        to: customer.email,
        from_name: restaurant.name,
        subject: `A Special Treat from ${restaurant.name}`,
        body: emailBody
      });

      alert("Promotional email sent successfully!");
      onClose();

    } catch (error) {
      console.error("Error sending promo email:", error);
      alert("Failed to send email. Please try again.");
    }
    setIsSending(false);
  };
  
  if (!customer) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send Promotion to {customer.name}</DialogTitle>
          <DialogDescription>
            Select a promotion and add a personal message to send to {customer.email}.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="promotion">Select Promotion</Label>
            <Select onValueChange={setSelectedPromoId}>
              <SelectTrigger id="promotion">
                <SelectValue placeholder="Choose a promotion..." />
              </SelectTrigger>
              <SelectContent>
                {promotions.map(promo => (
                  <SelectItem key={promo.id} value={promo.id}>
                    {promo.code} - {promo.description}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Custom Message (Optional)</Label>
            <Textarea
              id="message"
              placeholder="e.g., We miss you! Come back and enjoy a discount on us."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="h-24"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSend} disabled={isSending || !selectedPromoId}>
            {isSending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            Send Email
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}