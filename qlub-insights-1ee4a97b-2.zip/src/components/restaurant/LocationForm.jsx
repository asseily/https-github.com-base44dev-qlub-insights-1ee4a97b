import React, { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Save, X } from "lucide-react";
import { Location } from "@/api/entities";

export default function LocationForm({ restaurant, location, onClose, onSaved }) {
  const [form, setForm] = useState(location || {
    location_name: "",
    address: "",
    phone: "",
    manager_email: "",
    is_active: true,
    settings: {
      operating_hours: {},
      delivery_radius: 0,
      accepts_reservations: true
    }
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const payload = { ...form, restaurant_id: restaurant.id };
    if (location) {
      await Location.update(location.id, payload);
    } else {
      await Location.create(payload);
    }
    onSaved();
    onClose();
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle>{location ? "Edit Location" : "Add Location"}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSave}>
        <CardContent className="grid md:grid-cols-2 gap-6">
          <div>
            <Label>Location Name</Label>
            <Input value={form.location_name} name="location_name" onChange={handleChange} placeholder="Downtown Branch" required />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={form.phone} name="phone" onChange={handleChange} placeholder="+971 5x xxx xxxx" />
          </div>
          <div className="md:col-span-2">
            <Label>Address</Label>
            <Input value={form.address} name="address" onChange={handleChange} placeholder="Full address" />
          </div>
          <div className="md:col-span-2">
            <Label>Manager Email</Label>
            <Input value={form.manager_email} name="manager_email" onChange={handleChange} placeholder="manager@yourbrand.com" />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" /> Cancel
          </Button>
          <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
            <Save className="w-4 h-4 mr-2" /> Save
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}