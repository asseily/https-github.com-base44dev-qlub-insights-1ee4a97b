import React, { useEffect, useMemo, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { InvokeLLM } from "@/api/integrations";
import { Sun, Lightbulb, AlertTriangle, Loader2, Copy as CopyIcon, Printer, RefreshCw } from "lucide-react";

export default function DailyBriefing({ restaurant, orders = [], onRefresh }) {
  const [aiBriefing, setAiBriefing] = useState(null);
  const [localBriefing, setLocalBriefing] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastError, setLastError] = useState(null);
  const [copied, setCopied] = useState(false);

  const isOffline = typeof navigator !== "undefined" ? !navigator.onLine : false;
  const aiEnabled = restaurant?.settings?.ai_insights_enabled !== false;
  const currency = restaurant?.settings?.currency || "AED";

  // Today's basic metrics
  const todayMetrics = useMemo(() => {
    const todayStr = new Date().toDateString();
    const todaysOrders = (orders || []).filter(
      (o) => o?.created_date && new Date(o.created_date).toDateString() === todayStr
    );
    const revenue = todaysOrders.reduce((s, o) => s + (o?.total ?? 0), 0);
    const itemCounts = {};
    todaysOrders.forEach((o) => {
      (Array.isArray(o.items) ? o.items : []).forEach((it) => {
        const key = it?.menu_item_id || "unknown";
        const qty = Number(it?.quantity) || 0;
        itemCounts[key] = (itemCounts[key] || 0) + qty;
      });
    });
    const active = todaysOrders.filter((o) =>
      ["pending", "confirmed", "preparing", "ready"].includes(o.status)
    ).length;
    return { count: todaysOrders.length, revenue, topCounts: itemCounts, active };
  }, [orders]);

  // Local fallback generation (no network)
  const buildLocalBriefing = useCallback(() => {
    const name = restaurant?.name || "Your Restaurant";
    const noData = todayMetrics.count === 0 && Number(todayMetrics.revenue || 0) === 0;

    if (noData) {
      return {
        greeting: `Good morning, ${name}!`,
        key_insight: "Quiet start so far — no orders yet today.",
        positive_highlights: ["Team is ready for peak hours."],
        areas_for_attention: ["Verify menu availability and prep stations."],
        suggested_actions: ["Run a lunch special to drive early traffic."]
      };
    }

    return {
      greeting: `Good morning, ${name}!`,
      key_insight: `So far: ${todayMetrics.count} order${todayMetrics.count === 1 ? "" : "s"} — ${currency} ${Number(todayMetrics.revenue || 0).toFixed(2)} total. Active orders: ${todayMetrics.active}.`,
      positive_highlights: ["Steady start to operations."],
      areas_for_attention: ["Monitor prep times during lunch rush."],
      suggested_actions: ["Promote 1–2 popular items for upsell."]
    };
  }, [restaurant?.name, todayMetrics.count, todayMetrics.revenue, todayMetrics.active, currency]);

  // Simple retry helper for transient errors
  const withRetry = async (fn, retries = 2, baseDelayMs = 600) => {
    let attempt = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      try {
        return await fn();
      } catch (e) {
        attempt += 1;
        if (attempt > retries) throw e;
        await new Promise((res) => setTimeout(res, baseDelayMs * attempt));
      }
    }
  };

  const generateBriefing = useCallback(async () => {
    const noDataYet = todayMetrics.count === 0 && Number(todayMetrics.revenue || 0) === 0;
    const shouldUseLLM = aiEnabled && !isOffline && Boolean(restaurant?.name) && !noDataYet;

    // Fallback path: skip LLM when offline, disabled, or no data
    if (!shouldUseLLM) {
      const local = buildLocalBriefing();
      setAiBriefing(null);
      setLocalBriefing(local);
      setLastError(isOffline ? "Offline" : !aiEnabled ? "AI disabled" : "Insufficient data");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setLastError(null);
    setAiBriefing(null);
    setLocalBriefing(null);

    const prompt = `
You are an expert restaurant consultant AI.
Generate a concise, actionable morning briefing for the manager of "${restaurant.name}" for today.

Data:
- Total Orders Today: ${todayMetrics.count}
- Total Revenue Today: ${currency} ${Number(todayMetrics.revenue || 0).toFixed(2)}
- Active Orders: ${todayMetrics.active}
- Top item quantities (menu_item_id:qty): ${JSON.stringify(todayMetrics.topCounts)}

Output strictly as JSON with:
{
  "greeting": "Short, encouraging greeting",
  "key_insight": "Single most important insight from today's data",
  "positive_highlights": ["2-3 positives"],
  "areas_for_attention": ["2-3 risks to watch"],
  "suggested_actions": ["3-4 concrete actions for today"]
}
`.trim();

    try {
      const res = await withRetry(() =>
        InvokeLLM({
          prompt,
          response_json_schema: {
            type: "object",
            properties: {
              greeting: { type: "string" },
              key_insight: { type: "string" },
              positive_highlights: { type: "array", items: { type: "string" } },
              areas_for_attention: { type: "array", items: { type: "string" } },
              suggested_actions: { type: "array", items: { type: "string" } }
            }
          }
        })
      );

      // Basic shape guard
      const normalized = {
        greeting: res?.greeting || `Good morning, ${restaurant?.name || "team"}!`,
        key_insight: res?.key_insight || `Today's snapshot: ${todayMetrics.count} orders, ${currency} ${Number(todayMetrics.revenue || 0).toFixed(2)}.`,
        positive_highlights: Array.isArray(res?.positive_highlights) ? res.positive_highlights : ["Operations look stable."],
        areas_for_attention: Array.isArray(res?.areas_for_attention) ? res.areas_for_attention : ["Watch kitchen load during lunch."],
        suggested_actions: Array.isArray(res?.suggested_actions) ? res.suggested_actions : ["Upsell popular items.", "Tighten ticket times."]
      };

      setAiBriefing(normalized);
      setLocalBriefing(null);
      setIsLoading(false);
    } catch (e) {
      console.warn("AI briefing failed; using local fallback:", e);
      setLastError(e?.message || "AI error");
      setAiBriefing(null);
      setLocalBriefing(buildLocalBriefing());
      setIsLoading(false);
    }
  }, [aiEnabled, isOffline, restaurant?.name, currency, todayMetrics, buildLocalBriefing]);

  useEffect(() => {
    generateBriefing();
  }, [generateBriefing]);

  const current = aiBriefing || localBriefing;

  const copyBriefing = async () => {
    if (!current) return;
    const text = [
      current.greeting,
      "",
      `Key Insight: ${current.key_insight}`,
      "",
      "Positive Highlights:",
      ...(current.positive_highlights || []).map((v) => `• ${v}`),
      "",
      "Areas for Attention:",
      ...(current.areas_for_attention || []).map((v) => `• ${v}`),
      "",
      "Suggested Actions:",
      ...(current.suggested_actions || []).map((v) => `• ${v}`)
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch (err) {
      console.error("Copy failed:", err);
    }
  };

  const printBriefing = () => {
    if (!current) return;
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    w.document.write(`
      <html>
        <head>
          <title>Daily Briefing — ${restaurant?.name || "Restaurant"}</title>
          <style>
            body { font-family: Inter, Arial, sans-serif; padding: 24px; color: #0f172a; }
            h1 { margin: 0 0 8px 0; }
            .tag { display: inline-block; background: #eef2ff; color: #3730a3; padding: 4px 8px; border-radius: 999px; font-size: 12px; margin-bottom: 16px; }
            h2 { margin: 16px 0 8px 0; }
            ul { margin: 8px 0 16px 20px; }
            .muted { color: #64748b; font-size: 12px; }
          </style>
        </head>
        <body>
          <h1>Daily Briefing — ${restaurant?.name || "Restaurant"}</h1>
          <div class="tag">${aiBriefing ? "AI Insights" : "Local Summary"}</div>
          <p>${current.greeting}</p>
          <h2>Key Insight</h2>
          <p>${current.key_insight}</p>
          <h2>Positive Highlights</h2>
          <ul>${(current.positive_highlights || []).map((v) => `<li>${v}</li>`).join("")}</ul>
          <h2>Areas for Attention</h2>
          <ul>${(current.areas_for_attention || []).map((v) => `<li>${v}</li>`).join("")}</ul>
          <h2>Suggested Actions</h2>
          <ul>${(current.suggested_actions || []).map((v) => `<li>${v}</li>`).join("")}</ul>
          <p class="muted">Generated on ${new Date().toLocaleString()}</p>
          <script>window.onload = () => window.print();</script>
        </body>
      </html>
    `);
    w.document.close();
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Sun className="w-5 h-5 text-amber-500" />
          <CardTitle>Daily Briefing</CardTitle>
          <Badge variant={aiBriefing ? "default" : "outline"} className="ml-2">
            {aiBriefing ? "AI Insights" : "Local Summary"}
          </Badge>
          {(isOffline || !aiEnabled) && (
            <span className="ml-2 inline-flex items-center gap-1 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
              <AlertTriangle className="w-3 h-3" />
              {isOffline ? "Offline mode" : "AI disabled"}
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={copyBriefing} disabled={!current}>
            <CopyIcon className="w-4 h-4 mr-2" />
            {copied ? "Copied" : "Copy"}
          </Button>
          <Button variant="outline" size="sm" onClick={printBriefing} disabled={!current}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button size="sm" onClick={generateBriefing} disabled={isLoading}>
            {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            {isLoading ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading && (
          <div className="flex items-center gap-2 text-slate-600">
            <Loader2 className="w-4 h-4 animate-spin" />
            Generating briefing...
          </div>
        )}
        {!isLoading && current && (
          <>
            <div className="text-slate-900 font-medium">{current.greeting}</div>
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-amber-600 mt-0.5" />
              <div>
                <div className="text-sm font-semibold">Key Insight</div>
                <div className="text-sm text-slate-700">{current.key_insight}</div>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="border rounded-lg p-3">
                <div className="text-sm font-semibold mb-2">Positive Highlights</div>
                <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
                  {(current.positive_highlights || []).map((v, i) => <li key={i}>{v}</li>)}
                </ul>
              </div>
              <div className="border rounded-lg p-3">
                <div className="text-sm font-semibold mb-2">Areas for Attention</div>
                <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
                  {(current.areas_for_attention || []).map((v, i) => <li key={i}>{v}</li>)}
                </ul>
              </div>
              <div className="border rounded-lg p-3">
                <div className="text-sm font-semibold mb-2">Suggested Actions</div>
                <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
                  {(current.suggested_actions || []).map((v, i) => <li key={i}>{v}</li>)}
                </ul>
              </div>
            </div>

            <div className="text-xs text-slate-500">
              Snapshot for today: {todayMetrics.count} orders, {currency} {Number(todayMetrics.revenue || 0).toFixed(2)} revenue, {todayMetrics.active} active orders.
            </div>
          </>
        )}
        {!isLoading && !current && (
          <div className="text-slate-600">No briefing available.</div>
        )}
      </CardContent>
    </Card>
  );
}