
import React, { useState, useEffect } from 'react';
import { Restaurant } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { UploadFile } from "@/api/integrations";
import { Save, Upload, Image as ImageIcon, Palette, Loader2, X, Brain } from "lucide-react";

const colorSwatches = [
  "#6D28D9", // Purple (Default)
  "#DB2777", // Pink
  "#059669", // Emerald
  "#2563EB", // Blue
  "#EA580C", // Orange
  "#D97706", // Amber
];

export default function RestaurantSettings({ restaurant, onSave }) {
  const [formData, setFormData] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (restaurant) {
      setFormData({
        id: restaurant.id,
        name: restaurant.name || '',
        description: restaurant.description || '',
        address: restaurant.address || '',
        phone: restaurant.phone || '',
        cuisine_type: restaurant.cuisine_type || '',
        settings: {
          logo_url: restaurant.settings?.logo_url || '',
          brand_color: restaurant.settings?.brand_color || '#6D28D9',
          currency: restaurant.settings?.currency || 'AED',
          service_charge: restaurant.settings?.service_charge ?? 0,
          tax_rate: restaurant.settings?.tax_rate ?? 5,
          tip_suggestions: restaurant.settings?.tip_suggestions || [10, 15, 20],
          payment_gateway_mode: restaurant.settings?.payment_gateway_mode || 'simulated',
          payment_gateway_provider: restaurant.settings?.payment_gateway_provider || 'stripe',
          pos_sync_mode: restaurant.settings?.pos_sync_mode || 'off',
          ai_insights_enabled: restaurant.settings?.ai_insights_enabled !== false // default true
        },
      });
    } else {
       setFormData({
        name: '', description: '', address: '', phone: '', cuisine_type: '',
        settings: { 
          logo_url: '', 
          brand_color: '#6D28D9', 
          currency: 'AED', 
          service_charge: 0, 
          tax_rate: 5, 
          tip_suggestions: [10, 15, 20],
          payment_gateway_mode: 'simulated',
          payment_gateway_provider: 'stripe',
          pos_sync_mode: 'off',
          ai_insights_enabled: true
        }
      });
    }
  }, [restaurant]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSettingsChange = (e) => {
    const { name, value } = e.target;
    const numericFields = new Set(['service_charge', 'tax_rate']);
    const nextValue = numericFields.has(name) ? (value === '' ? '' : Number(value)) : value; // coerce to number when applicable
    setFormData(prev => ({
      ...prev,
      settings: { ...prev.settings, [name]: nextValue }
    }));
  };
  
  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({
        ...prev,
        settings: { ...prev.settings, logo_url: file_url }
      }));
    } catch (error) {
      console.error("Error uploading image:", error);
    }
    setIsUploading(false);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      if (formData.id) {
        await Restaurant.update(formData.id, formData);
      } else {
        await Restaurant.create(formData);
      }
      onSave();
    } catch (error) {
      console.error("Error saving settings:", error);
    }
    setIsSaving(false);
  };

  if (!formData) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Restaurant Details */}
      <Card className="shadow-lg border-0">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-900">Restaurant Details</CardTitle>
          <p className="text-slate-600">Update your restaurant's core information.</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Restaurant Name</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleInputChange} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cuisine_type">Cuisine Type</Label>
              <Input id="cuisine_type" name="cuisine_type" value={formData.cuisine_type} onChange={handleInputChange} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} />
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" name="address" value={formData.address} onChange={handleInputChange} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Branding */}
      <Card className="shadow-lg border-0">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-900 flex items-center gap-3">
            <Palette className="w-6 h-6 text-purple-600" />
            Branding
          </CardTitle>
          <p className="text-slate-600">Customize the look and feel of your customer-facing pages.</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Logo</Label>
            <div className="flex items-center gap-6">
              <div className="relative">
                {formData.settings.logo_url ? (
                  <img src={formData.settings.logo_url} alt="Logo" className="w-24 h-24 object-contain rounded-lg bg-slate-100 p-2" />
                ) : (
                  <div className="w-24 h-24 bg-slate-100 rounded-lg flex items-center justify-center">
                    <ImageIcon className="w-10 h-10 text-slate-400" />
                  </div>
                )}
              </div>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  disabled={isUploading}
                />
                <Button type="button" variant="outline" className="w-full" disabled={isUploading}>
                  {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Upload className="w-4 h-4 mr-2" />}
                  {isUploading ? 'Uploading...' : 'Upload Logo'}
                </Button>
                <p className="text-xs text-slate-500 mt-2">Recommended: PNG with transparent background.</p>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <Label>Brand Color</Label>
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex gap-2">
                {colorSwatches.map(color => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => handleSettingsChange({ target: { name: 'brand_color', value: color } })}
                    className={`w-8 h-8 rounded-full transition-all duration-200 ${formData.settings.brand_color === color ? 'ring-2 ring-offset-2 ring-purple-600' : ''}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-md border" style={{backgroundColor: formData.settings.brand_color}} />
                <Input
                  name="brand_color"
                  value={formData.settings.brand_color}
                  onChange={handleSettingsChange}
                  className="w-32"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* NEW: AI & Insights */}
      <Card className="shadow-lg border-0">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-900 flex items-center gap-3">
            <Brain className="w-6 h-6 text-purple-600" />
            AI & Insights
          </CardTitle>
          <p className="text-slate-600">
            Control AI-generated insights across your dashboard. When disabled, the app will use local summaries only.
          </p>
        </CardHeader>
        <CardContent className="flex items-center justify-between gap-4">
          <div>
            <div className="font-medium text-slate-900">Enable AI insights</div>
            <div className="text-sm text-slate-600">Affects Morning Briefing and Advanced Analytics.</div>
          </div>
          <Switch
            checked={!!formData?.settings?.ai_insights_enabled}
            onCheckedChange={(checked) =>
              setFormData((prev) => ({
                ...prev,
                settings: { ...prev.settings, ai_insights_enabled: checked }
              }))
            }
          />
        </CardContent>
      </Card>

      {/* Financial Settings */}
      <Card className="shadow-lg border-0">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-900">Financial Settings</CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <Label htmlFor="currency">Currency</Label>
            <Input id="currency" name="currency" value={formData.settings.currency} onChange={handleSettingsChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="tax_rate">Tax Rate (%)</Label>
            <Input id="tax_rate" name="tax_rate" type="number" value={formData.settings.tax_rate} onChange={handleSettingsChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="service_charge">Service Charge (%)</Label>
            <Input id="service_charge" name="service_charge" type="number" value={formData.settings.service_charge} onChange={handleSettingsChange} />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-lg border-0">
        <CardHeader>
          <CardTitle className="text-2xl text-slate-900">Integrations</CardTitle>
          <p className="text-slate-600">Configure payments and POS synchronization (requires backend).</p>
        </CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <Label>Payment Processing</Label>
            <Select
              value={formData.settings.payment_gateway_mode}
              onValueChange={(v) =>
                setFormData((prev) => ({ ...prev, settings: { ...prev.settings, payment_gateway_mode: v } }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="simulated">Simulated (no real charge)</SelectItem>
                <SelectItem value="backend">Backend (real gateway)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              Backend mode requires your server to expose /api/payments/create-session and webhooks.
            </p>
          </div>

          <div className="space-y-2">
            <Label>Payment Provider</Label>
            <Select
              value={formData.settings.payment_gateway_provider}
              onValueChange={(v) =>
                setFormData((prev) => ({ ...prev, settings: { ...prev.settings, payment_gateway_provider: v } }))
              }
              disabled={formData.settings.payment_gateway_mode !== 'backend'}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stripe">Stripe</SelectItem>
                <SelectItem value="checkout">Checkout.com</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              We’ll pass this provider to your backend when creating sessions.
            </p>
          </div>

          <div className="space-y-2">
            <Label>POS Sync Mode</Label>
            <Select
              value={formData.settings.pos_sync_mode}
              onValueChange={(v) =>
                setFormData((prev) => ({ ...prev, settings: { ...prev.settings, pos_sync_mode: v } }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="off">Off</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              When enabled, order status changes will be POSTed to your backend for POS sync.
            </p>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-end pt-4">
        <Button size="lg" onClick={handleSave} disabled={isSaving} style={{ backgroundColor: formData.settings.brand_color }}>
          {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Save className="w-4 h-4 mr-2" />}
          {isSaving ? 'Saving...' : 'Save All Settings'}
        </Button>
      </div>
    </div>
  );
}
