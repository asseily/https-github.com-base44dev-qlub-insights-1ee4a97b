import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Settings, Zap, AlertCircle } from 'lucide-react';

export default function AutoReorderSettings({ restaurant, inventory, suppliers }) {
  const [autoReorderEnabled, setAutoReorderEnabled] = useState(false);

  const eligibleItems = inventory.filter(item => 
    item.status === 'low_stock' && 
    suppliers.some(s => s.categories?.includes(item.category) && s.status === 'active')
  );

  return (
    <div className="space-y-6">
      <Card className="border-amber-200 bg-amber-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-amber-800">
            <Settings className="w-5 h-5" />
            Intelligent Auto-Reorder System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold">Enable Auto-Reorder</h4>
              <p className="text-sm text-slate-600">
                Automatically create purchase orders when items fall below minimum stock
              </p>
            </div>
            <Switch 
              checked={autoReorderEnabled}
              onCheckedChange={setAutoReorderEnabled}
            />
          </div>
          
          {autoReorderEnabled && (
            <div className="p-4 bg-white rounded-lg border">
              <h4 className="font-semibold flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-blue-600" />
                Auto-Reorder Rules
              </h4>
              <div className="space-y-2 text-sm">
                <p>✅ Create PO when stock ≤ minimum level</p>
                <p>✅ Order quantity = (maximum stock - current stock)</p>
                <p>✅ Use preferred supplier from item settings</p>
                <p>✅ Set delivery date = supplier's next delivery day</p>
                <p>✅ Send notification to manager for approval</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Items Eligible for Auto-Reorder</CardTitle>
        </CardHeader>
        <CardContent>
          {eligibleItems.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 mx-auto text-slate-300 mb-3" />
              <p className="text-slate-600">No items currently eligible for auto-reorder</p>
              <p className="text-sm text-slate-500">Items need to be low stock and have active suppliers</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Current/Min Stock</TableHead>
                  <TableHead>Preferred Supplier</TableHead>
                  <TableHead>Auto-Reorder Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {eligibleItems.map(item => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>
                      <span className="text-red-600 font-medium">
                        {item.current_stock}
                      </span>
                      /{item.minimum_stock} {item.unit}
                    </TableCell>
                    <TableCell>
                      {suppliers.find(s => 
                        s.categories?.includes(item.category) && s.status === 'active'
                      )?.name || 'No preferred supplier'}
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-800">
                        Ready for Auto-Reorder
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}