
import React, { useState } from 'react';
import { MenuItem } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Eye, 
  EyeOff,
  Star,
  TrendingUp,
  DollarSign,
  Package,
  AlertTriangle,
  Download 
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import MenuItemForm from "./MenuItemForm";
import MenuItemCard from "./MenuItemCard";

export default function MenuManagement({ restaurant, menuItems, refreshData }) {
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [activeTab, setActiveTab] = useState("items");

  const handleSubmit = async (itemData) => {
    const fullItemData = {
      ...itemData,
      restaurant_id: restaurant.id
    };

    if (editingItem) {
      await MenuItem.update(editingItem.id, fullItemData);
    } else {
      await MenuItem.create(fullItemData);
    }
    
    setShowForm(false);
    setEditingItem(null);
    refreshData();
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setShowForm(true);
  };

  const toggleAvailability = async (item) => {
    await MenuItem.update(item.id, { 
      ...item, 
      available: !item.available 
    });
    refreshData();
  };

  const filteredAndSortedItems = () => {
    let filtered = menuItems.filter(item => {
      const name = (item.name || "").toLowerCase();
      const desc = (item.description || "").toLowerCase();
      const matchesSearch = name.includes(searchTerm.toLowerCase()) ||
                           desc.includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
      const matchesStatus = statusFilter === "all" || 
                           (statusFilter === "available" && item.available) ||
                           (statusFilter === "unavailable" && !item.available) ||
                           (statusFilter === "featured" && item.featured);
      
      return matchesSearch && matchesCategory && matchesStatus;
    });

    // Sort items
    filtered.sort((a, b) => {
      switch(sortBy) {
        case 'name':
          return (a.name || "").localeCompare(b.name || "");
        case 'price':
          return (a.price ?? 0) - (b.price ?? 0);
        case 'category':
          return (a.category || "").localeCompare((b.category || ""));
        case 'featured':
          return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
        default:
          return 0;
      }
    });

    return filtered;
  };

  const getMenuStats = () => {
    const total = menuItems.length;
    const available = menuItems.filter(item => item.available).length;
    const featured = menuItems.filter(item => item.featured).length;
    const avgPrice = total > 0 ? menuItems.reduce((sum, item) => sum + (item.price ?? 0), 0) / total : 0;
    
    const categories = {};
    menuItems.forEach(item => {
      categories[item.category] = (categories[item.category] || 0) + 1;
    });

    return { total, available, featured, avgPrice, categories };
  };

  const stats = getMenuStats();
  const currency = restaurant?.settings?.currency || 'AED';
  const filteredItems = filteredAndSortedItems();

  // NEW: Export filtered items to CSV
  const exportMenuCSV = () => {
    const headers = ["Name","Category","Price","Available","Featured","Allergens","Dietary Info"];
    const rows = filteredItems.map(item => ([
      item.name || "",
      item.category || "",
      (item.price ?? 0).toFixed(2),
      item.available ? "Yes" : "No",
      item.featured ? "Yes" : "No",
      (item.allergens || []).join("|"),
      (item.dietary_info || []).join("|")
    ]));
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `menu_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Menu Management</h2>
          <p className="text-slate-600 text-lg">Manage your restaurant's digital menu</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportMenuCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Menu Item
          </Button>
        </div>
      </div>

      {/* Menu Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Total Items</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Package className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Available</p>
                <p className="text-2xl font-bold">{stats.available}</p>
                <p className="text-green-200 text-xs">
                  {stats.total ? ((stats.available / stats.total) * 100).toFixed(0) : 0}% of menu
                </p>
              </div>
              <Eye className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-amber-500 to-amber-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-100 text-sm">Featured Items</p>
                <p className="text-2xl font-bold">{stats.featured}</p>
              </div>
              <Star className="w-8 h-8 text-amber-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-100 text-sm">Avg Price</p>
                <p className="text-2xl font-bold">{currency} {stats.avgPrice.toFixed(0)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-emerald-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white p-1 shadow-sm border border-slate-200 rounded-lg">
          <TabsTrigger value="items" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Menu Items
          </TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Categories
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="items" className="space-y-6">
          {/* Search and Filters */}
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search menu items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <div className="flex gap-4">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="appetizers">🥗 Appetizers</SelectItem>
                      <SelectItem value="mains">🍽️ Mains</SelectItem>
                      <SelectItem value="desserts">🍰 Desserts</SelectItem>
                      <SelectItem value="drinks">🥤 Drinks</SelectItem>
                      <SelectItem value="sides">🍟 Sides</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Items</SelectItem>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="unavailable">Unavailable</SelectItem>
                      <SelectItem value="featured">Featured</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">Name</SelectItem>
                      <SelectItem value="price">Price</SelectItem>
                      <SelectItem value="category">Category</SelectItem>
                      <SelectItem value="featured">Featured</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Menu Item Form */}
          {showForm && (
            <MenuItemForm
              item={editingItem}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingItem(null);
              }}
            />
          )}

          {/* Menu Items Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredItems.map((item) => (
                <MenuItemCard
                  key={item.id}
                  item={item}
                  onEdit={handleEdit}
                  onToggleAvailability={toggleAvailability}
                />
              ))}
            </AnimatePresence>
          </div>

          {filteredItems.length === 0 && (
            <Card className="shadow-lg">
              <CardContent className="text-center py-12">
                <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  {menuItems.length === 0 ? "No menu items yet" : "No items match your filters"}
                </h3>
                <p className="text-slate-600 mb-6">
                  {menuItems.length === 0 
                    ? "Start building your digital menu by adding your first item"
                    : "Try adjusting your search terms or filters"
                  }
                </p>
                <Button 
                  onClick={() => setShowForm(true)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Menu Item
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="categories">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Menu Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(stats.categories).map(([category, count]) => (
                  <Card key={category} className="border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-slate-900 capitalize">
                            {category.replace('_', ' ')}
                          </h4>
                          <p className="text-sm text-slate-600">{count} items</p>
                        </div>
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Menu Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <TrendingUp className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Analytics Coming Soon</h3>
                <p className="text-slate-600">
                  Menu performance analytics will be available once you have order data
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
