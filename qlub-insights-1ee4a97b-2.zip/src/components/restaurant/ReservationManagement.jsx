
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Calendar as CalendarIcon,
  Users,
  Phone,
  Mail,
  Plus,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle
} from 'lucide-react';
import { format, startOfDay, endOfDay, addDays } from 'date-fns';
import { Reservation, Table as RestaurantTable } from "@/api/entities";

import ReservationForm from './ReservationForm';
import ReservationCalendarView from './ReservationCalendarView';

export default function ReservationManagement({ restaurant, tables, refreshData }) {
  const [reservations, setReservations] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [editingReservation, setEditingReservation] = useState(null);
  const [activeTab, setActiveTab] = useState('today');

  // NEW: offline detection and retry helper (component-local)
  const [isOffline, setIsOffline] = useState(typeof navigator !== "undefined" ? !navigator.onLine : false);
  const withRetry = useCallback(async (fn, retries = 3, base = 600) => {
    let attempt = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      try { return await fn(); }
      catch (e) {
        attempt += 1;
        if (attempt >= retries) throw e;
        await new Promise(r => setTimeout(r, base * attempt));
      }
    }
  }, []);

  useEffect(() => {
    const onOnline = () => setIsOffline(false);
    const onOffline = () => setIsOffline(true);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  const loadReservations = useCallback(async () => {
    if (!restaurant) return;
    if (isOffline) return; // skip calls when offline
    try {
      const data = await withRetry(() => Reservation.filter({
        restaurant_id: restaurant.id
      }, '-reservation_date', 100));

      setReservations(data);
    } catch (error) {
      console.error("Error loading reservations:", error);
    }
  }, [restaurant, withRetry, isOffline]);

  useEffect(() => {
    loadReservations();
  }, [loadReservations, selectedDate]);

  const updateReservationStatus = async (reservationId, newStatus) => {
    try {
      const reservation = reservations.find(r => r.id === reservationId);
      await Reservation.update(reservationId, {
        ...reservation,
        status: newStatus
      });
      loadReservations();
    } catch (error) {
      console.error("Error updating reservation:", error);
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'no_show': return 'bg-gray-100 text-gray-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const todaysReservations = reservations.filter(r => {
    const resDate = new Date(r.reservation_date);
    const today = new Date();
    return resDate.toDateString() === today.toDateString();
  });

  const upcomingReservations = reservations.filter(r => {
    const resDate = new Date(r.reservation_date);
    const today = new Date();
    const nextWeek = addDays(today, 7);
    return resDate > today && resDate <= nextWeek;
  });

  const confirmedToday = todaysReservations.filter(r => r.status === 'confirmed').length;
  const pendingToday = todaysReservations.filter(r => r.status === 'pending').length;

  return (
    <div className="space-y-8">
      {/* Offline note to reduce confusion */}
      {isOffline && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm px-4 py-2 rounded-md flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          You are offline. Reservations will refresh automatically when connection is restored.
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Reservation Management</h2>
          <p className="text-slate-600">Manage bookings and table availability</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Reservation
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Today - Confirmed</p>
                <p className="text-2xl font-bold">{confirmedToday}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm">Today - Pending</p>
                <p className="text-2xl font-bold">{pendingToday}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">This Week</p>
                <p className="text-2xl font-bold">{upcomingReservations.length}</p>
              </div>
              <CalendarIcon className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Capacity Today</p>
                <p className="text-2xl font-bold">
                  {Math.round((confirmedToday / (tables.length || 1)) * 100)}%
                </p>
              </div>
              <Users className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="today">Today's Reservations</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="today">
          <Card>
            <CardHeader>
              <CardTitle>Today's Reservations - {format(new Date(), 'EEEE, MMMM d, yyyy')}</CardTitle>
            </CardHeader>
            <CardContent>
              {todaysReservations.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <CalendarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No reservations for today</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Time</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Party Size</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {todaysReservations
                      .sort((a, b) => new Date(a.reservation_date) - new Date(b.reservation_date))
                      .map((reservation) => (
                      <TableRow key={reservation.id}>
                        <TableCell className="font-medium">
                          {format(new Date(reservation.reservation_date), 'h:mm a')}
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{reservation.customer_name}</p>
                            {reservation.special_requests && (
                              <p className="text-sm text-slate-600">{reservation.special_requests}</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4 text-slate-400" />
                            {reservation.party_size}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-sm">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {reservation.customer_phone}
                            </div>
                            {reservation.customer_email && (
                              <div className="flex items-center gap-2 text-sm">
                                <Mail className="w-3 h-3 text-slate-400" />
                                {reservation.customer_email}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(reservation.status)}>
                            {reservation.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {reservation.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-600 border-green-600"
                                  onClick={() => updateReservationStatus(reservation.id, 'confirmed')}
                                >
                                  <CheckCircle className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 border-red-600"
                                  onClick={() => updateReservationStatus(reservation.id, 'cancelled')}
                                >
                                  <XCircle className="w-4 h-4" />
                                </Button>
                              </>
                            )}
                            {reservation.status === 'confirmed' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => updateReservationStatus(reservation.id, 'completed')}
                              >
                                Complete
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Reservations (Next 7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              {upcomingReservations.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <CalendarIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No upcoming reservations</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {upcomingReservations
                    .sort((a, b) => new Date(a.reservation_date) - new Date(b.reservation_date))
                    .map((reservation) => (
                    <div key={reservation.id} className="border rounded-lg p-4 hover:bg-slate-50">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold">{reservation.customer_name}</h3>
                            <Badge className={getStatusColor(reservation.status)}>
                              {reservation.status}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-slate-600">
                            <div className="flex items-center gap-2">
                              <CalendarIcon className="w-4 h-4" />
                              {format(new Date(reservation.reservation_date), 'MMM d, h:mm a')}
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4" />
                              {reservation.party_size} guests
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="w-4 h-4" />
                              {reservation.customer_phone}
                            </div>
                          </div>
                          {reservation.special_requests && (
                            <p className="text-sm text-slate-500 mt-2">
                              Special requests: {reservation.special_requests}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingReservation(reservation);
                              setShowForm(true);
                            }}
                          >
                            Edit
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <ReservationCalendarView
            reservations={reservations}
            restaurant={restaurant}
            onDateSelect={setSelectedDate}
          />
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Reservation Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold mb-3">Business Hours</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Monday - Thursday:</span>
                      <span>11:00 AM - 11:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Friday - Saturday:</span>
                      <span>11:00 AM - 12:00 AM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sunday:</span>
                      <span>12:00 PM - 10:00 PM</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Reservation Policies</h4>
                  <div className="space-y-2 text-sm text-slate-600">
                    <p>• Maximum party size: 12 people</p>
                    <p>• Advance booking: Up to 30 days</p>
                    <p>• Cancellation: 24 hours notice</p>
                    <p>• No-show policy: 15 minute grace period</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Forms */}
      {showForm && (
        <ReservationForm
          reservation={editingReservation}
          restaurant={restaurant}
          tables={tables}
          onClose={() => {
            setShowForm(false);
            setEditingReservation(null);
          }}
          onSave={loadReservations}
        />
      )}
    </div>
  );
}
