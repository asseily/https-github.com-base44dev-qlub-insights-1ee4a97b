
import React, { useState } from 'react';
import { Staff } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Plus,
  Search,
  UserCheck,
  Users,
  Clock,
  DollarSign,
  Filter,
  Edit,
  Eye,
  Calendar,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import StaffMemberModal from "./StaffMemberModal";

export default function StaffManagement({ restaurant, staff, refreshData }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [editingStaff, setEditingStaff] = useState(null);
  const currency = restaurant?.settings?.currency || 'AED';

  const filteredStaff = staff.filter(member => {
    const term = (searchTerm || '').toLowerCase();
    const matchesSearch =
      (member.full_name || '').toLowerCase().includes(term) ||
      (member.email || '').toLowerCase().includes(term) ||
      (member.employee_id || '').toLowerCase().includes(term);
    const matchesRole = roleFilter === 'all' || member.role === roleFilter;
    const matchesStatus = statusFilter === 'all' || member.status === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      case 'inactive': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'on_leave': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getRoleColor = (role) => {
    switch(role) {
      case 'manager': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'chef': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'waiter': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cashier': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'host': return 'bg-pink-100 text-pink-800 border-pink-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const handleEditStaff = (member) => {
    setEditingStaff(member);
    setShowStaffModal(true);
  };

  const activeStaffCount = staff.filter(member => member.status === 'active').length;
  const onLeaveCount = staff.filter(member => member.status === 'on_leave').length;
  const totalPayroll = staff.reduce((sum, member) => {
    if (member.status === 'active' && member.hourly_rate) {
      return sum + (member.hourly_rate * 40 * 4); // Assuming 40 hours/week, 4 weeks/month
    }
    return sum;
  }, 0);

  // Export filtered staff to CSV
  const exportStaffCSV = () => {
    const headers = ["Full Name","Employee ID","Role","Email","Phone","Hourly Rate","Hire Date","Status"];
    const rows = filteredStaff.map(m => ([
      m.full_name || "",
      m.employee_id || "",
      m.role || "",
      m.email || "",
      m.phone || "",
      m.hourly_rate != null ? m.hourly_rate : "",
      m.hire_date ? new Date(m.hire_date).toLocaleDateString() : "",
      m.status || ""
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `staff_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Staff Management</h2>
          <p className="text-slate-600 text-lg">Manage employees, roles, and schedules</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportStaffCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button
            onClick={() => setShowStaffModal(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Staff Member
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Active Staff</p>
                <p className="text-2xl font-bold text-slate-900">{activeStaffCount}</p>
              </div>
              <UserCheck className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total Staff</p>
                <p className="text-2xl font-bold text-slate-900">{staff.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">On Leave</p>
                <p className="text-2xl font-bold text-slate-900">{onLeaveCount}</p>
              </div>
              <Clock className="w-8 h-8 text-amber-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Monthly Payroll</p>
                <p className="text-2xl font-bold text-slate-900">{currency} {totalPayroll.toFixed(0)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search staff members..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="chef">Chef</SelectItem>
                <SelectItem value="waiter">Waiter</SelectItem>
                <SelectItem value="cashier">Cashier</SelectItem>
                <SelectItem value="host">Host</SelectItem>
                <SelectItem value="kitchen_assistant">Kitchen Assistant</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="on_leave">On Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Staff Table */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Staff Members ({filteredStaff.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead className="font-semibold">Employee</TableHead>
                  <TableHead className="font-semibold">ID</TableHead>
                  <TableHead className="font-semibold">Role</TableHead>
                  <TableHead className="font-semibold">Contact</TableHead>
                  <TableHead className="font-semibold">Hourly Rate</TableHead>
                  <TableHead className="font-semibold">Hire Date</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {filteredStaff.map((member) => (
                    <motion.tr
                      key={member.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="hover:bg-slate-50 transition-colors"
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-purple-100 text-purple-700 text-sm">
                              {((member.full_name || member.email || 'U').split(' ').map(n => n?.[0] || '').join('') || 'U').toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{member.full_name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{member.employee_id}</TableCell>
                      <TableCell>
                        <Badge className={getRoleColor(member.role)}>
                          <span className="capitalize">{member.role.replace('_', ' ')}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{member.email}</div>
                          <div className="text-slate-500">{member.phone}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {member.hourly_rate ? `${currency} ${member.hourly_rate}/hr` : 'N/A'}
                      </TableCell>
                      <TableCell>
                        {member.hire_date ? new Date(member.hire_date).toLocaleDateString() : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(member.status)}>
                          <span className="capitalize">{member.status.replace('_', ' ')}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditStaff(member)}
                            className="h-8 w-8"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                          >
                            <Calendar className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>

          {filteredStaff.length === 0 && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-slate-400 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">No staff members found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm || roleFilter !== 'all' || statusFilter !== 'all'
                  ? "Try adjusting your search or filters"
                  : "Add your first staff member to get started"
                }
              </p>
              <Button onClick={() => setShowStaffModal(true)} className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Staff Member
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Staff Modal */}
      <StaffMemberModal
        isOpen={showStaffModal}
        onClose={() => {
          setShowStaffModal(false);
          setEditingStaff(null);
        }}
        staff={editingStaff}
        restaurant={restaurant}
        onSave={refreshData}
      />
    </div>
  );
}
