
import React, { useMemo } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Package, Calendar as CalendarIcon, Clock, TicketPercent, Truck, Users, UtensilsCrossed } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function NotificationsCenter({
  open,
  onOpenChange,
  restaurant,
  orders = [],
  inventory = [],
  reservations = [],
  promotions = [],
  purchaseOrders = [],
  staff = []
}) {
  const data = useMemo(() => {
    const today = new Date();
    const in7Days = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const lowStock = inventory.filter(i => i.status === "low_stock" || i.status === "out_of_stock");
    const activeOrders = orders.filter(o => ["pending", "confirmed", "preparing", "ready"].includes(o.status));
    const todayPendingReservations = reservations.filter(r => {
      const d = new Date(r.reservation_date);
      return d.toDateString() === today.toDateString() && r.status === "pending";
    });
    const expiringPromos = promotions.filter(p => {
      if (!p.is_active || !p.valid_to) return false;
      const end = new Date(p.valid_to);
      return end >= today && end <= in7Days;
    });
    const inFlightPOs = purchaseOrders.filter(po => ["sent", "confirmed"].includes(po.status));
    const onLeaveStaff = staff.filter(s => s.status === "on_leave");

    return {
      lowStock,
      activeOrders,
      todayPendingReservations,
      expiringPromos,
      inFlightPOs,
      onLeaveStaff,
      total: lowStock.length + activeOrders.length + todayPendingReservations.length + expiringPromos.length + inFlightPOs.length + onLeaveStaff.length
    };
  }, [inventory, orders, reservations, promotions, purchaseOrders, staff]);

  const goto = (tab) => createPageUrl(`RestaurantDashboard?tab=${tab}`);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center justify-between">
            Alerts & Notifications
            <Badge variant="secondary" className="ml-3">{data.total} total</Badge>
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Summary cards */}
          <div className="grid grid-cols-2 gap-3">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500">Low/Out of Stock</p>
                    <p className="text-xl font-bold">{data.lowStock.length}</p>
                  </div>
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500">Active Orders</p>
                    <p className="text-xl font-bold">{data.activeOrders.length}</p>
                  </div>
                  <UtensilsCrossed className="w-5 h-5 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500">Today Pending Res.</p>
                    <p className="text-xl font-bold">{data.todayPendingReservations.length}</p>
                  </div>
                  <Clock className="w-5 h-5 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500">Expiring Promos</p>
                    <p className="text-xl font-bold">{data.expiringPromos.length}</p>
                  </div>
                  <TicketPercent className="w-5 h-5 text-emerald-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Low stock */}
          <Card className="border-amber-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-amber-800">
                <AlertTriangle className="w-5 h-5" /> Inventory Alerts
                <Badge variant="outline" className="ml-2">{data.lowStock.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.lowStock.length === 0 ? (
                <p className="text-sm text-slate-500">No inventory alerts.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.lowStock.slice(0, 6).map(item => (
                    <div key={item.id} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-slate-500" />
                        <span className="font-medium">{item.name}</span>
                        <Badge variant="outline" className="capitalize">{item.status.replace("_"," ")}</Badge>
                      </div>
                      <span className="text-slate-500">Stock {item.current_stock}/{item.minimum_stock}</span>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to={goto("inventory")}>Go to Inventory</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Orders */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <UtensilsCrossed className="w-5 h-5 text-purple-600" /> Active Orders
                <Badge variant="outline" className="ml-2">{data.activeOrders.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.activeOrders.length === 0 ? (
                <p className="text-sm text-slate-500">No active orders.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.activeOrders.slice(0, 6).map(o => (
                    <div key={o.id} className="flex items-center justify-between text-sm">
                      <span className="font-medium">Order #{o.id.slice(-5)}</span>
                      <Badge className="capitalize">{o.status.replace("_"," ")}</Badge>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild size="sm" className="w-full">
                <Link to={goto("orders")}>Go to Orders</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Reservations */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-blue-600" /> Today's Reservations (Pending)
                <Badge variant="outline" className="ml-2">{data.todayPendingReservations.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.todayPendingReservations.length === 0 ? (
                <p className="text-sm text-slate-500">No pending reservations today.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.todayPendingReservations.slice(0, 6).map(r => (
                    <div key={r.id} className="flex items-center justify-between text-sm">
                      <span className="font-medium">{r.customer_name}</span>
                      <span className="text-slate-500">{new Date(r.reservation_date).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}</span>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to={goto("reservations")}>Go to Reservations</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Promotions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <TicketPercent className="w-5 h-5 text-emerald-600" /> Expiring Promotions (7 days)
                <Badge variant="outline" className="ml-2">{data.expiringPromos.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.expiringPromos.length === 0 ? (
                <p className="text-sm text-slate-500">No promotions expiring soon.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.expiringPromos.slice(0, 6).map(p => (
                    <div key={p.id} className="flex items-center justify-between text-sm">
                      <span className="font-medium">{p.code}</span>
                      <span className="text-slate-500">Ends {new Date(p.valid_to).toLocaleDateString()}</span>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild size="sm" className="w-full">
                <Link to={goto("promotions")}>Go to Promotions</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Purchase Orders */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-slate-700" /> Purchase Orders In-Flight
                <Badge variant="outline" className="ml-2">{data.inFlightPOs.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.inFlightPOs.length === 0 ? (
                <p className="text-sm text-slate-500">No active purchase orders.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.inFlightPOs.slice(0, 6).map(po => (
                    <div key={po.id} className="flex items-center justify-between text-sm">
                      <span className="font-medium">PO {po.order_number}</span>
                      <Badge className="capitalize">{po.status}</Badge>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to={goto("supply-chain")}>Go to Supply Chain</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Staff */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-pink-600" /> Staff On Leave
                <Badge variant="outline" className="ml-2">{data.onLeaveStaff.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.onLeaveStaff.length === 0 ? (
                <p className="text-sm text-slate-500">All staff available.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-auto pr-1">
                  {data.onLeaveStaff.slice(0, 6).map(s => (
                    <div key={s.id} className="flex items-center justify-between text-sm">
                      <span className="font-medium">{s.full_name}</span>
                      <Badge variant="secondary" className="capitalize">{s.status.replace("_"," ")}</Badge>
                    </div>
                  ))}
                </div>
              )}
              <Button asChild size="sm" className="w-full">
                <Link to={goto("staff")}>Go to Staff</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  );
}
