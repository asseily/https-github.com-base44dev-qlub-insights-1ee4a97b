
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  QrCode,
  Download,
  Printer,
  Eye,
  Copy,
  RefreshCw,
  FileText,
  Share2,
  Link as LinkIcon // Added LinkIcon
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function QRCodeGenerator({ restaurant, tables, defaultSelectedTable = "all" }) {
  const [selectedTable, setSelectedTable] = useState(defaultSelectedTable);
  const [qrSize, setQrSize] = useState("medium");
  const [includeTableNumber, setIncludeTableNumber] = useState(true);
  const [includeLogo, setIncludeLogo] = useState(true);
  const [version, setVersion] = useState(0); // for regenerate

  const sizeMap = {
    small: { size: "150x150", label: "Small (150px)" },
    medium: { size: "200x200", label: "Medium (200px)" },
    large: { size: "300x300", label: "Large (300px)" },
    xlarge: { size: "400x400", label: "X-Large (400px)" }
  };

  const generateMenuURL = (tableNumber) => {
    const baseUrl = window.location.origin;
    // Use consistent params: restaurant_id and both table and table_number
    return baseUrl + createPageUrl(`CustomerMenu?restaurant_id=${restaurant.id}&table=${tableNumber}&table_number=${tableNumber}`);
  };

  const generateQRCodeURL = (tableNumber) => {
    const menuUrl = generateMenuURL(tableNumber);
    // Dynamically set QR code size based on selected qrSize state, fallback to medium as per outline's logic
    const size = qrSize === "small" ? "150x150" : qrSize === "large" ? "300x300" : qrSize === "xlarge" ? "400x400" : "200x200";
    // Add cache-buster so Regenerate forces a fresh image
    return `https://api.qrserver.com/v1/create-qr-code/?size=${size}&data=${encodeURIComponent(menuUrl)}&cb=${version}`;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        // Optionally, add a toast notification here, e.g., alert("Link copied to clipboard!");
      })
      .catch(err => console.error('Failed to copy: ', err));
  };

  const downloadQRCode = (tableNumber) => {
    const qrUrl = generateQRCodeURL(tableNumber);
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = `${restaurant.name.toLowerCase().replace(/\s/g, '-')}-table-${tableNumber}-qr.png`;
    link.click();
  };

  const downloadAllQRCodes = () => {
    filteredTables.forEach(table => {
      setTimeout(() => downloadQRCode(table.table_number), 100);
    });
  };

  const previewTable = (tableNumber) => {
    const url = generateMenuURL(tableNumber);
    window.open(url, '_blank');
  };

  const handlePrintSetupGuide = () => {
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) return;
    const list = (selectedTable === "all" ? tables : tables.filter(t => t.id === selectedTable));
    const qrBlocks = list.map(t => `
      <div style="display:inline-block;width:280px;margin:12px;border:1px solid #e5e7eb;border-radius:12px;padding:16px;text-align:center;font-family:Inter,Arial,sans-serif;">
        ${includeLogo && restaurant?.settings?.logo_url ? `<img src="${restaurant.settings.logo_url}" alt="Logo" style="height:36px;object-fit:contain;margin-bottom:8px;" />` : ""}
        <img src="${generateQRCodeURL(t.table_number)}" alt="QR Table ${t.table_number}" style="width:180px;height:180px;"/>
        <div style="margin-top:8px;font-weight:700;color:#111827;">${restaurant.name}</div>
        <div style="color:#6b21a8;font-weight:600">${includeTableNumber ? `Table ${t.table_number}` : 'Scan to view menu & order'}</div>
        <div style="font-size:12px;color:#6b7280">Scan to view menu & order</div>
        <div style="font-size:10px;color:#9ca3af;margin-top:6px;">${generateMenuURL(t.table_number)}</div>
      </div>
    `).join("");
    printWindow.document.write(`
      <html>
        <head>
          <title>QR Codes - ${restaurant.name}</title>
          <meta name="viewport" content="width=device-width, initial-scale=1"/>
        </head>
        <body style="padding:24px; font-family:Inter,Arial,sans-serif;">
          <h1 style="font-family:Inter,Arial,sans-serif;color:#111827;">QR Codes for ${restaurant.name}</h1>
          <p style="font-family:Inter,Arial,sans-serif;color:#4b5563;">Print and place at each table. Ensure good lighting for easy scanning.</p>
          <div style="display: flex; flex-wrap: wrap; justify-content: center;">${qrBlocks}</div>
          <script>window.onload = () => window.print();</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleShare = (tableNumber) => {
    const url = generateMenuURL(tableNumber);
    if (navigator.share) {
      navigator.share({ title: `${restaurant.name} - Table ${tableNumber}`, text: "Scan to view the menu and order:", url })
        .catch((error) => console.log('Error sharing', error));
    } else {
      copyToClipboard(url);
      alert("Link copied to clipboard! You can share it manually.");
    }
  };

  const filteredTables = selectedTable === "all" ? tables : tables.filter(t => t.id === selectedTable);

  // NEW: print all currently filtered QR codes in a simple layout
  const printQRCodes = () => {
    const win = window.open("", "_blank");
    if (!win) return; // Handle popup blocker
    const style = `
      <style>
        body { font-family: sans-serif; padding: 24px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; justify-items: center;}
        .card { border: 1px solid #e5e7eb; border-radius: 12px; padding: 16px; text-align: center; width: 220px; box-sizing: border-box;}
        .title { font-weight: 600; margin-top: 8px; }
        .logo { height: 28px; object-fit: contain; margin-bottom: 8px; }
        img.qr { max-width: 200px; height: auto; object-fit: contain; }
        @media print {
            body { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
            .grid { page-break-inside: avoid; }
            .card { break-inside: avoid; }
        }
      </style>
    `;
    const content = `
      <div class="grid">
        ${filteredTables.map(t => {
          const imgSrc = generateQRCodeURL(t.table_number);
          const title = includeTableNumber ? `Table ${t.table_number}` : "Scan to Order";
          return `<div class="card">
            ${includeLogo && restaurant?.settings?.logo_url ? `<img src="${restaurant.settings.logo_url}" class="logo" alt="Logo" />` : ''}
            <img src="${imgSrc}" alt="${title}" class="qr" />
            <div class="title">${title}</div>
          </div>`;
        }).join("")}
      </div>
    `;
    win.document.write(`<html><head><title>Print QR Codes</title>${style}</head><body>${content}<script>window.onload=()=>win.print()</script></body></html>`);
    win.document.close();
  };

  // NEW: copy a menu link for the current selection
  const copyMenuLink = async () => {
    let url;
    if (selectedTable === "all") {
      url = window.location.origin + createPageUrl(`CustomerMenu?restaurant_id=${restaurant.id}`);
    } else {
      const t = tables.find(tb => tb.id === selectedTable);
      url = generateMenuURL(t?.table_number || "");
    }
    await navigator.clipboard.writeText(url)
      .then(() => {
        alert("Link copied to clipboard!");
      })
      .catch(err => console.error('Failed to copy menu link: ', err));
  };

  // NEW: export CSV with menu links for the current filtered tables
  const exportMenuLinksCSV = () => {
    const headers = ["Table Number","Menu URL","Status","Location"];
    const origin = window.location.origin;
    const rows = filteredTables.map(t => {
      const url = generateMenuURL(t.table_number); // already absolute, but ensure consistency
      return [
        t.table_number || "",
        url.startsWith("http") ? url : origin + url,
        t.status || "",
        t.location || ""
      ];
    });
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `qr_menu_links_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">QR Code Generator</h2>
          <p className="text-slate-600 text-lg">Generate and manage QR codes for your tables</p>
        </div>
        <div className="flex gap-3">
          <Button onClick={downloadAllQRCodes} className="bg-emerald-600 hover:bg-emerald-700">
            <Download className="w-4 h-4 mr-2" />
            Download All QR Codes
          </Button>
          <Button variant="outline" onClick={handlePrintSetupGuide}>
            <Printer className="w-4 h-4 mr-2" />
            Print Setup Guide
          </Button>
        </div>
      </div>

      {/* Controls */}
      <Card className="shadow-lg bg-gradient-to-r from-purple-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-purple-600" />
            QR Code Customization
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Select Table</label>
              <Select value={selectedTable} onValueChange={setSelectedTable}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tables</SelectItem>
                  {tables.map(table => (
                    <SelectItem key={table.id} value={table.id}>
                      Table {table.table_number}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">QR Code Size</label>
              <Select value={qrSize} onValueChange={setQrSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(sizeMap).map(([key, value]) => (
                    <SelectItem key={key} value={key}>
                      {value.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Restaurant Info</label>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="includeTableNumber"
                    checked={includeTableNumber}
                    onChange={(e) => setIncludeTableNumber(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="includeTableNumber" className="text-sm">Table Number</label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="includeLogo"
                    checked={includeLogo}
                    onChange={(e) => setIncludeLogo(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="includeLogo" className="text-sm">Logo</label>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Quick Actions</label>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setVersion(v => v + 1)}>
                  <RefreshCw className="w-4 h-4 mr-1" />
                  Regenerate
                </Button>
                <Button size="sm" variant="outline">
                  <FileText className="w-4 h-4 mr-1" />
                  Template
                </Button>
              </div>
            </div>
          </div>

          {/* NEW: Print and Copy Link buttons (within CardContent, after the grid) */}
          <div className="flex flex-wrap gap-3 mt-6 pt-4 border-t border-slate-100">
            <Button variant="outline" onClick={printQRCodes} className="flex items-center gap-2">
              <Printer className="w-4 h-4" /> Print Filtered QR Codes
            </Button>
            <Button variant="outline" onClick={copyMenuLink} className="flex items-center gap-2">
              <LinkIcon className="w-4 h-4" /> Copy Menu Link
            </Button>
            {/* NEW: Export links CSV */}
            <Button variant="outline" onClick={exportMenuLinksCSV} className="flex items-center gap-2">
              <Download className="w-4 h-4" /> Export Links CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* QR Codes Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredTables.map(table => (
          <Card key={table.id} className="shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-slate-800 to-slate-900 text-white">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-lg">Table {table.table_number}</CardTitle>
                  <p className="text-slate-300 text-sm">{table.location}</p>
                </div>
                <Badge className={table.status === 'available' ? 'bg-green-500' : 'bg-amber-500'}>
                  {table.status}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              {/* QR Code Display */}
              <div className="text-center mb-6">
                {includeLogo && restaurant?.settings?.logo_url && (
                  <img src={restaurant.settings.logo_url} alt="Logo" className="h-8 mx-auto mb-3 object-contain" />
                )}
                <div className="inline-block p-4 bg-white rounded-xl shadow-lg border-2 border-slate-100">
                  <img
                    src={generateQRCodeURL(table.table_number)}
                    alt={`QR Code for Table ${table.table_number}`}
                    className="w-32 h-32 mx-auto"
                  />
                </div>
                {includeTableNumber && (
                  <div className="mt-3">
                    <h3 className="font-bold text-slate-900">{restaurant.name}</h3>
                    <p className="text-lg font-semibold text-purple-600">Table {table.table_number}</p>
                    <p className="text-xs text-slate-500">Scan to view menu & order</p>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => downloadQRCode(table.table_number)}
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => previewTable(table.table_number)}
                    className="flex-1"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Preview
                  </Button>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyToClipboard(generateMenuURL(table.table_number))}
                    className="flex-1"
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy Link
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => handleShare(table.table_number)}>
                    <Share2 className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <p className="text-xs text-slate-500 break-all">
                    {generateMenuURL(table.table_number)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTables.length === 0 && (
        <Card className="shadow-lg">
          <CardContent className="text-center py-12">
            <QrCode className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No tables found</h3>
            <p className="text-slate-600 mb-6">Create tables first to generate QR codes</p>
            <Button asChild className="bg-purple-600 hover:bg-purple-700">
              <Link to={createPageUrl('RestaurantDashboard?tab=tables')}>Add Tables</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Setup Instructions */}
      <Card className="shadow-lg bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-xl text-blue-900">QR Code Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-blue-800 mb-2">For Physical Tables:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Download high-resolution QR codes (300px or larger)</li>
                <li>• Print on waterproof material for durability</li>
                <li>• Place in clear table tents or laminated stands</li>
                <li>• Ensure good lighting for easy scanning</li>
                <li>• Test with multiple devices before deployment</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-blue-800 mb-2">For Digital Display:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Use medium to large sizes for tablet displays</li>
                <li>• Ensure high contrast background</li>
                <li>• Include restaurant branding for recognition</li>
                <li>• Consider different QR codes for takeaway vs dine-in</li>
                <li>• Regularly update and regenerate codes</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
