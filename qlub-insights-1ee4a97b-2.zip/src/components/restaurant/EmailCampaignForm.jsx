import React, { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Save, X } from "lucide-react";

export default function EmailCampaignForm({ initial, onCancel, onSubmit }) {
  const [form, setForm] = useState(initial || {
    campaign_name: "",
    subject: "",
    content: "",
    target_audience: "all_customers",
    schedule_type: "immediate",
    scheduled_date: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle>{initial ? "Edit Campaign" : "Create Campaign"}</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="text-sm font-medium">Campaign Name</label>
            <Input name="campaign_name" value={form.campaign_name} onChange={handleChange} placeholder="Summer Specials" />
          </div>
          <div>
            <label className="text-sm font-medium">Subject</label>
            <Input name="subject" value={form.subject} onChange={handleChange} placeholder="Hot deals this week 🔥" />
          </div>
        </div>
        <div>
          <label className="text-sm font-medium">Audience</label>
          <Select value={form.target_audience} onValueChange={(v) => setForm(prev => ({ ...prev, target_audience: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all_customers">All Customers</SelectItem>
              <SelectItem value="vip_customers">VIP Customers</SelectItem>
              <SelectItem value="regular_customers">Regular Customers</SelectItem>
              <SelectItem value="inactive_customers">Inactive Customers</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm font-medium">Content (HTML supported)</label>
          <Textarea name="content" value={form.content} onChange={handleChange} rows={8} placeholder="<h1>Welcome back!</h1>" />
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="text-sm font-medium">Schedule</label>
            <Select value={form.schedule_type} onValueChange={(v) => setForm(prev => ({ ...prev, schedule_type: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Send Now</SelectItem>
                <SelectItem value="scheduled">Schedule</SelectItem>
                <SelectItem value="recurring">Recurring</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {form.schedule_type !== "immediate" && (
            <div>
              <label className="text-sm font-medium">Scheduled Date</label>
              <Input type="datetime-local" name="scheduled_date" value={form.scheduled_date} onChange={handleChange} />
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-end gap-3">
        <Button variant="outline" onClick={onCancel}><X className="w-4 h-4 mr-2" /> Cancel</Button>
        <Button className="bg-purple-600 hover:bg-purple-700" onClick={() => onSubmit(form)}><Save className="w-4 h-4 mr-2" /> Save</Button>
      </CardFooter>
    </Card>
  );
}