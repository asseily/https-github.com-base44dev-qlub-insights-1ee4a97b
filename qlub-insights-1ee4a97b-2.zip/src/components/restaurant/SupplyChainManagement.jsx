
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Truck,
  Package,
  Plus,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  Send,
  FileText,
  Download // Ensure Download icon is imported
} from 'lucide-react';
import { Supplier, PurchaseOrder, InventoryItem } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";

import SupplierForm from './SupplierForm';
import PurchaseOrderModal from './PurchaseOrderModal';
import AutoReorderSettings from './AutoReorderSettings';

export default function SupplyChainManagement({ restaurant, inventory, refreshData }) {
  const [suppliers, setSuppliers] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [showSupplierForm, setShowSupplierForm] = useState(false);
  const [showPOModal, setShowPOModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [isGeneratingRecommendations, setIsGeneratingRecommendations] = useState(false);
  const [reorderRecommendations, setReorderRecommendations] = useState([]);

  // NEW: connectivity + AI settings
  const isOffline = typeof navigator !== "undefined" ? !navigator.onLine : false;
  const aiEnabled = restaurant?.settings?.ai_insights_enabled !== false;
  const currency = restaurant?.settings?.currency || 'AED';

  const loadSupplyChainData = useCallback(async () => {
    if (!restaurant) return;

    try {
      const [supplierData, poData] = await Promise.all([
        Supplier.filter({ restaurant_id: restaurant.id }),
        PurchaseOrder.filter({ restaurant_id: restaurant.id }, '-order_date', 50)
      ]);

      setSuppliers(supplierData);
      setPurchaseOrders(poData);
    } catch (error) {
      console.error("Error loading supply chain data:", error);
    }
  }, [restaurant]);

  useEffect(() => {
    loadSupplyChainData();
  }, [loadSupplyChainData]);

  // NEW: local fallback generator
  const buildLocalRecommendations = useCallback((lowStockItems) => {
    const urgent_items = lowStockItems.slice(0, 8).map(item => {
      const base = Math.max(item.minimum_stock * 2 - (item.current_stock || 0), item.minimum_stock);
      const recommended_quantity = Math.max(Math.ceil(base), item.minimum_stock > 0 ? item.minimum_stock : 1);
      // naive supplier pick by category match
      const supplierCandidate = suppliers.find(s => Array.isArray(s.categories) && s.categories.includes(item.category));
      return {
        item_name: item.name,
        recommended_quantity,
        preferred_supplier: supplierCandidate?.name || (item.supplier || "Any preferred"),
        reason: `Stock ${item.current_stock}/${item.minimum_stock}. Replenish to ~2x min stock.`,
      };
    });

    const cost_optimization = [
      "Consolidate orders to preferred suppliers to reduce delivery fees.",
      "Compare unit costs across suppliers for top-3 high-volume SKUs.",
      "Schedule deliveries earlier in the week to avoid rush premiums."
    ];

    const supplier_recommendations = suppliers
      .filter(s => s.status === "active")
      .slice(0, 5)
      .map(s => `Prioritize ${s.name} for categories: ${(s.categories || []).slice(0,3).join(", ")}`);

    return { urgent_items, cost_optimization, supplier_recommendations };
  }, [suppliers]); // Dependency on suppliers state

  const generateReorderRecommendations = async () => {
    setIsGeneratingRecommendations(true);
    try {
      const lowStockItems = inventory.filter(item => item.current_stock <= item.minimum_stock);
      // Guard: if no low stock -> clear and return
      if (lowStockItems.length === 0) {
        setReorderRecommendations({ urgent_items: [], cost_optimization: [], supplier_recommendations: [] });
        setIsGeneratingRecommendations(false);
        return;
      }
      // Guard: if offline or AI disabled -> use local logic
      if (!aiEnabled || isOffline) {
        setReorderRecommendations(buildLocalRecommendations(lowStockItems));
        setIsGeneratingRecommendations(false);
        return;
      }

      // AI path
      const prompt = `
        As a supply chain expert, analyze these low stock items for ${restaurant.name} and provide intelligent reorder recommendations.

        Low Stock Items: ${JSON.stringify(lowStockItems.map(item => ({
          name: item.name,
          current_stock: item.current_stock,
          minimum_stock: item.minimum_stock,
          category: item.category,
          supplier: item.supplier
        })))}

        Available Suppliers: ${JSON.stringify(suppliers.map(s => ({
          name: s.name,
          categories: s.categories,
          rating: s.rating
        })))}

        Provide reorder recommendations:
      `;

      const recommendations = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            urgent_items: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  item_name: { type: "string" },
                  recommended_quantity: { type: "number" },
                  preferred_supplier: { type: "string" },
                  reason: { type: "string" }
                }
              }
            },
            cost_optimization: { type: "array", items: { type: "string" } },
            supplier_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Normalize response, fallback to local if AI returns empty or malformed
      if (!recommendations || (!Array.isArray(recommendations.urgent_items) && !Array.isArray(recommendations.cost_optimization))) {
        setReorderRecommendations(buildLocalRecommendations(lowStockItems));
      } else {
        setReorderRecommendations({
          urgent_items: Array.isArray(recommendations.urgent_items) ? recommendations.urgent_items : [],
          cost_optimization: Array.isArray(recommendations.cost_optimization) ? recommendations.cost_optimization : [],
          supplier_recommendations: Array.isArray(recommendations.supplier_recommendations) ? recommendations.supplier_recommendations : []
        });
      }
    } catch (error) {
      // Fallback on any error
      const lowStockItems = inventory.filter(item => item.current_stock <= item.minimum_stock);
      setReorderRecommendations(buildLocalRecommendations(lowStockItems));
      console.error("Error generating recommendations:", error);
    }
    setIsGeneratingRecommendations(false);
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'confirmed': return 'bg-blue-100 text-blue-800';
      case 'sent': return 'bg-purple-100 text-purple-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const lowStockCount = inventory.filter(item => item.current_stock <= item.minimum_stock).length;
  const activePOs = purchaseOrders.filter(po => ['sent', 'confirmed'].includes(po.status)).length;
  const totalSpent = purchaseOrders
    .filter(po => po.status === 'delivered')
    .reduce((sum, po) => sum + (po.total_amount || 0), 0); // FIX: guard undefined

  // Export Suppliers CSV (Updated per outline)
  const exportSuppliersCSV = () => {
    const headers = ["Name","Contact Person","Email","Phone","Categories","Payment Terms","Status","Rating"];
    const rows = suppliers.map(s => ([
      s.name || "",
      s.contact_person || "",
      s.email || "",
      s.phone || "",
      (s.categories || []).join("|"),
      s.payment_terms || "",
      s.status || "",
      s.rating != null ? s.rating : ""
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `suppliers_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export Purchase Orders CSV (Updated per outline)
  const exportPOsCSV = () => {
    const headers = ["PO Number","Supplier ID","Status","Order Date","Expected Delivery","Actual Delivery","Total Amount","Items Count"];
    const rows = purchaseOrders.map(po => ([
      po.order_number || "",
      po.supplier_id || "",
      po.status || "",
      po.order_date ? new Date(po.order_date).toLocaleString() : "",
      po.expected_delivery ? new Date(po.expected_delivery).toLocaleString() : "",
      po.actual_delivery ? new Date(po.actual_delivery).toLocaleString() : "",
      po.total_amount != null ? po.total_amount.toFixed(2) : "0.00",
      Array.isArray(po.items) ? po.items.length : 0
    ]));
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `purchase_orders_${restaurant?.name?.replace(/\s+/g,'_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Supply Chain Management</h2>
          <p className="text-slate-600">Intelligent procurement and supplier relationships</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportSuppliersCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export Suppliers CSV
          </Button>
          <Button variant="outline" onClick={exportPOsCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export POs CSV
          </Button>
          <Button
            variant="outline"
            onClick={generateReorderRecommendations}
            disabled={isGeneratingRecommendations || lowStockCount === 0}
            className="flex items-center gap-2"
          >
            {isGeneratingRecommendations ? <Clock className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
            {aiEnabled && !isOffline ? "AI Reorder Recommendations" : "Generate Recommendations"}
          </Button>
          <Button onClick={() => setShowSupplierForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Supplier
          </Button>
        </div>
      </div>

      {/* NEW: subtle status hint */}
      {(!aiEnabled || isOffline) && (
        <p className="text-xs text-slate-600">
          {isOffline ? "You're offline. " : ""}
          {!aiEnabled ? "AI insights are disabled in Settings. " : ""}
          We'll use local heuristics to suggest reorder quantities.
        </p>
      )}

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">Low Stock Items</p>
                <p className="text-2xl font-bold">{lowStockCount}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Active Orders</p>
                <p className="text-2xl font-bold">{activePOs}</p>
              </div>
              <Truck className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Monthly Spend</p>
                <p className="text-2xl font-bold">{currency} {totalSpent.toFixed(0)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Active Suppliers</p>
                <p className="text-2xl font-bold">{suppliers.filter(s => s.status === 'active').length}</p>
              </div>
              <Package className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Recommendations (now also used for local fallbacks) */}
      {reorderRecommendations.urgent_items && (reorderRecommendations.urgent_items.length > 0 || reorderRecommendations.cost_optimization?.length > 0 || reorderRecommendations.supplier_recommendations?.length > 0) && (
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-amber-800">
              <AlertTriangle className="w-5 h-5" />
              {aiEnabled && !isOffline ? "AI Reorder Recommendations" : "Reorder Recommendations"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Urgent Items</h4>
                <div className="space-y-2">
                  {reorderRecommendations.urgent_items.map((item, idx) => (
                    <div key={idx} className="p-3 bg-white rounded-lg border">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">{item.item_name}</p>
                          <p className="text-sm text-slate-600">Qty: {item.recommended_quantity} | Supplier: {item.preferred_supplier}</p>
                        </div>
                        <Button size="sm" variant="outline">
                          Create PO
                        </Button>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">{item.reason}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Cost Optimization Tips</h4>
                <ul className="space-y-2 text-sm">
                  {reorderRecommendations.cost_optimization?.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>

                {Array.isArray(reorderRecommendations.supplier_recommendations) && reorderRecommendations.supplier_recommendations.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-semibold mb-2">Supplier Recommendations</h4>
                    <ul className="space-y-1 text-sm text-slate-700 list-disc list-inside">
                      {reorderRecommendations.supplier_recommendations.map((s, i) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <Tabs defaultValue="suppliers" className="space-y-6">
        <TabsList>
          <TabsTrigger value="suppliers">Suppliers ({suppliers.length})</TabsTrigger>
          <TabsTrigger value="orders">Purchase Orders ({purchaseOrders.length})</TabsTrigger>
          <TabsTrigger value="automation">Auto-Reorder Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="suppliers">
          <Card>
            <CardHeader>
              <CardTitle>Supplier Directory</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Supplier</TableHead>
                    <TableHead>Categories</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {suppliers.map((supplier) => (
                    <TableRow key={supplier.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{supplier.name}</p>
                          <p className="text-sm text-slate-600">{supplier.contact_person}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {supplier.categories?.slice(0, 2).map((cat, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {cat}
                            </Badge>
                          ))}
                          {supplier.categories?.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{supplier.categories.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{supplier.email}</p>
                          <p className="text-sm text-slate-600">{supplier.phone}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span className="text-amber-500">★</span>
                          <span>{supplier.rating}/5</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={supplier.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
                          {supplier.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingSupplier(supplier);
                            setShowSupplierForm(true);
                          }}
                        >
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {suppliers.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-slate-500 py-8">
                        No suppliers found. Click "Add Supplier" to get started!
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Purchase Orders</CardTitle>
                <Button onClick={() => setShowPOModal(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Purchase Order
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>PO Number</TableHead>
                    <TableHead>Supplier</TableHead>
                    <TableHead>Order Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {purchaseOrders.map((po) => (
                    <TableRow key={po.id}>
                      <TableCell className="font-medium">{po.order_number}</TableCell>
                      <TableCell>
                        {suppliers.find(s => s.id === po.supplier_id)?.name || 'Unknown'}
                      </TableCell>
                      <TableCell>
                        {new Date(po.order_date).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{currency} {po.total_amount != null ? po.total_amount.toFixed(2) : "0.00"}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(po.status)}>
                          {po.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">
                            <FileText className="w-4 h-4" />
                          </Button>
                          {po.status === 'draft' && (
                            <Button variant="ghost" size="sm">
                              <Send className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {purchaseOrders.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-slate-500 py-8">
                        No purchase orders found. Click "Create Purchase Order" to start!
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation">
          <AutoReorderSettings
            restaurant={restaurant}
            inventory={inventory}
            suppliers={suppliers}
          />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {showSupplierForm && (
        <SupplierForm
          supplier={editingSupplier}
          restaurant={restaurant}
          onClose={() => {
            setShowSupplierForm(false);
            setEditingSupplier(null);
          }}
          onSave={loadSupplyChainData}
        />
      )}

      {showPOModal && (
        <PurchaseOrderModal
          restaurant={restaurant}
          suppliers={suppliers}
          inventory={inventory}
          onClose={() => setShowPOModal(false)}
          onSave={loadSupplyChainData}
        />
      )}
    </div>
  );
}
