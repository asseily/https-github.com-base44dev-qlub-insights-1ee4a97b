
import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { InvokeLLM } from "@/api/integrations";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  ClipboardList,
  Download,
  Brain,
  Lightbulb,
  AlertCircle,
  Loader2
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Area
} from 'recharts';
import { eachDayOfInterval, format, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter, subMonths, subQuarters, subYears, startOfYear, endOfYear } from 'date-fns';

const MetricCard = ({ title, value, change, icon: Icon, color }) => (
  <Card className="shadow-lg border-l-4" style={{borderColor: color}}>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {change && (
        <p className={`text-xs text-muted-foreground ${change.startsWith('+') ? 'text-emerald-500' : 'text-red-500'}`}>
          {change} vs last period
        </p>
      )}
    </CardContent>
  </Card>
);

export default function FinancialReporting({ restaurant, orders, purchaseOrders }) {
  const [period, setPeriod] = useState('this_month');
  const [aiInsights, setAiInsights] = useState(null);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);
  const [lastAiInsightUpdate, setLastAiInsightUpdate] = useState(null);

  // NEW: AI/Connectivity guards
  const isOffline = typeof navigator !== "undefined" ? !navigator.onLine : false;
  const aiEnabled = restaurant?.settings?.ai_insights_enabled !== false;
  const currency = restaurant?.settings?.currency || 'AED';

  const dateRanges = {
    this_month: { start: startOfMonth(new Date()), end: endOfMonth(new Date()) },
    last_month: { start: startOfMonth(subMonths(new Date(), 1)), end: endOfMonth(subMonths(new Date(), 1)) },
    this_quarter: { start: startOfQuarter(new Date()), end: endOfQuarter(new Date()) },
    last_quarter: { start: startOfQuarter(subQuarters(new Date(), 1)), end: endOfQuarter(subQuarters(new Date(), 1)) },
    this_year: { start: startOfYear(new Date()), end: endOfYear(new Date()) }
  };

  const selectedRange = dateRanges[period];

  const financialData = useMemo(() => {
    const periodOrders = orders.filter(o => {
      const orderDate = new Date(o.created_date);
      return orderDate >= selectedRange.start && orderDate <= selectedRange.end;
    });

    const periodPOs = purchaseOrders.filter(po => {
      const deliveryDate = new Date(po.actual_delivery || po.expected_delivery);
      return deliveryDate >= selectedRange.start && deliveryDate <= selectedRange.end;
    });

    const revenueRaw = periodOrders.reduce((sum, o) => sum + (o.total || 0), 0); // FIX: default 0
    const cogsRaw = periodPOs.reduce((sum, po) => sum + (po.total_amount || 0), 0); // FIX: default 0
    const revenue = Number.isFinite(revenueRaw) ? revenueRaw : 0;
    const cogs = Number.isFinite(cogsRaw) ? cogsRaw : 0;
    const grossProfit = revenue - cogs;
    const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
    const avgOrderValue = periodOrders.length > 0 ? revenue / periodOrders.length : 0;

    // Chart Data
    const days = eachDayOfInterval({ start: selectedRange.start, end: selectedRange.end });
    const dailyData = days.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');
      const dailyOrders = periodOrders.filter(o => format(new Date(o.created_date), 'yyyy-MM-dd') === dayStr);
      const dailyPOs = periodPOs.filter(po => format(new Date(po.actual_delivery || po.expected_delivery), 'yyyy-MM-dd') === dayStr);
      
      const dailyRevenueRaw = dailyOrders.reduce((sum, o) => sum + (o.total || 0), 0); // FIX: default 0
      const dailyCogsRaw = dailyPOs.reduce((sum, po) => sum + (po.total_amount || 0), 0); // FIX: default 0
      
      const dailyRevenue = Number.isFinite(dailyRevenueRaw) ? dailyRevenueRaw : 0;
      const dailyCogs = Number.isFinite(dailyCogsRaw) ? dailyCogsRaw : 0;

      return {
        date: format(day, 'MMM d'),
        Revenue: dailyRevenue,
        COGS: dailyCogs,
        Profit: dailyRevenue - dailyCogs
      };
    });

    return {
      revenue,
      cogs,
      grossProfit,
      grossMargin,
      avgOrderValue,
      totalOrders: periodOrders.length,
      dailyData
    };
  }, [orders, purchaseOrders, selectedRange]);

  const generateAIInsights = async () => {
    setIsGeneratingInsights(true);
    setAiInsights(null);
    try {
        // NEW: Skip LLM when AI disabled, offline, or there is no meaningful data
        const noDataYet = (financialData?.totalOrders ?? 0) === 0 && (financialData?.revenue ?? 0) === 0;
        if (!aiEnabled || isOffline || noDataYet) {
          setAiInsights({
            financial_summary: noDataYet
              ? "Not enough data for this period yet. Showing a local summary."
              : !aiEnabled
                ? "AI insights are disabled in settings. Showing a local summary."
                : "You're offline. Showing a local summary.",
            key_observation: noDataYet
              ? "Zero orders and revenue in the selected period."
              : "Connectivity/AI is unavailable; using heuristic view.",
            actionable_recommendations: [
              "Review pricing and featured items for this period.",
              "Promote a targeted offer to drive orders.",
              "Keep COGS in check with supplier comparisons."
            ],
            potential_risk: "Limited data reduces confidence in trends."
          });
          setLastAiInsightUpdate(new Date()); // Update timestamp even for local insights
          setIsGeneratingInsights(false);
          return;
        }

        const prompt = `
            Analyze the following financial data for the restaurant "${restaurant.name}" for the period: ${period.replace('_', ' ')}.
            - Total Revenue: ${currency} ${financialData.revenue.toFixed(2)}
            - Cost of Goods Sold (COGS): ${currency} ${financialData.cogs.toFixed(2)}
            - Gross Profit: ${currency} ${financialData.grossProfit.toFixed(2)}
            - Gross Margin: ${financialData.grossMargin.toFixed(1)}%
            - Total Orders: ${financialData.totalOrders}
            - Average Order Value: ${currency} ${financialData.avgOrderValue.toFixed(2)}
            
            Based on this, provide a concise, actionable financial analysis in JSON format.
            {
              "financial_summary": "A brief, one-sentence summary of the financial performance.",
              "key_observation": "The single most important observation (e.g., 'high profit margin but low order volume').",
              "actionable_recommendations": [
                "A specific, data-driven recommendation to increase revenue.",
                "A specific, data-driven recommendation to reduce costs.",
                "A strategic suggestion for improving overall profitability."
              ],
              "potential_risk": "Identify one potential financial risk to monitor."
            }
        `;
        const insights = await InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    financial_summary: { type: 'string' },
                    key_observation: { type: 'string' },
                    actionable_recommendations: { type: 'array', items: { type: 'string' } },
                    potential_risk: { type: 'string' }
                }
            }
        });
        setAiInsights(insights);
        setLastAiInsightUpdate(new Date());
    } catch (error) {
        console.error("Error generating AI financial insights:", error);
        setAiInsights({
          financial_summary: "Could not reach AI service. Showing a locally generated summary.",
          key_observation: "Connectivity issues detected.",
          actionable_recommendations: [
            "Re-run insights when back online.",
            "Track daily sales vs. COGS trendlines.",
            "Focus promotions on high-margin categories."
          ],
          potential_risk: "External service connectivity impacting insights."
        });
        setLastAiInsightUpdate(new Date());
    }
    setIsGeneratingInsights(false);
  };

  const exportFinancialPDF = () => {
    const title = `Financial Report - ${restaurant?.name || "Restaurant"} (${format(selectedRange.start, 'MMM d, yyyy')} - ${format(selectedRange.end, 'MMM d, yyyy')})`;
    const summaryRows = [
      ["Total Revenue", `${currency} ${financialData.revenue.toFixed(2)}`],
      ["COGS", `${currency} ${financialData.cogs.toFixed(2)}`],
      ["Gross Profit", `${currency} ${financialData.grossProfit.toFixed(2)}`],
      ["Gross Margin", `${financialData.grossMargin.toFixed(1)}%`],
      ["Total Orders", `${financialData.totalOrders}`],
      ["Average Order Value", `${currency} ${financialData.avgOrderValue.toFixed(2)}`]
    ];

    const dailyRowsHtml = financialData.dailyData.map(d => `
      <tr>
        <td>${d.date}</td>
        <td style="text-align:right">${currency} ${(d.Revenue ?? 0).toFixed(2)}</td>
        <td style="text-align:right">${currency} ${(d.COGS ?? 0).toFixed(2)}</td>
        <td style="text-align:right">${currency} ${(d.Profit ?? 0).toFixed(2)}</td>
      </tr>
    `).join("");

    const summaryRowsHtml = summaryRows.map(([k, v]) => `
      <tr>
        <td>${k}</td>
        <td style="text-align:right">${v}</td>
      </tr>
    `).join("");

    const html = `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>${title}</title>
          <style>
            body { font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; padding: 24px; color: #0f172a; }
            h1 { margin: 0 0 4px 0; font-size: 22px; }
            h2 { margin: 24px 0 8px 0; font-size: 16px; }
            .muted { color: #64748b; }
            table { width: 100%; border-collapse: collapse; margin-top: 8px; }
            th, td { border: 1px solid #e2e8f0; padding: 8px; font-size: 12px; }
            th { background: #f8fafc; text-align: left; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
            @media print {
              @page { margin: 16mm; }
            }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          <div class="muted">Generated on ${new Date().toLocaleString()}</div>

          <div class="grid">
            <div>
              <h2>Summary</h2>
              <table>
                <tbody>
                  ${summaryRowsHtml}
                </tbody>
              </table>
            </div>

            <div>
              <h2>Notes</h2>
              <div class="muted" style="font-size:12px; line-height:1.6;">
                This report summarizes revenue, COGS, and gross profit for the selected period.
                Use the daily breakdown to spot trends and anomalies. For detailed analytics,
                see the Financial Reporting section in the dashboard.
              </div>
            </div>
          </div>

          <h2 style="margin-top:24px;">Daily Breakdown</h2>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th style="text-align:right">Revenue</th>
                <th style="text-align:right">COGS</th>
                <th style="text-align:right">Gross Profit</th>
              </tr>
            </thead>
            <tbody>
              ${dailyRowsHtml}
            </tbody>
          </table>
          <script>
            window.onload = () => setTimeout(() => window.print(), 100);
          </script>
        </body>
      </html>
    `;

    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(html);
    w.document.close();
    w.focus();
  };

  // NEW: Export financials (daily data + summary) to CSV
  const exportFinancialCSV = () => {
    const headers = ["Date","Revenue","COGS","Gross Profit"];
    const dailyRows = financialData.dailyData.map(d => ([
      d.date,
      (d.Revenue ?? 0).toFixed(2),
      (d.COGS ?? 0).toFixed(2),
      (d.Profit ?? 0).toFixed(2)
    ]));

    const summaryRows = [
      [],
      ["Summary","Value"],
      ["Total Revenue", `${currency} ${financialData.revenue.toFixed(2)}`],
      ["COGS", `${currency} ${financialData.cogs.toFixed(2)}`],
      ["Gross Profit", `${currency} ${financialData.grossProfit.toFixed(2)}`],
      ["Gross Margin (%)", financialData.grossMargin.toFixed(1)],
      ["Total Orders", financialData.totalOrders],
      ["Average Order Value", `${currency} ${financialData.avgOrderValue.toFixed(2)}`]
    ];

    const csv = [headers, ...dailyRows, ...summaryRows]
      .map(r => r.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `financials_${restaurant?.name?.replace(/\s+/g,'_') || 'report'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <ClipboardList className="w-8 h-8 text-purple-600" />
            Financial Reporting
          </h2>
          <p className="text-slate-600 text-lg">Analyze revenue, costs, and profitability.</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px] bg-white">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this_month">This Month</SelectItem>
              <SelectItem value="last_month">Last Month</SelectItem>
              <SelectItem value="this_quarter">This Quarter</SelectItem>
              <SelectItem value="last_quarter">Last Quarter</SelectItem>
              <SelectItem value="this_year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportFinancialPDF}>
            <Download className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
          <Button variant="outline" onClick={exportFinancialCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="Total Revenue" value={`${currency} ${financialData.revenue.toFixed(2)}`} icon={DollarSign} color="#10B981" change="+5.2%" />
        <MetricCard title="Cost of Goods Sold" value={`${currency} ${financialData.cogs.toFixed(2)}`} icon={TrendingDown} color="#EF4444" change="+2.1%" />
        <MetricCard title="Gross Profit" value={`${currency} ${financialData.grossProfit.toFixed(2)}`} icon={TrendingUp} color="#3B82F6" change="+8.3%" />
        <MetricCard title="Gross Margin" value={`${financialData.grossMargin.toFixed(1)}%`} icon={ClipboardList} color="#A855F7" change="+1.5%"/>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <Card className="lg:col-span-3 shadow-xl">
          <CardHeader>
            <CardTitle>Performance Over Time</CardTitle>
            <CardDescription>{format(selectedRange.start, 'MMM d, yyyy')} - {format(selectedRange.end, 'MMM d, yyyy')}</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <ComposedChart data={financialData.dailyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="Profit" fill="#A855F7" name="Gross Profit" />
                <Line type="monotone" dataKey="Revenue" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="COGS" stroke="#EF4444" strokeWidth={2} />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 shadow-xl bg-gradient-to-br from-purple-50 via-white to-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-6 h-6 text-purple-600"/>
              AI Financial Analyst
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
             <Button
               onClick={generateAIInsights}
               disabled={isGeneratingInsights || isOffline || !aiEnabled}
               className="w-full bg-purple-600 hover:bg-purple-700 disabled:opacity-60"
             >
              {isGeneratingInsights ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                'Generate AI Insights'
              )}
            </Button>

            {/* NEW: subtle status hint */}
            {(!aiEnabled || isOffline) && (
              <p className="text-xs text-slate-600">
                {isOffline ? "You're offline. " : ""}
                {!aiEnabled ? "AI insights are disabled in Settings. " : ""}
                We'll use a local summary instead.
              </p>
            )}

            {aiInsights && (
              <div className="space-y-4 animate-in fade-in-50">
                <p className="text-xs text-muted-foreground">Last updated: {lastAiInsightUpdate ? format(lastAiInsightUpdate, 'MMM d, yyyy HH:mm') : 'N/A'}</p>
                <p className="p-4 bg-white rounded-lg border border-slate-200 text-slate-800 italic">"{aiInsights.financial_summary}"</p>
                
                <div>
                  <h4 className="font-semibold flex items-center gap-2 mb-2"><Lightbulb className="w-4 h-4 text-emerald-500"/>Recommendations</h4>
                  <ul className="list-disc list-inside space-y-2 text-sm text-slate-700">
                    {aiInsights.actionable_recommendations.map((rec, i) => <li key={i}>{rec}</li>)}
                  </ul>
                </div>
                 <div>
                  <h4 className="font-semibold flex items-center gap-2 mb-2"><AlertCircle className="w-4 h-4 text-amber-500"/>Potential Risk</h4>
                   <p className="text-sm text-slate-700">{aiInsights.potential_risk}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

       <Card className="shadow-xl">
        <CardHeader>
          <CardTitle>Profit & Loss Statement (Simplified)</CardTitle>
           <CardDescription>A summary of revenues and costs for the selected period.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[250px]">Account</TableHead>
                <TableHead>Description</TableHead>
               <TableHead className="text-right">Amount ({currency})</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow className="bg-emerald-50">
                <TableCell className="font-bold text-emerald-800">Total Revenue</TableCell>
                <TableCell className="text-emerald-700">Total sales from {financialData.totalOrders} orders</TableCell>
               <TableCell className="text-right font-bold text-emerald-800">{financialData.revenue.toFixed(2)}</TableCell>
              </TableRow>
              <TableRow className="bg-red-50">
                <TableCell className="font-semibold text-red-800">Cost of Goods Sold (COGS)</TableCell>
                <TableCell className="text-red-700">Direct costs from delivered purchase orders</TableCell>
               <TableCell className="text-right font-semibold text-red-800">({financialData.cogs.toFixed(2)})</TableCell>
              </TableRow>
              <TableRow className="bg-blue-50">
                <TableCell className="font-bold text-xl text-blue-800">Gross Profit</TableCell>
                <TableCell className="text-blue-700">Revenue minus COGS</TableCell>
               <TableCell className="text-right font-bold text-2xl text-blue-800">{financialData.grossProfit.toFixed(2)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

    </div>
  );
}
