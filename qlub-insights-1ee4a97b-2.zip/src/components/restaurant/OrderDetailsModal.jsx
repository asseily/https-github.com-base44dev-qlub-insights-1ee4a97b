import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { 
  X, 
  Clock, 
  Users, 
  DollarSign, 
  MessageSquare, 
  CheckCircle,
  Printer,
  Edit,
  CreditCard,
  RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistance } from "date-fns";

export default function OrderDetailsModal({ 
  order, 
  isOpen, 
  onClose, 
  onStatusChange, 
  getStatusColor 
}) {
  const [notes, setNotes] = useState(order.notes || '');
  const [isEditingNotes, setIsEditingNotes] = useState(false);

  if (!isOpen) return null;

  const getTimeElapsed = () => {
    return formatDistance(new Date(order.created_date), new Date(), { addSuffix: true });
  };

  const getOrderTimeline = () => {
    const statuses = ['pending', 'confirmed', 'preparing', 'ready', 'served'];
    const currentIndex = statuses.indexOf(order.status);
    
    return statuses.map((status, index) => ({
      status,
      completed: index <= currentIndex,
      current: index === currentIndex,
      label: status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')
    }));
  };

  const handleStatusChange = (newStatus) => {
    onStatusChange(order.id, newStatus);
    onClose();
  };

  const calculateItemTotal = (item) => {
    const modifierPrice = item.selected_modifiers?.reduce((sum, mod) => sum + mod.price_change, 0) || 0;
    return (item.price + modifierPrice) * item.quantity;
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        >
          {/* Header */}
          <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-2xl">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <CardTitle className="text-2xl flex items-center gap-3">
                  <span className="font-mono">Order #{order.id.slice(-8)}</span>
                  <Badge className={`${getStatusColor(order.status)} border-white`}>
                    {order.status.replace('_', ' ')}
                  </Badge>
                </CardTitle>
                <div className="flex items-center gap-6 mt-3 text-purple-100">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>Table {order.table_id}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{getTimeElapsed()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    <span>AED {order.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-white hover:bg-white/20 rounded-full"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-8 space-y-8">
            {/* Order Timeline */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Order Status</h3>
              <div className="flex items-center gap-2">
                {getOrderTimeline().map((step, index) => (
                  <React.Fragment key={step.status}>
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        step.completed 
                          ? 'bg-purple-600 text-white' 
                          : 'bg-slate-200 text-slate-400'
                      }`}>
                        {step.completed ? (
                          <CheckCircle className="w-4 h-4" />
                        ) : (
                          <span className="text-xs font-bold">{index + 1}</span>
                        )}
                      </div>
                      <span className={`text-xs mt-1 ${
                        step.completed ? 'text-purple-600 font-medium' : 'text-slate-400'
                      }`}>
                        {step.label}
                      </span>
                    </div>
                    {index < getOrderTimeline().length - 1 && (
                      <div className={`flex-1 h-0.5 ${
                        step.completed ? 'bg-purple-600' : 'bg-slate-200'
                      }`} />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Customer Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Customer Information</h3>
              <div className="bg-slate-50 rounded-lg p-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-slate-600">Customer Name</label>
                    <p className="text-slate-900">{order.customer_name || 'Guest'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-slate-600">Table Number</label>
                    <p className="text-slate-900">Table {order.table_id}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-slate-600">Order Time</label>
                    <p className="text-slate-900">
                      {new Date(order.created_date).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-slate-600">Payment Status</label>
                    <Badge variant="outline" className="mt-1">
                      {order.payment_status}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Order Items</h3>
              <div className="space-y-3">
                {order.items?.map((item, idx) => (
                  <Card key={idx} className="border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-slate-900">
                              {item.quantity}x {item.menu_item_name || 'Menu Item'}
                            </span>
                          </div>
                          
                          {/* Modifiers */}
                          {item.selected_modifiers?.length > 0 && (
                            <div className="mt-1 space-y-1">
                              {item.selected_modifiers.map((mod, modIdx) => (
                                <p key={modIdx} className="text-sm text-slate-600">
                                  • {mod.modifier_name}: {mod.option_name}
                                  {mod.price_change !== 0 && (
                                    <span className="text-emerald-600 ml-1">
                                      (+AED {mod.price_change.toFixed(2)})
                                    </span>
                                  )}
                                </p>
                              ))}
                            </div>
                          )}

                          {/* Special Instructions */}
                          {item.special_instructions && (
                            <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded">
                              <div className="flex items-start gap-2">
                                <MessageSquare className="w-3 h-3 text-amber-600 mt-0.5" />
                                <p className="text-sm text-amber-800">
                                  {item.special_instructions}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="text-right">
                          <p className="font-bold text-emerald-600">
                            AED {calculateItemTotal(item).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Order Summary</h3>
              <Card className="border border-slate-200">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Subtotal</span>
                      <span>AED {order.subtotal.toFixed(2)}</span>
                    </div>
                    
                    {order.service_charge > 0 && (
                      <div className="flex justify-between">
                        <span className="text-slate-600">Service Charge</span>
                        <span>AED {order.service_charge.toFixed(2)}</span>
                      </div>
                    )}
                    
                    {order.tax_amount > 0 && (
                      <div className="flex justify-between">
                        <span className="text-slate-600">VAT</span>
                        <span>AED {order.tax_amount.toFixed(2)}</span>
                      </div>
                    )}
                    
                    {order.tip_amount > 0 && (
                      <div className="flex justify-between">
                        <span className="text-slate-600">Tip</span>
                        <span>AED {order.tip_amount.toFixed(2)}</span>
                      </div>
                    )}
                    
                    <Separator />
                    
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total</span>
                      <span className="text-emerald-600">AED {order.total.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Notes */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-slate-900">Order Notes</h3>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setIsEditingNotes(!isEditingNotes)}
                >
                  <Edit className="w-4 h-4 mr-1" />
                  {isEditingNotes ? 'Cancel' : 'Edit'}
                </Button>
              </div>
              
              {isEditingNotes ? (
                <div className="space-y-3">
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Add notes about this order..."
                    className="h-20"
                  />
                  <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                    Save Notes
                  </Button>
                </div>
              ) : (
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-slate-700">
                    {order.notes || 'No special notes for this order'}
                  </p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 pt-6 border-t border-slate-200">
              {order.status === 'pending' && (
                <Button
                  onClick={() => handleStatusChange('confirmed')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Confirm Order
                </Button>
              )}
              
              {order.status === 'confirmed' && (
                <Button
                  onClick={() => handleStatusChange('preparing')}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Start Preparing
                </Button>
              )}
              
              {order.status === 'preparing' && (
                <Button
                  onClick={() => handleStatusChange('ready')}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark as Ready
                </Button>
              )}
              
              {order.status === 'ready' && (
                <Button
                  onClick={() => handleStatusChange('served')}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Mark as Served
                </Button>
              )}

              <Button variant="outline">
                <Printer className="w-4 h-4 mr-2" />
                Print Receipt
              </Button>

              {order.payment_status !== 'paid' && (
                <Button variant="outline">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Process Payment
                </Button>
              )}
            </div>
          </CardContent>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}