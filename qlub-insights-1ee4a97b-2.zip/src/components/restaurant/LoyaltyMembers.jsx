
import React, { useMemo, useState } from "react";
import { CustomerLoyalty } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table as UITable, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, UserPlus, Coins, Gift, Plus, Edit, Download } from "lucide-react";

export default function LoyaltyMembers({ restaurant, program, members, customers, onChanged }) {
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [initialPoints, setInitialPoints] = useState(0);

  const customersMap = useMemo(() => {
    const m = {};
    customers.forEach(c => { m[c.id] = c; });
    return m;
  }, [customers]);

  const getTier = (lifetime) => {
    if (lifetime >= 2000) return "platinum";
    if (lifetime >= 1000) return "gold";
    if (lifetime >= 500) return "silver";
    return "bronze";
  };

  const enrollCustomer = async () => {
    if (!program || !selectedCustomerId) return;
    await CustomerLoyalty.create({
      customer_id: selectedCustomerId,
      loyalty_program_id: program.id,
      points_balance: Number(initialPoints) || 0,
      lifetime_points: Number(initialPoints) || 0,
      rewards_redeemed: 0,
      tier: getTier(Number(initialPoints) || 0),
      last_activity: new Date().toISOString()
    });
    setSelectedCustomerId("");
    setInitialPoints(0);
    onChanged();
  };

  const adjustPoints = async (member, delta) => {
    const newLifetime = (member.lifetime_points || 0) + (delta > 0 ? delta : 0);
    const updated = {
      points_balance: (member.points_balance || 0) + delta,
      lifetime_points: newLifetime,
      tier: getTier(newLifetime),
      last_activity: new Date().toISOString()
    };
    await CustomerLoyalty.update(member.id, updated);
    onChanged();
  };

  const redeemReward = async (member) => {
    if (!program) return;
    const threshold = program.reward_threshold || 100;
    if ((member.points_balance || 0) < threshold) return;
    await CustomerLoyalty.update(member.id, {
      points_balance: (member.points_balance || 0) - threshold,
      rewards_redeemed: (member.rewards_redeemed || 0) + 1,
      last_activity: new Date().toISOString()
    });
    onChanged();
  };

  // NEW: Export loyalty members to CSV
  const exportMembersCSV = () => {
    const headers = ["Customer", "Email", "Points Balance", "Lifetime Points", "Tier", "Rewards Redeemed", "Last Activity"];
    const rows = members.map(m => {
      const c = customers.find(x => x.id === m.customer_id) || {};
      return [
        c.name || c.email || "",
        c.email || "",
        m.points_balance ?? 0,
        m.lifetime_points ?? 0,
        m.tier || "bronze",
        m.rewards_redeemed ?? 0,
        m.last_activity ? new Date(m.last_activity).toLocaleString() : ""
      ];
    });
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `loyalty_members_${restaurant?.name?.replace(/\s+/g, '_') || 'export'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-600" />
            Loyalty Members
          </CardTitle>
          <Button variant="outline" onClick={exportMembersCSV}>
            <Download className="w-4 h-4 mr-2" /> Export CSV
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {!program ? (
            <div className="text-slate-600">
              Configure your loyalty program first to enroll members.
            </div>
          ) : (
            <>
              {/* Enroll */}
              <div className="grid md:grid-cols-3 gap-4 items-end">
                <div className="space-y-2">
                  <Label>Customer</Label>
                  <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                    <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name || c.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Initial Points</Label>
                  <Input type="number" value={initialPoints} onChange={(e) => setInitialPoints(e.target.value)} placeholder="0" />
                </div>
                <div>
                  <Button onClick={enrollCustomer} className="bg-purple-600 hover:bg-purple-700 w-full">
                    <UserPlus className="w-4 h-4 mr-2" /> Enroll Customer
                  </Button>
                </div>
              </div>

              {/* Members Table */}
              <div className="overflow-x-auto">
                <UITable>
                  <TableHeader>
                    <TableRow className="bg-slate-50">
                      <TableHead>Customer</TableHead>
                      <TableHead>Points</TableHead>
                      <TableHead>Lifetime</TableHead>
                      <TableHead>Tier</TableHead>
                      <TableHead>Rewards</TableHead>
                      <TableHead>Last Activity</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {members.map(m => {
                      const c = customersMap[m.customer_id] || {};
                      return (
                        <TableRow key={m.id}>
                          <TableCell>
                            <div className="font-medium">{c.name || c.email}</div>
                            <div className="text-xs text-slate-500">{c.email}</div>
                          </TableCell>
                          <TableCell>{m.points_balance || 0}</TableCell>
                          <TableCell>{m.lifetime_points || 0}</TableCell>
                          <TableCell className="capitalize">{m.tier || "bronze"}</TableCell>
                          <TableCell>{m.rewards_redeemed || 0}</TableCell>
                          <TableCell>{m.last_activity ? new Date(m.last_activity).toLocaleString() : "—"}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-2">
                              <Button size="sm" variant="outline" onClick={() => adjustPoints(m, 50)}>
                                <Coins className="w-4 h-4 mr-1" /> +50
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => adjustPoints(m, 100)}>
                                <Coins className="w-4 h-4 mr-1" /> +100
                              </Button>
                              <Button size="sm" onClick={() => redeemReward(m)} className="bg-emerald-600 hover:bg-emerald-700">
                                <Gift className="w-4 h-4 mr-1" /> Redeem
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {members.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                          No members yet. Enroll your first customer above.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </UITable>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
