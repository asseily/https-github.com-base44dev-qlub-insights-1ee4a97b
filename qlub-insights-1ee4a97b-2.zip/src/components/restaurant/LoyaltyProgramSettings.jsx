import React, { useState, useEffect } from "react";
import { LoyaltyProgram } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Gift, Save, Crown } from "lucide-react";

export default function LoyaltyProgramSettings({ restaurant, program, onSaved }) {
  const [form, setForm] = useState({
    program_name: "Qlub Rewards",
    program_type: "points",
    points_per_aed: 1,
    reward_threshold: 100,
    reward_value: 10,
    welcome_bonus: 0,
    is_active: true
  });

  useEffect(() => {
    if (program) {
      setForm({
        program_name: program.program_name || "Qlub Rewards",
        program_type: program.program_type || "points",
        points_per_aed: program.points_per_aed ?? 1,
        reward_threshold: program.reward_threshold ?? 100,
        reward_value: program.reward_value ?? 10,
        welcome_bonus: program.welcome_bonus ?? 0,
        is_active: program.is_active ?? true
      });
    }
  }, [program]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleToggle = (checked) => {
    setForm(prev => ({ ...prev, is_active: checked }));
  };

  const handleSave = async () => {
    if (program) {
      await LoyaltyProgram.update(program.id, form);
    } else {
      await LoyaltyProgram.create({ restaurant_id: restaurant.id, ...form });
    }
    onSaved();
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Crown className="w-6 h-6 text-purple-600" />
          <CardTitle>Loyalty Program</CardTitle>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-sm">Active</Label>
          <Switch checked={form.is_active} onCheckedChange={handleToggle} />
        </div>
      </CardHeader>
      <CardContent className="grid md:grid-cols-3 gap-6">
        <div>
          <Label>Program Name</Label>
          <Input name="program_name" value={form.program_name} onChange={handleChange} />
        </div>
        <div>
          <Label>Program Type</Label>
          <Input name="program_type" value={form.program_type} onChange={handleChange} placeholder="points" />
        </div>
        <div>
          <Label>Points per AED</Label>
          <Input type="number" name="points_per_aed" value={form.points_per_aed} onChange={handleChange} />
        </div>
        <div>
          <Label>Reward Threshold (pts)</Label>
          <Input type="number" name="reward_threshold" value={form.reward_threshold} onChange={handleChange} />
        </div>
        <div>
          <Label>Reward Value (AED)</Label>
          <Input type="number" name="reward_value" value={form.reward_value} onChange={handleChange} />
        </div>
        <div>
          <Label>Welcome Bonus (pts)</Label>
          <Input type="number" name="welcome_bonus" value={form.welcome_bonus} onChange={handleChange} />
        </div>
        <div className="md:col-span-3 flex justify-end">
          <Button onClick={handleSave} className="bg-purple-600 hover:bg-purple-700">
            <Save className="w-4 h-4 mr-2" /> Save Program
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}