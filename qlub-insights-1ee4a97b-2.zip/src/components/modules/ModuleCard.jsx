import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Package, Users, Zap } from "lucide-react";

export default function ModuleCard({ module, onEdit }) {
  const getCategoryColor = (category) => {
    switch(category) {
      case 'core': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'addon': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'integration': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getCategoryIcon = (category) => {
    switch(category) {
      case 'core': return Package;
      case 'addon': return Users;
      case 'integration': return Zap;
      default: return Package;
    }
  };

  const IconComponent = getCategoryIcon(module.category);

  return (
    <Card className="hover:shadow-lg transition-all duration-300 border-slate-200">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-slate-100">
              <IconComponent className="w-4 h-4 text-slate-600" />
            </div>
            <div>
              <CardTitle className="text-lg">{module.name}</CardTitle>
              <Badge className={getCategoryColor(module.category)}>
                {module.category}
              </Badge>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={() => onEdit(module)}>
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-slate-600">{module.description}</p>
        
        {module.key_features?.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Key Features
            </h4>
            <div className="space-y-1">
              {module.key_features.slice(0, 3).map((feature, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-xs text-slate-600">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {module.value_propositions?.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Value Propositions
            </h4>
            <div className="space-y-1">
              {module.value_propositions.slice(0, 2).map((value, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-xs text-slate-600">{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {module.partnerships?.length > 0 && (
          <div className="pt-3 border-t border-slate-100">
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Key Partnerships
            </h4>
            <div className="flex flex-wrap gap-1">
              {module.partnerships.slice(0, 3).map((partner, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {partner}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}