import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, X, Save, XCircle } from "lucide-react";

export default function ModuleForm({ module, onSubmit, onCancel }) {
  const [formData, setFormData] = useState(module || {
    name: '',
    description: '',
    category: 'core',
    key_features: [],
    value_propositions: [],
    technical_enablers: [],
    partnerships: []
  });

  const [newFeature, setNewFeature] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newTech, setNewTech] = useState('');
  const [newPartnership, setNewPartnership] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addItem = (field, value, setter) => {
    if (value.trim()) {
      setFormData(prev => ({
        ...prev,
        [field]: [...(prev[field] || []), value.trim()]
      }));
      setter('');
    }
  };

  const removeItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl">
          {module ? 'Edit Product Module' : 'Add New Product Module'}
        </CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Module Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                placeholder="e.g. Pay-at-Table"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => setFormData(prev => ({...prev, category: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="core">Core Product</SelectItem>
                  <SelectItem value="addon">Add-on Feature</SelectItem>
                  <SelectItem value="integration">Integration</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
              placeholder="Brief description of the module..."
              className="h-20"
              required
            />
          </div>

          {/* Key Features */}
          <div className="space-y-3">
            <Label>Key Features</Label>
            <div className="flex gap-2">
              <Input
                value={newFeature}
                onChange={(e) => setNewFeature(e.target.value)}
                placeholder="Add a key feature..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('key_features', newFeature, setNewFeature))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('key_features', newFeature, setNewFeature)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.key_features?.map((feature, idx) => (
                <Badge key={idx} variant="outline" className="gap-1">
                  {feature}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('key_features', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Value Propositions */}
          <div className="space-y-3">
            <Label>Value Propositions</Label>
            <div className="flex gap-2">
              <Input
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder="Add a value proposition..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('value_propositions', newValue, setNewValue))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('value_propositions', newValue, setNewValue)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.value_propositions?.map((value, idx) => (
                <Badge key={idx} variant="outline" className="gap-1 bg-emerald-50 text-emerald-700">
                  {value}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('value_propositions', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Technical Enablers */}
          <div className="space-y-3">
            <Label>Technical Enablers</Label>
            <div className="flex gap-2">
              <Input
                value={newTech}
                onChange={(e) => setNewTech(e.target.value)}
                placeholder="Add a technical enabler..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('technical_enablers', newTech, setNewTech))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('technical_enablers', newTech, setNewTech)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.technical_enablers?.map((tech, idx) => (
                <Badge key={idx} variant="outline" className="gap-1 bg-blue-50 text-blue-700">
                  {tech}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('technical_enablers', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Partnerships */}
          <div className="space-y-3">
            <Label>Key Partnerships</Label>
            <div className="flex gap-2">
              <Input
                value={newPartnership}
                onChange={(e) => setNewPartnership(e.target.value)}
                placeholder="Add a partnership..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('partnerships', newPartnership, setNewPartnership))}
              />
              <Button 
                type="button"
                variant="outline"
                onClick={() => addItem('partnerships', newPartnership, setNewPartnership)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.partnerships?.map((partnership, idx) => (
                <Badge key={idx} variant="outline" className="gap-1 bg-purple-50 text-purple-700">
                  {partnership}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeItem('partnerships', idx)}
                  />
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <XCircle className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            {module ? 'Update' : 'Create'} Module
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}