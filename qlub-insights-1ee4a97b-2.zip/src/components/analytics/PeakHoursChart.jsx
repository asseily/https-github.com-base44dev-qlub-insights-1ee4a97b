import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';

export default function PeakHoursChart({ orders }) {
  const data = useMemo(() => {
    const hourlyOrders = Array(24).fill(0).map((_, i) => ({ hour: i, orders: 0 }));
    
    orders.forEach(order => {
      const hour = new Date(order.created_date).getHours();
      hourlyOrders[hour].orders++;
    });

    return hourlyOrders.map(item => ({
      ...item,
      hourLabel: `${item.hour}:00`
    }));
  }, [orders]);

  return (
    <Card className="shadow-lg h-full">
      <CardHeader>
        <CardTitle>Peak Business Hours</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
            <XAxis dataKey="hourLabel" stroke="#6b7280" fontSize={12} interval={3} />
            <YAxis allowDecimals={false} stroke="#6b7280" fontSize={12} />
            <Tooltip
              contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}
              labelStyle={{ fontWeight: 'bold' }}
              formatter={(value) => [value, 'Orders']}
            />
            <Line type="monotone" dataKey="orders" stroke="#ff7300" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 8 }} />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}