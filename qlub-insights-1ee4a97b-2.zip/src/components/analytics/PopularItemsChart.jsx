import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function PopularItemsChart({ orders, menuItems }) {
  const data = useMemo(() => {
    const itemCounts = {};
    orders.forEach(order => {
      order.items.forEach(item => {
        itemCounts[item.menu_item_id] = (itemCounts[item.menu_item_id] || 0) + item.quantity;
      });
    });

    const menuMap = menuItems.reduce((acc, item) => {
      acc[item.id] = item.name;
      return acc;
    }, {});

    return Object.entries(itemCounts)
      .map(([itemId, count]) => ({
        name: menuMap[itemId] || 'Unknown Item',
        value: count,
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5); // Top 5 items
  }, [orders, menuItems]);

  return (
    <Card className="shadow-lg h-full">
      <CardHeader>
        <CardTitle>Top Selling Items</CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value, name) => [value, name]} />
              <Legend iconSize={10} />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-[300px] text-slate-500">
            No order data available for this period.
          </div>
        )}
      </CardContent>
    </Card>
  );
}