import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, Utensils, Heart, Smile } from 'lucide-react';

const RatingDisplay = ({ label, value, icon: Icon }) => (
  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
    <div className="flex items-center gap-2">
      <Icon className="w-5 h-5 text-purple-600" />
      <span className="font-medium text-slate-700">{label}</span>
    </div>
    <div className="flex items-center gap-1">
      <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
      <span className="font-bold text-slate-900">{value.toFixed(1)}</span>
    </div>
  </div>
);

export default function FeedbackSummary({ feedback }) {
  const summary = useMemo(() => {
    if (feedback.length === 0) {
      return {
        overall: 0,
        food: 0,
        service: 0,
        atmosphere: 0,
      };
    }

    const total = feedback.length;
    const overall = feedback.reduce((sum, fb) => sum + fb.rating, 0) / total;
    const food = feedback.reduce((sum, fb) => sum + fb.food_rating, 0) / total;
    const service = feedback.reduce((sum, fb) => sum + fb.service_rating, 0) / total;
    const atmosphere = feedback.reduce((sum, fb) => sum + fb.atmosphere_rating, 0) / total;

    return { overall, food, service, atmosphere };
  }, [feedback]);

  return (
    <Card className="shadow-lg h-full">
      <CardHeader>
        <CardTitle>Customer Feedback Summary</CardTitle>
      </CardHeader>
      <CardContent>
        {feedback.length > 0 ? (
          <div className="space-y-3">
            <RatingDisplay label="Overall Rating" value={summary.overall} icon={Star} />
            <RatingDisplay label="Food Quality" value={summary.food} icon={Utensils} />
            <RatingDisplay label="Service" value={summary.service} icon={Heart} />
            <RatingDisplay label="Atmosphere" value={summary.atmosphere} icon={Smile} />
          </div>
        ) : (
          <div className="flex items-center justify-center h-[300px] text-slate-500">
            No feedback available for this period.
          </div>
        )}
      </CardContent>
    </Card>
  );
}