import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';

export default function RevenueChart({ orders }) {
  const processData = () => {
    const dailyRevenue = {};
    orders.forEach(order => {
      const day = format(new Date(order.created_date), 'yyyy-MM-dd');
      if (!dailyRevenue[day]) {
        dailyRevenue[day] = 0;
      }
      dailyRevenue[day] += order.total;
    });

    return Object.keys(dailyRevenue)
      .map(day => ({
        date: format(new Date(day), 'MMM d'),
        revenue: dailyRevenue[day],
      }))
      .sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  const data = processData();

  return (
    <Card className="shadow-lg h-full">
      <CardHeader>
        <CardTitle>Revenue Over Time</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
            <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
            <YAxis stroke="#6b7280" fontSize={12} tickFormatter={(value) => `AED ${value}`} />
            <Tooltip
              contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem' }}
              labelStyle={{ fontWeight: 'bold' }}
              formatter={(value) => [`AED ${value.toFixed(2)}`, 'Revenue']}
            />
            <Legend wrapperStyle={{ fontSize: '14px' }} />
            <Bar dataKey="revenue" fill="#8884d8" name="Daily Revenue" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}