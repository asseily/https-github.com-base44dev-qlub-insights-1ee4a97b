import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function AnalyticsMetricCard({ title, value, icon: Icon, color, change }) {
  const colors = {
    emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', iconBg: 'bg-emerald-100' },
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', iconBg: 'bg-blue-100' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600', iconBg: 'bg-purple-100' },
    amber: { bg: 'bg-amber-50', text: 'text-amber-600', iconBg: 'bg-amber-100' },
  };
  
  const selectedColor = colors[color] || colors.blue;
  const isPositive = change && change.startsWith('+');

  return (
    <Card className={`shadow-lg border-0 ${selectedColor.bg} hover:shadow-xl transition-shadow`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <p className={`text-sm font-medium ${selectedColor.text}`}>{title}</p>
          <div className={`p-2 rounded-lg ${selectedColor.iconBg}`}>
            <Icon className={`w-5 h-5 ${selectedColor.text}`} />
          </div>
        </div>
        <h3 className="text-3xl font-bold text-slate-900 mb-2">{value}</h3>
        {change && (
          <div className={`flex items-center text-xs ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
            <span>{change} vs last period</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}