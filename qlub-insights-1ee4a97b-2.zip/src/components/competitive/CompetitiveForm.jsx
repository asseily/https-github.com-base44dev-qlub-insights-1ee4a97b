import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CompetitiveForm({ open, onOpenChange, initialData, onSubmit }) {
  const [form, setForm] = useState({
    competitor_name: "",
    region: "UAE",
    market_position: "challenger",
    strengths: "",
    weaknesses: "",
    differentiators: ""
  });

  useEffect(() => {
    if (initialData) {
      setForm({
        competitor_name: initialData.competitor_name || "",
        region: initialData.region || "UAE",
        market_position: initialData.market_position || "challenger",
        strengths: Array.isArray(initialData.strengths) ? initialData.strengths.join(", ") : (initialData.strengths || ""),
        weaknesses: Array.isArray(initialData.weaknesses) ? initialData.weaknesses.join(", ") : (initialData.weaknesses || ""),
        differentiators: Array.isArray(initialData.differentiators) ? initialData.differentiators.join(", ") : (initialData.differentiators || "")
      });
    } else {
      setForm({
        competitor_name: "",
        region: "UAE",
        market_position: "challenger",
        strengths: "",
        weaknesses: "",
        differentiators: ""
      });
    }
  }, [initialData]);

  const parseList = (val) =>
    String(val || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

  const handleSave = () => {
    const payload = {
      competitor_name: form.competitor_name,
      region: form.region,
      market_position: form.market_position,
      strengths: parseList(form.strengths),
      weaknesses: parseList(form.weaknesses),
      differentiators: parseList(form.differentiators)
    };
    onSubmit(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{initialData ? "Edit Competitor" : "Add Competitor"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Competitor Name</Label>
            <Input
              value={form.competitor_name}
              onChange={(e) => setForm({ ...form, competitor_name: e.target.value })}
              placeholder="e.g., Talabat Pay"
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => setForm({ ...form, region: v })}>
                <SelectTrigger><SelectValue placeholder="Select region" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="UAE">UAE</SelectItem>
                  <SelectItem value="GCC">GCC</SelectItem>
                  <SelectItem value="Global">Global</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Market Position</Label>
              <Select value={form.market_position} onValueChange={(v) => setForm({ ...form, market_position: v })}>
                <SelectTrigger><SelectValue placeholder="Select position" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="leader">Leader</SelectItem>
                  <SelectItem value="challenger">Challenger</SelectItem>
                  <SelectItem value="follower">Follower</SelectItem>
                  <SelectItem value="niche">Niche</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Strengths</Label>
            <Textarea
              value={form.strengths}
              onChange={(e) => setForm({ ...form, strengths: e.target.value })}
              placeholder="Comma-separated: strong brand, large merchant base"
              rows={2}
            />
            <p className="text-xs text-slate-500">Tip: Use commas to separate items. Example: fast onboarding, low fees</p>
          </div>
          <div className="space-y-2">
            <Label>Weaknesses</Label>
            <Textarea
              value={form.weaknesses}
              onChange={(e) => setForm({ ...form, weaknesses: e.target.value })}
              placeholder="Comma-separated: limited features, slow support"
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label>Differentiators</Label>
            <Textarea
              value={form.differentiators}
              onChange={(e) => setForm({ ...form, differentiators: e.target.value })}
              placeholder="Comma-separated: table-pay UX, instant payouts"
              rows={2}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}