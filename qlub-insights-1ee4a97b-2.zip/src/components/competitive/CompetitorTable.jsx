import React from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit } from "lucide-react";

const renderBadgesWithMore = (arr = [], colorClasses = "") => {
  const items = Array.isArray(arr) ? arr : [];
  const shown = items.slice(0, 2);
  const remaining = items.length - shown.length;
  return (
    <div className="flex flex-wrap gap-1">
      {shown.map((t, i) => (
        <Badge key={i} className={colorClasses}>{t}</Badge>
      ))}
      {remaining > 0 && (
        <Badge variant="outline">+{remaining} more</Badge>
      )}
      {items.length === 0 && <span className="text-xs text-slate-400">—</span>}
    </div>
  );
};

export default function CompetitorTable({ data, onQuickView, onEdit }) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead>Name</TableHead>
            <TableHead>Region</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Strengths</TableHead>
            <TableHead>Weaknesses</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((c) => (
            <TableRow key={c.id} className="hover:bg-slate-50">
              <TableCell className="font-medium">{c.competitor_name}</TableCell>
              <TableCell><Badge variant="outline">{c.region}</Badge></TableCell>
              <TableCell><Badge className="bg-indigo-100 text-indigo-800 capitalize">{c.market_position}</Badge></TableCell>
              <TableCell>{renderBadgesWithMore(c.strengths, "bg-emerald-50 text-emerald-800")}</TableCell>
              <TableCell>{renderBadgesWithMore(c.weaknesses, "bg-amber-50 text-amber-800")}</TableCell>
              <TableCell className="text-right">
                <div className="flex gap-2 justify-end">
                  <Button variant="ghost" size="icon" onClick={() => onQuickView(c)} aria-label="Quick view">
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => onEdit(c)} aria-label="Edit">
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {data.length === 0 && (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-10 text-slate-500">No competitors yet.</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}