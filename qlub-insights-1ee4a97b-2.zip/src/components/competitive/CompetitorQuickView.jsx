import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Lightbulb, AlertCircle, Sparkles } from "lucide-react";

export default function CompetitorQuickView({ open, onOpenChange, competitor, onEdit }) {
  if (!competitor) return null;

  const list = (arr) => Array.isArray(arr) ? arr : [];
  const section = (title, icon, colorClasses, items) => (
    <div className="space-y-2">
      <div className="flex items-center gap-2 font-semibold text-slate-800">
        {icon}
        <span>{title}</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {items.length === 0 ? (
          <span className="text-xs text-slate-400">No items</span>
        ) : items.map((t, i) => (
          <Badge key={i} className={colorClasses}>{t}</Badge>
        ))}
      </div>
    </div>
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="text-slate-900">{competitor.competitor_name}</SheetTitle>
          <div className="text-sm text-slate-500">
            Region: <Badge variant="outline" className="ml-1">{competitor.region}</Badge>
            <span className="mx-2">•</span>
            Position: <Badge className="ml-1 bg-indigo-100 text-indigo-800 capitalize">{competitor.market_position}</Badge>
          </div>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {section("Strengths", <Sparkles className="w-4 h-4 text-emerald-600" />, "bg-emerald-50 text-emerald-800", list(competitor.strengths))}
          {section("Weaknesses", <AlertCircle className="w-4 h-4 text-amber-600" />, "bg-amber-50 text-amber-800", list(competitor.weaknesses))}
          {section("Differentiators", <Lightbulb className="w-4 h-4 text-purple-600" />, "bg-purple-50 text-purple-800", list(competitor.differentiators))}
        </div>

        <div className="mt-8">
          <Button onClick={() => onEdit(competitor)} className="w-full">Edit</Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}