
import React, { useEffect, useState, useMemo } from "react";
import { PaymentLink, Order, Restaurant, Table, Payment } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Loader2, CheckCircle2, AlertTriangle, RotateCw } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function PaymentReturn() {
  const url = new URLSearchParams(window.location.search);
  const paymentLinkId = url.get("payment_link_id");
  const provider = url.get("provider") || "stripe";
  const result = url.get("result"); // success | cancel | undefined (treat as success attempt)
  const sessionId = url.get("session_id") || url.get("session") || url.get("checkout_session_id") || null;
  const intentId = url.get("payment_intent") || null;

  const [isVerifying, setIsVerifying] = useState(true);
  const [verifyError, setVerifyError] = useState("");
  const [link, setLink] = useState(null);
  const [order, setOrder] = useState(null);
  const [restaurant, setRestaurant] = useState(null);

  useEffect(() => {
    const run = async () => {
      if (!paymentLinkId) {
        setVerifyError("Missing payment link.");
        setIsVerifying(false);
        return;
      }

      // Load link and context first
      const links = await PaymentLink.filter({ id: paymentLinkId });
      const l = links?.[0] || null;
      setLink(l || null);

      if (!l) {
        setVerifyError("Payment link not found.");
        setIsVerifying(false);
        return;
      }

      // Load related entities locally and then set state
      let r = null;
      if (l.restaurant_id) {
        const rs = await Restaurant.filter({ id: l.restaurant_id });
        r = rs?.[0] || null;
        setRestaurant(r || null);
      }
      let o = null;
      if (l.order_id) {
        const os = await Order.filter({ id: l.order_id });
        o = os?.[0] || null;
        setOrder(o || null);
      }

      // If user cancelled at the gateway, show cancel state (no verification)
      if (result === "cancel") {
        setIsVerifying(false);
        return;
      }

      // Ask backend to verify the session/intent (idempotent). Backend should also be handling webhooks.
      const res = await fetch("/api/payments/confirm-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider,
          link_id: paymentLinkId,
          session_id: sessionId,
          payment_intent_id: intentId
        })
      });
      const data = await res.json().catch(() => ({}));

      // Refresh the link to get the latest status possibly updated by webhook.
      const refreshed = await PaymentLink.filter({ id: paymentLinkId });
      const newLink = refreshed?.[0] || null;
      setLink(newLink || l);

      // Fallback (if webhook hasn't updated yet): mark local state by response.
      const isPaid = (newLink?.status === "paid") || (data?.status === "confirmed") || (data?.success === true);
      if (!isPaid) {
        setVerifyError("Payment not confirmed yet.");
        setIsVerifying(false);
        return;
      }

      // Fallback entity updates if backend hasn't done it yet (idempotent best-effort)
      if (newLink && newLink.status !== "paid") {
        await PaymentLink.update(newLink.id, { ...newLink, status: "paid", usage_count: (newLink.usage_count || 0) + 1 });
      }
      if (o?.id) { // Use local 'o'
        if (o.payment_status !== "paid" || o.status !== "paid") {
          await Order.update(o.id, { ...o, payment_status: "paid", status: "paid" });
        }
      }
      if (o?.table_id) { // Use local 'o'
        const tables = await Table.filter({ id: o.table_id });
        const t = tables?.[0];
        if (t && t.status !== "available") {
          await Table.update(t.id, { ...t, status: "available" });
        }
      }

      // POS sync hook: notify backend on paid status if enabled
      if (r?.settings?.pos_sync_mode === "backend" && o?.id && r?.id) { // Use local 'r' and 'o'
        await fetch("/api/pos/sync-order-status", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            restaurant_id: r.id,
            order_id: o.id,
            status: "paid",
            table_id: o.table_id || null,
            totals: {
              subtotal: o.subtotal ?? 0,
              tax: o.tax_amount ?? 0,
              service_charge: o.service_charge ?? 0,
              tip: o.tip_amount ?? 0,
              total: o.total ?? 0
            },
            items: Array.isArray(o.items) ? o.items : []
          })
        });
      }

      setIsVerifying(false);

      // Redirect to Feedback after a short moment
      const fbUrl = createPageUrl(
        `Feedback?restaurant_id=${encodeURIComponent(newLink?.restaurant_id || l.restaurant_id)}${(o?.id) ? `&order_id=${encodeURIComponent(o.id)}` : ""}`
      );
      setTimeout(() => {
        window.location.href = fbUrl;
      }, 800);
    };

    run();
  }, [paymentLinkId, provider, result, sessionId, intentId]);

  const retryUrl = useMemo(() => {
    return createPageUrl(`PaymentPortal?payment_link_id=${encodeURIComponent(paymentLinkId || "")}`);
  }, [paymentLinkId]);

  if (!paymentLinkId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="max-w-md w-full bg-rose-50 border border-rose-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-rose-700">
              <AlertTriangle className="w-5 h-5" /> Invalid return
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700">Missing payment link ID.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (result === "cancel") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <Card className="max-w-md w-full text-center bg-amber-50 border border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-amber-700">
              <AlertTriangle className="w-5 h-5" /> Payment canceled
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-slate-700">Your payment was not completed.</p>
            <Separator />
            <div className="flex gap-3 justify-center">
              <Button asChild variant="outline">
                <a href={retryUrl}>Try again</a>
              </Button>
              <Button asChild>
                <a href={createPageUrl("RestaurantDashboard")}>Go to Dashboard</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isVerifying) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          <p className="text-slate-600">Verifying your payment...</p>
        </div>
      </div>
    );
  }

  if (verifyError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <Card className="max-w-md w-full text-center bg-amber-50 border border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2 text-amber-700">
              <AlertTriangle className="w-5 h-5" /> Payment not confirmed
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-slate-700">{verifyError}</p>
            <Separator />
            <div className="flex gap-3 justify-center">
              <Button asChild variant="outline">
                <a href={retryUrl}>Retry</a>
              </Button>
              <Button asChild>
                <a href={createPageUrl("RestaurantDashboard")}>Go to Dashboard</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Success: brief confirmation before redirect
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <Card className="max-w-md w-full text-center">
        <CardHeader>
          <CardTitle className="flex items-center justify-center gap-2 text-emerald-700">
            <CheckCircle2 className="w-6 h-6" /> Payment confirmed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600">You're all set. Redirecting to feedback...</p>
        </CardContent>
      </Card>
    </div>
  );
}
