
import React, { useState, useEffect, useCallback } from "react";
import { ProductModule, PricingStructure, CompetitiveAnalysis, IntegrationRequirement, CustomerFeedback } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Package, 
  DollarSign, 
  Users, 
  Zap, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle,
  Download,
  FileText,
  Loader2
} from "lucide-react";
import { InvokeLLM } from "@/api/integrations";

import MetricCard from "../components/dashboard/MetricCard";
import ProductOverview from "../components/dashboard/ProductOverview"; 
import PricingOverview from "../components/dashboard/PricingOverview";
import CompetitiveSnapshot from "../components/dashboard/CompetitiveSnapshot";
import ExecutiveSummaryModal from "../components/dashboard/ExecutiveSummaryModal";
import FeedbackInsights from "../components/dashboard/FeedbackInsights";

export default function Dashboard() {
  const [modules, setModules] = useState([]);
  const [pricing, setPricing] = useState([]);
  const [competitors, setCompetitors] = useState([]);
  const [integrations, setIntegrations] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [executiveSummary, setExecutiveSummary] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [modulesData, pricingData, competitorsData, integrationsData, feedbackData] = await Promise.all([
        ProductModule.list('-created_date', 10),
        PricingStructure.list('-created_date', 10),
        CompetitiveAnalysis.list('-created_date', 10),
        IntegrationRequirement.list('-created_date', 10),
        CustomerFeedback.list('-created_date', 50)
      ]);
      
      setModules(modulesData);
      setPricing(pricingData);
      setCompetitors(competitorsData);
      setIntegrations(integrationsData);
      setFeedback(feedbackData);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    }
    setIsLoading(false);
  };

  // Memoized handlers to satisfy exhaustive-deps and keep stable references
  const handleExportReport = useCallback(async () => {
    setIsExporting(true);
    try {
      // Compile data for report generation
      const reportData = {
        modules: modules.map(m => ({
          name: m.name,
          category: m.category,
          description: m.description,
          key_features: m.key_features,
          value_propositions: m.value_propositions
        })),
        pricing: pricing.map(p => ({
          fee_type: p.fee_type,
          status: p.status,
          explicit_rate: p.explicit_rate,
          placeholder_rate: p.placeholder_rate,
          uae_benchmark_min: p.uae_benchmark_min,
          uae_benchmark_max: p.uae_benchmark_max
        })),
        competitors: competitors.map(c => ({
          name: c.competitor_name,
          region: c.region,
          position: c.market_position,
          strengths: c.strengths,
          weaknesses: c.weaknesses
        })),
        integrations: integrations.map(i => ({
          name: i.integration_name,
          priority: i.priority,
          status: i.status,
          business_impact: i.business_impact
        }))
      };

      const response = await InvokeLLM({
        prompt: `Generate a comprehensive business analysis report for Qlub.io based on this data. 
        
        Data: ${JSON.stringify(reportData)}
        
        Create a detailed report with:
        1. Executive Summary
        2. Product Module Analysis
        3. Pricing Strategy Assessment
        4. Competitive Landscape Analysis
        5. Integration Roadmap
        6. Key Recommendations
        
        Format as a professional business report with clear sections and actionable insights.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            executive_summary: { type: "string" },
            product_analysis: { type: "string" },
            pricing_analysis: { type: "string" },
            competitive_analysis: { type: "string" },
            integration_roadmap: { type: "string" },
            recommendations: { type: "array", items: { type: "string" } },
            conclusion: { type: "string" }
          }
        }
      });

      const reportText = `
# ${response.title || 'Qlub.io Product Brief Analysis Report'}

## Executive Summary
${response.executive_summary}

## Product Module Analysis
${response.product_analysis}

## Pricing Strategy Assessment  
${response.pricing_analysis}

## Competitive Landscape Analysis
${response.competitive_analysis}

## Integration Roadmap
${response.integration_roadmap}

## Key Recommendations
${response.recommendations?.map(rec => `• ${rec}`).join('\n') || 'No specific recommendations available'}

## Conclusion
${response.conclusion}

---
Generated on: ${new Date().toLocaleDateString()}
Data Points: ${modules.length} modules, ${pricing.length} pricing points, ${competitors.length} competitors, ${integrations.length} integrations
      `.trim();

      const blob = new Blob([reportText], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Qlub_Product_Brief_Report_${new Date().toISOString().split('T')[0]}.md`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

    } catch (error) {
      console.error("Error generating report:", error);
      alert("Error generating report. Please try again.");
    }
    setIsExporting(false);
  }, [modules, pricing, competitors, integrations]);

  const handleExecutiveSummary = useCallback(async () => {
    setIsGeneratingSummary(true);
    try {
      const summaryData = {
        total_modules: modules.length,
        core_modules: modules.filter(m => m.category === 'core').length,
        pricing_transparency: pricing.filter(p => p.status === 'missing').length,
        key_competitors: competitors.length,
        critical_integrations: integrations.filter(i => i.priority === 'critical').length
      };

      const response = await InvokeLLM({
        prompt: `Generate an executive summary for Qlub.io product brief analysis based on this data:

        Metrics: ${JSON.stringify(summaryData)}
        
        Key Product Modules: ${modules.slice(0, 3).map(m => m.name).join(', ')}
        Main Competitors: ${competitors.slice(0, 3).map(c => c.competitor_name).join(', ')}
        
        Create a concise executive summary covering:
        1. Business overview and value proposition
        2. Key strengths and opportunities  
        3. Critical challenges and recommendations
        4. Market positioning assessment
        
        Keep it executive-level, strategic, and actionable.`,
        response_json_schema: {
          type: "object",
          properties: {
            overview: { type: "string" },
            key_strengths: { type: "array", items: { type: "string" } },
            opportunities: { type: "array", items: { type: "string" } },
            challenges: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } },
            market_position: { type: "string" },
            priority_actions: { type: "array", items: { type: "string" } }
          }
        }
      });

      setExecutiveSummary(response);
      setShowSummaryModal(true);
    } catch (error) {
      console.error("Error generating executive summary:", error);
      alert("Error generating executive summary. Please try again.");
    }
    setIsGeneratingSummary(false);
  }, [modules, pricing, competitors, integrations]);

  // Auto actions via URL params: ?export=report or ?summary=1
  useEffect(() => {
    if (isLoading) return; // wait for data to load
    const params = new URLSearchParams(window.location.search);
    const exportAction = params.get("export");
    const summaryAction = params.get("summary");
    if (exportAction === "report" && !isExporting) {
      handleExportReport();
    }
    if ((summaryAction === "1" || summaryAction === "true") && !isGeneratingSummary) {
      handleExecutiveSummary();
    }
  }, [isLoading, isExporting, isGeneratingSummary, handleExportReport, handleExecutiveSummary]);

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              Qlub.io Product Brief
            </h1>
            <p className="text-slate-600 text-lg">
              UAE Restaurant Fintech & Guest Experience Platform
            </p>
            <div className="flex items-center gap-4 mt-4">
              <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                <CheckCircle className="w-3 h-3 mr-1" />
                Analysis Complete
              </Badge>
              <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                <AlertTriangle className="w-3 h-3 mr-1" />
                Pricing Data Missing
              </Badge>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={handleExportReport}
              disabled={isExporting}
            >
              {isExporting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              {isExporting ? 'Generating...' : 'Export Report'}
            </Button>
            <Button 
              className="bg-amber-600 hover:bg-amber-700 flex items-center gap-2"
              onClick={handleExecutiveSummary}
              disabled={isGeneratingSummary}
            >
              {isGeneratingSummary ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              {isGeneratingSummary ? 'Generating...' : 'Executive Summary'}
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard 
            title="Product Modules"
            value={modules.length}
            icon={Package}
            bgColor="bg-blue-500"
            description="Core offerings analyzed"
          />
          <MetricCard 
            title="Pricing Points"
            value={pricing.length}
            icon={DollarSign}
            bgColor="bg-emerald-500" 
            description="Fee structures mapped"
          />
          <MetricCard 
            title="Competitors"
            value={competitors.length}
            icon={Users}
            bgColor="bg-purple-500"
            description="Market players analyzed"
          />
          <MetricCard 
            title="Integrations"
            value={integrations.filter(i => i.priority === 'critical').length}
            icon={Zap}
            bgColor="bg-amber-500"
            description="Critical integrations"
          />
        </div>

        {/* Core Value Propositions */}
        <Card className="bg-gradient-to-r from-blue-900 to-amber-600 text-white">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <TrendingUp className="w-6 h-6" />
              Core Value Propositions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">10s</div>
                <div className="text-blue-100">Faster checkout time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">+6%</div>
                <div className="text-blue-100">Average basket increase</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">100%</div>
                <div className="text-blue-100">Automatic POS closure</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Sections */}
        <div className="grid lg:grid-cols-2 gap-8">
          <ProductOverview modules={modules} isLoading={isLoading} />
          <PricingOverview pricing={pricing} isLoading={isLoading} />
        </div>

        <FeedbackInsights feedback={feedback} isLoading={isLoading} />

        <CompetitiveSnapshot competitors={competitors} isLoading={isLoading} />
      </div>

      {/* Executive Summary Modal */}
      {showSummaryModal && executiveSummary && (
        <ExecutiveSummaryModal
          isOpen={showSummaryModal}
          onClose={() => setShowSummaryModal(false)}
          summary={executiveSummary}
        />
      )}
    </div>
  );
}
