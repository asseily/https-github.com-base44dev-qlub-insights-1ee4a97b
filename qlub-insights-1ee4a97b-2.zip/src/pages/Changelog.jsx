
import React, { useEffect, useMemo, useState, useCallback } from "react";
import { ProductModule, PricingStructure, CompetitiveAnalysis, IntegrationRequirement, CustomerFeedback, EmailCampaign, Order } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { History, RefreshCw, Package, DollarSign, Users, Zap, MessageSquare, Mail, Receipt, Download } from "lucide-react";

export default function Changelog() {
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [
      modules,
      pricing,
      competitors,
      integrations,
      feedback,
      campaigns,
      orders
    ] = await Promise.all([
      ProductModule.list("-created_date", 50),
      PricingStructure.list("-created_date", 50),
      CompetitiveAnalysis.list("-created_date", 50),
      IntegrationRequirement.list("-created_date", 50),
      CustomerFeedback.list("-created_date", 50),
      EmailCampaign.list("-created_date", 50),
      Order.list("-created_date", 50)
    ]);

    const mapItem = (type, data, map) => (data || []).map(map).map(i => ({ ...i, type }));

    const timeline = [
      ...mapItem("Product Module", modules, m => ({
        id: m.id,
        title: m.name,
        subtitle: m.category,
        meta: "Module created",
        date: m.created_date
      })),
      ...mapItem("Pricing", pricing, p => ({
        id: p.id,
        title: p.fee_type,
        subtitle: p.explicit_rate || p.placeholder_rate || "Not disclosed",
        meta: `${p.currency} • ${p.frequency} • ${p.status}`,
        date: p.created_date
      })),
      ...mapItem("Competitor", competitors, c => ({
        id: c.id,
        title: c.competitor_name,
        subtitle: `${c.region} • ${c.market_position}`,
        meta: "Competitive Analysis",
        date: c.created_date
      })),
      ...mapItem("Integration", integrations, i => ({
        id: i.id,
        title: i.integration_name,
        subtitle: `${i.priority} • ${i.status}`,
        meta: "Integration",
        date: i.created_date
      })),
      ...mapItem("Feedback", feedback, f => ({
        id: f.id,
        title: f.customer_name || "Guest",
        subtitle: `Rating ${f.rating}/5${f.comment ? ` • ${String(f.comment).slice(0, 60)}${String(f.comment).length > 60 ? "..." : ""}` : ""}`,
        meta: "Customer Feedback",
        date: f.created_date
      })),
      ...mapItem("Campaign", campaigns, e => ({
        id: e.id,
        title: e.campaign_name,
        subtitle: `${e.status} • ${e.target_audience}`,
        meta: "Email Campaign",
        date: e.created_date
      })),
      ...mapItem("Order", orders, o => ({
        id: o.id,
        title: `Order #${String(o.id).slice(-6)}`,
        subtitle: `${o.customer_name || "Guest"} • ${o.status}`,
        meta: "Order",
        date: o.created_date
      }))
    ]
      .filter(i => !!i.date)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    setItems(timeline);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    if (filter === "all") return items;
    return items.filter(i => i.type === filter);
  }, [items, filter]);

  const exportChangelogCSV = () => {
    const headers = ["Type", "Title", "Subtitle", "Meta", "Date"];
    const rows = (filtered || []).map(it => ([
      it.type || "",
      it.title || "",
      it.subtitle || "",
      it.meta || "",
      it.date ? new Date(it.date).toISOString() : ""
    ]));
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    // Prepend UTF-8 BOM to improve Excel compatibility
    const csvWithBom = '\uFEFF' + csv;
    const blob = new Blob([csvWithBom], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `changelog_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const typeIcon = (type) => {
    switch (type) {
      case "Product Module": return <Package className="w-4 h-4 text-blue-600" />;
      case "Pricing": return <DollarSign className="w-4 h-4 text-emerald-600" />;
      case "Competitor": return <Users className="w-4 h-4 text-purple-600" />;
      case "Integration": return <Zap className="w-4 h-4 text-amber-600" />;
      case "Feedback": return <MessageSquare className="w-4 h-4 text-rose-600" />;
      case "Campaign": return <Mail className="w-4 h-4 text-sky-600" />;
      case "Order": return <Receipt className="w-4 h-4 text-slate-600" />;
      default: return <History className="w-4 h-4 text-slate-500" />;
    }
  };

  const typeBadgeClass = (type) => {
    switch (type) {
      case "Product Module": return "bg-blue-50 text-blue-700 border-blue-200";
      case "Pricing": return "bg-emerald-50 text-emerald-700 border-emerald-200";
      case "Competitor": return "bg-purple-50 text-purple-700 border-purple-200";
      case "Integration": return "bg-amber-50 text-amber-700 border-amber-200";
      case "Feedback": return "bg-rose-50 text-rose-700 border-rose-200";
      case "Campaign": return "bg-sky-50 text-sky-700 border-sky-200";
      case "Order": return "bg-slate-100 text-slate-700 border-slate-200";
      default: return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
              <History className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Changelog</h1>
              <p className="text-slate-600">Recent activity across modules, pricing, competitors, integrations, campaigns, and orders.</p>
            </div>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Filter type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="Product Module">Product Module</SelectItem>
                <SelectItem value="Pricing">Pricing</SelectItem>
                <SelectItem value="Competitor">Competitor</SelectItem>
                <SelectItem value="Integration">Integration</SelectItem>
                <SelectItem value="Feedback">Feedback</SelectItem>
                <SelectItem value="Campaign">Campaign</SelectItem>
                <SelectItem value="Order">Order</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setFilter("all")}
              disabled={loading || filter === "all"}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Reset
            </Button>
            <Button
              variant="outline"
              onClick={exportChangelogCSV}
              disabled={loading || (filtered || []).length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
            <Button variant="outline" onClick={load} disabled={loading} className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl">Latest Updates</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {Array(8).fill(0).map((_, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-4 w-2/3" />
                    </div>
                    <Skeleton className="h-4 w-28" />
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                No updates found.
              </div>
            ) : (
              <div className="space-y-4">
                {filtered.map((it) => (
                  <div key={`${it.type}_${it.id}`} className="flex items-start gap-4 p-3 rounded-lg hover:bg-slate-50">
                    <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center">
                      {typeIcon(it.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-semibold text-slate-900 truncate">{it.title}</h3>
                        <Badge className={typeBadgeClass(it.type)} variant="outline">{it.type}</Badge>
                      </div>
                      {it.subtitle && (
                        <p className="text-sm text-slate-600 mt-1">{it.subtitle}</p>
                      )}
                      {it.meta && (
                        <p className="text-xs text-slate-500 mt-1">{it.meta}</p>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 whitespace-nowrap">
                      {it.date ? new Date(it.date).toLocaleString() : ""}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
