
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Restaurant, MenuItem, Order, Table } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  ShoppingCart,
  ChevronDown,
  X,
  Plus,
  Minus,
  Loader2,
  Utensils,
  Search
} from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";

import MenuItemCard from "../components/customer/MenuItemCard";
import CategoryTabs from "../components/customer/CategoryTabs";
import ItemCustomizationModal from "../components/customer/ItemCustomizationModal";
import CartSidebar from "../components/customer/CartSidebar";

export default function CustomerMenu() {
  const [searchParams] = useSearchParams();
  const restaurantId = searchParams.get('restaurant_id');
  const tableNumberParam = searchParams.get('table') || searchParams.get('table_number');

  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [table, setTable] = useState(null);

  const loadMenuData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [restaurantData, menuData] = await Promise.all([
        Restaurant.filter({ id: restaurantId }),
        MenuItem.filter({ restaurant_id: restaurantId, available: true }, '-featured')
      ]);

      if (restaurantData.length > 0) {
        setRestaurant(restaurantData[0]);
      }
      setMenuItems(menuData);

      // NEW: resolve table by number if provided
      if (restaurantData.length > 0 && tableNumberParam) {
        const tables = await Table.filter({ restaurant_id: restaurantData[0].id, table_number: tableNumberParam });
        setTable(tables[0] || null);
      }
    } catch (error) {
      console.error("Error loading menu data:", error);
    }
    setIsLoading(false);
  }, [restaurantId, tableNumberParam]);

  useEffect(() => {
    if (restaurantId) {
      loadMenuData();
    }
  }, [restaurantId, loadMenuData]);

  const addToCart = (item, quantity, selectedModifiers, specialInstructions) => {
    const cartItem = {
      ...item,
      cartItemId: Date.now(),
      quantity,
      selectedModifiers,
      specialInstructions
    };
    setCart(prevCart => [...prevCart, cartItem]);
    setSelectedItem(null);
  };

  const updateCartItemQuantity = (cartItemId, newQuantity) => {
    if (newQuantity <= 0) {
      setCart(prevCart => prevCart.filter(item => item.cartItemId !== cartItemId));
    } else {
      setCart(prevCart => prevCart.map(item =>
        item.cartItemId === cartItemId ? { ...item, quantity: newQuantity } : item
      ));
    }
  };
  
  const brandColor = restaurant?.settings?.brand_color || '#6D28D9';
  const brandStyle = { '--brand-color': brandColor };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-purple-600" style={{color: brandColor}} />
          <p className="text-lg text-slate-700">Loading menu...</p>
        </div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="text-center p-8">
          <Utensils className="w-12 h-12 mx-auto mb-4 text-slate-400" />
          <h2 className="text-xl font-semibold mb-2">Restaurant not found</h2>
          <p className="text-slate-600">The menu you are looking for is not available.</p>
        </Card>
      </div>
    );
  }

  const categories = ['all', 'featured', ...new Set(menuItems.map(item => item.category))];
  const filteredItems = menuItems.filter(item => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'featured') return item.featured;
    return item.category === activeCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 font-sans" style={brandStyle}>
      {/* Header */}
      <header className="sticky top-0 bg-white shadow-md z-30">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
             {restaurant.settings?.logo_url ? (
              <img src={restaurant.settings.logo_url} alt={`${restaurant.name} Logo`} className="h-12 w-auto object-contain"/>
            ) : (
              <div className="w-12 h-12 bg-slate-200 rounded-lg flex items-center justify-center font-bold text-xl text-slate-600">{restaurant.name[0]}</div>
            )}
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{restaurant.name}</h1>
              <p className="text-sm text-slate-600">{restaurant.cuisine_type}</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={() => setIsCartOpen(true)}
            className="relative"
          >
            <ShoppingCart className="w-5 h-5" />
            {cart.length > 0 && (
              <Badge className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0 flex items-center justify-center bg-[var(--brand-color)] text-white">
                {cart.reduce((sum, item) => sum + item.quantity, 0)}
              </Badge>
            )}
          </Button>
        </div>
        <CategoryTabs
          categories={categories}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          brandColor={brandColor}
        />
      </header>

      {/* Menu Body */}
      <main className="max-w-5xl mx-auto p-4 space-y-8">
        <AnimatePresence>
          <motion.div
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredItems.map(item => (
              <MenuItemCard key={item.id} item={item} onSelect={() => setSelectedItem(item)} />
            ))}
          </motion.div>
        </AnimatePresence>
        
        {filteredItems.length === 0 && (
          <div className="text-center py-16">
            <Search className="w-12 h-12 mx-auto text-slate-400 mb-4" />
            <p className="text-slate-600">No items in this category.</p>
          </div>
        )}
      </main>

      <AnimatePresence>
        {selectedItem && (
          <ItemCustomizationModal
            item={selectedItem}
            onClose={() => setSelectedItem(null)}
            onAddToCart={addToCart}
            brandColor={brandColor}
          />
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {isCartOpen && (
          <CartSidebar
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cart={cart}
            restaurant={restaurant}
            table={table}
            updateCartItemQuantity={updateCartItemQuantity}
            setCart={setCart}
            brandColor={brandColor}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
