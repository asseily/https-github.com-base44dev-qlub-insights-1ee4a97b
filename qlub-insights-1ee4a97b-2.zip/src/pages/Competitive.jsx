
import React, { useEffect, useMemo, useState, useCallback } from "react";
import { CompetitiveAnalysis } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, Download, RefreshCw } from "lucide-react";

import CompetitiveForm from "@/components/competitive/CompetitiveForm";
import CompetitorQuickView from "@/components/competitive/CompetitorQuickView";
import CompetitorTable from "@/components/competitive/CompetitorTable";

export default function Competitive() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [region, setRegion] = useState("all");
  const [position, setPosition] = useState("all");

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const [quickViewOpen, setQuickViewOpen] = useState(false);
  const [quickViewItem, setQuickViewItem] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await CompetitiveAnalysis.list("-updated_date", 500);
    setRows(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      const matchQ = q.trim().length === 0 || (r.competitor_name || "").toLowerCase().includes(q.toLowerCase());
      const matchRegion = region === "all" || r.region === region;
      const matchPos = position === "all" || r.market_position === position;
      return matchQ && matchRegion && matchPos;
    });
  }, [rows, q, region, position]);

  const resetFilters = () => {
    setQ("");
    setRegion("all");
    setPosition("all");
  };

  const handleAdd = () => {
    setEditing(null);
    setShowForm(true);
  };
  const handleEdit = (item) => {
    setEditing(item);
    setShowForm(true);
  };
  const handleQuickView = (item) => {
    setQuickViewItem(item);
    setQuickViewOpen(true);
  };

  const saveForm = async (payload) => {
    if (editing) {
      await CompetitiveAnalysis.update(editing.id, payload);
    } else {
      await CompetitiveAnalysis.create(payload);
    }
    setShowForm(false);
    setEditing(null);
    load();
  };

  const exportCompetitorsCSV = () => {
    const headers = [
      "Competitor",
      "Region",
      "Position",
      "Strengths",
      "Weaknesses",
      "Differentiators"
    ];
    const rowsOut = (filtered || []).map(c => ([
      c.competitor_name || "",
      c.region || "",
      c.market_position || "",
      Array.isArray(c.strengths) ? c.strengths.join(" | ") : "",
      Array.isArray(c.weaknesses) ? c.weaknesses.join(" | ") : "",
      Array.isArray(c.differentiators) ? c.differentiators.join(" | ") : ""
    ]));
    const csv = [headers, ...rowsOut]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `competitive_export_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Competitive Analysis</h1>
            <p className="text-slate-600">Keep a clean overview of key competitors.</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={exportCompetitorsCSV}
              disabled={loading || (filtered || []).length === 0}
            >
              <Download className="w-4 h-4 mr-2" /> Export CSV
            </Button>
            <Button onClick={handleAdd} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" /> Add Competitor
            </Button>
          </div>
        </div>

        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search competitors..." className="pl-10" />
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-slate-500 text-sm">
                  <Filter className="w-4 h-4" /> Filters
                </div>
                <Select value={region} onValueChange={setRegion}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Region" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Regions</SelectItem>
                    <SelectItem value="UAE">UAE</SelectItem>
                    <SelectItem value="GCC">GCC</SelectItem>
                    <SelectItem value="Global">Global</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={position} onValueChange={setPosition}>
                  <SelectTrigger className="w-44">
                    <SelectValue placeholder="Position" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Positions</SelectItem>
                    <SelectItem value="leader">Leader</SelectItem>
                    <SelectItem value="challenger">Challenger</SelectItem>
                    <SelectItem value="follower">Follower</SelectItem>
                    <SelectItem value="niche">Niche</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={resetFilters}
                  disabled={loading || (q === "" && region === "all" && position === "all")}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Reset
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-slate-900">Competitors ({filtered.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="py-12 text-center text-slate-500">Loading...</div>
            ) : (
              <CompetitorTable
                data={filtered}
                onQuickView={handleQuickView}
                onEdit={handleEdit}
              />
            )}
          </CardContent>
        </Card>
      </div>

      <CompetitiveForm
        open={showForm}
        onOpenChange={setShowForm}
        initialData={editing}
        onSubmit={saveForm}
      />

      <CompetitorQuickView
        open={quickViewOpen}
        onOpenChange={setQuickViewOpen}
        competitor={quickViewItem}
        onEdit={handleEdit}
      />
    </div>
  );
}
