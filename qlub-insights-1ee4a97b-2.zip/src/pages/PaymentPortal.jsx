
import React, { useEffect, useState, useMemo, useCallback } from "react";
import { PaymentLink, Order, Restaurant, Table, Payment } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Loader2, Wallet, CreditCard, Smartphone, AlertTriangle, CheckCircle2 } from "lucide-react";
import { createPageUrl } from "@/utils";
import { SendEmail } from "@/api/integrations";
import PaymentSuccessOverlay from "@/components/payment/PaymentSuccessOverlay";
import { CustomerFeedback } from "@/api/entities";

export default function PaymentPortal() {
  const urlParams = new URLSearchParams(window.location.search);
  const paymentLinkId = urlParams.get("payment_link_id");

  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [link, setLink] = useState(null);
  const [order, setOrder] = useState(null);
  const [restaurant, setRestaurant] = useState(null);

  const [method, setMethod] = useState("apple_pay"); // apple_pay | google_pay | card
  const [tipPercent, setTipPercent] = useState(0);
  const [customTip, setCustomTip] = useState("");
  const [receiptEmail, setReceiptEmail] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const load = useCallback(async () => {
    if (!paymentLinkId) return;
    setLoading(true);

    const links = await PaymentLink.filter({ id: paymentLinkId });
    const l = links?.[0] || null;
    setLink(l || null);

    if (l?.restaurant_id) {
      const rs = await Restaurant.filter({ id: l.restaurant_id });
      setRestaurant(rs?.[0] || null);
    } else {
      setRestaurant(null);
    }

    if (l?.order_id) {
      const os = await Order.filter({ id: l.order_id });
      setOrder(os?.[0] || null);
    } else {
      setOrder(null);
    }

    setLoading(false);
  }, [paymentLinkId]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    // Prefill email from link if available
    if (link?.customer_email && !receiptEmail) {
      setReceiptEmail(link.customer_email);
    }
  }, [link, receiptEmail]);

  const currency = restaurant?.settings?.currency || link?.currency || "AED";
  const tipSuggestions = restaurant?.settings?.tip_suggestions || [10, 15, 20];
  const gatewayMode = restaurant?.settings?.payment_gateway_mode || "simulated";
  const provider = restaurant?.settings?.payment_gateway_provider || "stripe";

  const subtotal = useMemo(() => {
    if (order?.subtotal != null) return Number(order.subtotal) || 0;
    return Number(link?.amount || 0);
  }, [order?.subtotal, link?.amount]);

  const serviceCharge = useMemo(() => {
    const rate = Number(restaurant?.settings?.service_charge || 0);
    return +(subtotal * (rate / 100)).toFixed(2);
  }, [restaurant?.settings?.service_charge, subtotal]);

  const taxAmount = useMemo(() => {
    const rate = Number(restaurant?.settings?.tax_rate || 0);
    return +(subtotal * (rate / 100)).toFixed(2);
  }, [restaurant?.settings?.tax_rate, subtotal]);

  const tipAmount = useMemo(() => {
    const custom = Number(customTip || 0);
    if (custom > 0) return +custom.toFixed(2);
    const pct = Number(tipPercent || 0);
    return +((subtotal * (pct / 100)) || 0).toFixed(2);
  }, [tipPercent, customTip, subtotal]);

  const total = useMemo(
    () => +(subtotal + serviceCharge + taxAmount + tipAmount).toFixed(2),
    [subtotal, serviceCharge, taxAmount, tipAmount]
  );

  const fmt = (v) => `${currency} ${Number(v || 0).toFixed(2)}`;

  const simulatePayment = async () => {
    if (!link || link.status !== "active" || processing) return;
    setProcessing(true);

    // Simulated successful payment
    await Payment.create({
      order_id: link.order_id || undefined,
      restaurant_id: link.restaurant_id,
      table_id: order?.table_id || undefined,
      payment_method: method === "card" ? "card" : "digital_wallet",
      payment_type: "full",
      amount: total,
      tip_amount: tipAmount,
      status: "completed"
    });

    await PaymentLink.update(link.id, {
      ...link,
      status: "paid",
      usage_count: (link.usage_count || 0) + 1
    });

    if (order?.id) {
      await Order.update(order.id, {
        ...order,
        tip_amount: tipAmount,
        payment_status: "paid",
        status: "paid"
      });
    }

    if (order?.table_id) {
      const tables = await Table.filter({ id: order.table_id });
      const t = tables?.[0];
      if (t) {
        await Table.update(t.id, { ...t, status: "available" });
      }
    }

    // Send email receipt (optional, only if email provided)
    if (receiptEmail) {
      const restName = restaurant?.name || "Your Restaurant";
      const subject = `Receipt from ${restName}`;
      const body = [
        `Thank you for your payment at ${restName}.`,
        "",
        `Amount: ${fmt(total)}`,
        tipAmount ? `Tip: ${fmt(tipAmount)}` : "",
        order?.id ? `Order: #${order.id}` : "",
        link?.reference ? `Reference: ${link.reference}` : "",
        "",
        `Date: ${new Date().toLocaleString()}`,
        "",
        "We appreciate your business!"
      ].filter(Boolean).join("\n");
      await SendEmail({
        to: receiptEmail,
        subject,
        body
      });
    }

    // NEW: premium success overlay before redirect (simulated mode)
    setShowSuccess(true);
    const fbUrl = createPageUrl(
      `Feedback?restaurant_id=${encodeURIComponent(link.restaurant_id)}${order?.id ? `&order_id=${encodeURIComponent(order.id)}` : ""}`
    );
    setTimeout(() => {
      window.location.href = fbUrl;
    }, 2000);
  };

  const startBackendPayment = async () => {
    if (!link || link.status !== "active" || processing) return;
    setProcessing(true);

    const origin = window.location.origin;
    const successUrl = origin + createPageUrl(`PaymentReturn?payment_link_id=${encodeURIComponent(link.id)}&provider=${encodeURIComponent(provider)}&result=success`);
    const cancelUrl = origin + createPageUrl(`PaymentReturn?payment_link_id=${encodeURIComponent(link.id)}&provider=${encodeURIComponent(provider)}&result=cancel`);

    const res = await fetch("/api/payments/create-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        provider,
        link_id: link.id,
        restaurant_id: link.restaurant_id,
        order_id: order?.id || null,
        currency,
        amounts: {
          subtotal,
          service_charge: serviceCharge,
          tax: taxAmount,
          tip: tipAmount,
          total
        },
        meta: {
          method,
          reference: link.reference || null,
          description: link.description || null
        },
        // NEW: callback URLs and optional customer email for receipt
        success_url: successUrl,
        cancel_url: cancelUrl,
        customer_email: receiptEmail || link?.customer_email || null
      })
    });

    const data = await res.json().catch(() => ({}));

    if (data.redirect_url) {
      window.location.href = data.redirect_url;
      return;
    }

    // If backend immediately confirms (rare), redirect to our return page for verification UX
    if (data.status === "confirmed" || data.success === true) {
      window.location.href = successUrl;
      return;
    }

    setProcessing(false);
    alert("Payment session could not be created. Please try again later.");
  };

  if (!paymentLinkId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="max-w-md w-full bg-rose-50 border border-rose-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-rose-700">
              <AlertTriangle className="w-5 h-5" />
              Invalid Payment Link
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700">Missing payment_link_id in URL.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          <p className="text-slate-600">Loading payment details...</p>
        </div>
      </div>
    );
  }

  if (!link) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="max-w-md w-full bg-amber-50 border border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <AlertTriangle className="w-5 h-5" />
              Link Not Found
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700">This payment link may have been deleted.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Enforce link expiry
  const isExpired = link.expires_at ? new Date(link.expires_at).getTime() < Date.now() : false;
  if (isExpired) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="max-w-md w-full bg-amber-50 border border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <AlertTriangle className="w-5 h-5" /> Link Expired
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700">This payment link expired on {new Date(link.expires_at).toLocaleString()}.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (link.status !== "active") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Card className="max-w-md w-full bg-amber-50 border border-amber-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <AlertTriangle className="w-5 h-5" /> Link Unavailable
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700">This payment link is {link.status}.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">
              {restaurant?.name || "Payment"} — {fmt(total)}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  type="button"
                  variant={method === "apple_pay" ? "default" : "outline"}
                  onClick={() => setMethod("apple_pay")}
                >
                  <Smartphone className="w-4 h-4 mr-2" />
                  Apple Pay
                </Button>
                <Button
                  type="button"
                  variant={method === "google_pay" ? "default" : "outline"}
                  onClick={() => setMethod("google_pay")}
                >
                  <Smartphone className="w-4 h-4 mr-2" />
                  Google Pay
                </Button>
                <Button
                  type="button"
                  variant={method === "card" ? "default" : "outline"}
                  onClick={() => setMethod("card")}
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Card
                </Button>
              </div>
            </div>

            <Separator />

            {/* Email receipt */}
            <div className="space-y-2">
              <Label htmlFor="receiptEmail">Email receipt (optional)</Label>
              <Input
                id="receiptEmail"
                type="email"
                placeholder="name@example.com"
                value={receiptEmail}
                onChange={(e) => setReceiptEmail(e.target.value)}
              />
            </div>

            <Separator />

            <div className="space-y-3">
              <Label>Tip</Label>
              <div className="flex gap-2">
                {(tipSuggestions || []).map((p) => (
                  <Button
                    key={p}
                    type="button"
                    variant={tipPercent === p && !customTip ? "default" : "outline"}
                    onClick={() => {
                      setCustomTip("");
                      setTipPercent(p);
                    }}
                  >
                    {p}%
                  </Button>
                ))}
                <Input
                  type="number"
                  min="0"
                  step="0.5"
                  placeholder="Custom amount"
                  value={customTip}
                  onChange={(e) => {
                    setCustomTip(e.target.value);
                    setTipPercent(0);
                  }}
                  className="w-40"
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between text-sm text-slate-600">
                <span>Subtotal</span>
                <span>{fmt(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>Service charge</span>
                <span>{fmt(serviceCharge)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>Tax</span>
                <span>{fmt(taxAmount)}</span>
              </div>
              <div className="flex justify-between text-sm text-slate-600">
                <span>Tip</span>
                <span>{fmt(tipAmount)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span>{fmt(total)}</span>
              </div>
            </div>

            <div className="pt-2">
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={gatewayMode === "backend" ? startBackendPayment : simulatePayment}
                disabled={processing}
              >
                {processing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Wallet className="w-4 h-4 mr-2" />}
                {gatewayMode === "backend" ? "Proceed to Secure Payment" : "Pay Now (Simulated)"}
              </Button>
              {gatewayMode === "backend" && (
                <p className="text-xs text-slate-500 mt-2">
                  You’ll be redirected to a secure payment page. Upon completion, our webhook will update your order.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="text-center text-xs text-slate-500 mt-4">
          {gatewayMode === "simulated" ? (
            <span className="inline-flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Testing mode — no real charges will occur.
            </span>
          ) : (
            <span className="inline-flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-green-600" /> Secure payment powered by your backend ({provider}).
            </span>
          )}
          {link.expires_at && (
            <p className="inline-flex items-center gap-1 mt-1 text-slate-400">
              Expires: {new Date(link.expires_at).toLocaleString()}
            </p>
          )}
        </div>
      </div>
      {showSuccess && (
        <PaymentSuccessOverlay
          open={showSuccess}
          onClose={() => setShowSuccess(false)}
          amount={total}
          currency={currency}
          restaurantName={restaurant?.name}
          orderId={order?.id}
          receiptEmail={receiptEmail || link?.customer_email}
          autoRedirectInSeconds={2}
          onGiveFeedback={async (rating, comment) => {
            await CustomerFeedback.create({
              restaurant_id: link.restaurant_id,
              order_id: order?.id || undefined,
              customer_name: "", // unknown at payment time
              customer_email: receiptEmail || link?.customer_email || "",
              rating,
              food_rating: rating,
              service_rating: rating,
              atmosphere_rating: rating,
              comment,
              experience_highlights: [],
              improvement_areas: [],
              would_recommend: rating >= 4,
              visit_frequency: "occasional"
            });
            const fbUrl = createPageUrl(
              `Feedback?restaurant_id=${encodeURIComponent(link.restaurant_id)}${order?.id ? `&order_id=${encodeURIComponent(order.id)}` : ""}`
            );
            window.location.href = fbUrl;
          }}
        />
      )}
    </div>
  );
}
