import React, { useState } from "react";
import { CustomerFeedback } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Star, CheckCircle2 } from "lucide-react";

export default function FeedbackPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const restaurant_id = urlParams.get("restaurant_id") || "";
  const order_id = urlParams.get("order_id") || "";

  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submitFeedback = async () => {
    if (!restaurant_id || !rating) return;
    await CustomerFeedback.create({
      restaurant_id,
      order_id: order_id || undefined,
      customer_name: name || undefined,
      customer_email: email || undefined,
      rating: Number(rating),
      comment: comment || undefined,
      would_recommend: true
    });
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <Card className="max-w-md w-full text-center">
          <CardHeader>
            <CardTitle className="flex items-center justify-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              Thank you!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 mb-4">Your feedback helps us improve.</p>
            <Button onClick={() => (window.location.href = "/")} variant="outline">
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Rate your experience</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-sm text-slate-700">Overall rating</Label>
              <div className="flex items-center gap-2 mt-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => setRating(n)}
                    className={`p-2 rounded-full ${rating >= n ? "text-amber-500" : "text-slate-300"}`}
                    aria-label={`Rate ${n}`}
                  >
                    <Star className="w-6 h-6 fill-current" />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-sm text-slate-700">Your name (optional)</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe" />
            </div>

            <div>
              <Label className="text-sm text-slate-700">Email (optional)</Label>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>

            <div>
              <Label className="text-sm text-slate-700">Comments (optional)</Label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Tell us about your experience..."
                className="min-h-[120px]"
              />
            </div>

            <Button className="w-full bg-purple-600 hover:bg-purple-700" onClick={submitFeedback} disabled={!restaurant_id}>
              Submit Feedback
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}