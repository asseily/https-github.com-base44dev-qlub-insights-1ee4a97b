import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import ProductModules from "./ProductModules";

import Pricing from "./Pricing";

import CustomerMenu from "./CustomerMenu";

import RestaurantDashboard from "./RestaurantDashboard";

import PaymentPortal from "./PaymentPortal";

import RestaurantAnalytics from "./RestaurantAnalytics";

import KDS from "./KDS";

import Feedback from "./Feedback";

import PaymentReturn from "./PaymentReturn";

import Integrations from "./Integrations";

import Competitive from "./Competitive";

import Changelog from "./Changelog";

import Exports from "./Exports";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    ProductModules: ProductModules,
    
    Pricing: Pricing,
    
    CustomerMenu: CustomerMenu,
    
    RestaurantDashboard: RestaurantDashboard,
    
    PaymentPortal: PaymentPortal,
    
    RestaurantAnalytics: RestaurantAnalytics,
    
    KDS: KDS,
    
    Feedback: Feedback,
    
    PaymentReturn: PaymentReturn,
    
    Integrations: Integrations,
    
    Competitive: Competitive,
    
    Changelog: Changelog,
    
    Exports: Exports,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/ProductModules" element={<ProductModules />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/CustomerMenu" element={<CustomerMenu />} />
                
                <Route path="/RestaurantDashboard" element={<RestaurantDashboard />} />
                
                <Route path="/PaymentPortal" element={<PaymentPortal />} />
                
                <Route path="/RestaurantAnalytics" element={<RestaurantAnalytics />} />
                
                <Route path="/KDS" element={<KDS />} />
                
                <Route path="/Feedback" element={<Feedback />} />
                
                <Route path="/PaymentReturn" element={<PaymentReturn />} />
                
                <Route path="/Integrations" element={<Integrations />} />
                
                <Route path="/Competitive" element={<Competitive />} />
                
                <Route path="/Changelog" element={<Changelog />} />
                
                <Route path="/Exports" element={<Exports />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}