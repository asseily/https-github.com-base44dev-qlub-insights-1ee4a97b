

import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  FileText, 
  LayoutDashboard, 
  Package, 
  DollarSign, 
  Users, 
  Zap,
  Building2,
  Download,
  ChefHat, // Added ChefHat icon
  History // Added History icon for Changelog
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Restaurant Dashboard",
    url: createPageUrl("RestaurantDashboard"),
    icon: ChefHat,
  },
  {
    title: "Executive Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Product Modules", 
    url: createPageUrl("ProductModules"),
    icon: Package,
  },
  {
    title: "Pricing & Fees",
    url: createPageUrl("Pricing"),
    icon: DollarSign,
  },
  {
    title: "Competitive Analysis",
    url: createPageUrl("Competitive"),
    icon: Users,
  },
  {
    title: "Integration Roadmap",
    url: createPageUrl("Integrations"),
    icon: Zap,
  },
  {
    title: "Changelog", // New navigation item for Changelog
    url: createPageUrl("Changelog"),
    icon: History,
  },
  {
    title: "Data Export",
    url: createPageUrl("Exports"),
    icon: Download,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isOffline, setIsOffline] = useState(typeof navigator !== "undefined" ? !navigator.onLine : false);

  useEffect(() => {
    const onOnline = () => setIsOffline(false);
    const onOffline = () => setIsOffline(true);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader className="border-b border-slate-100 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-900 to-amber-600 rounded-xl flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">Qlub Product Brief</h2>
                <p className="text-xs text-slate-500">UAE Restaurant Fintech</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-3">
                Analysis Sections
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-amber-50 hover:text-amber-700 transition-all duration-200 rounded-xl mb-2 ${
                          location.pathname === item.url ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'text-slate-600'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-8">
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-3">
                Key Metrics
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-4 py-2 space-y-4">
                  <div className="p-3 rounded-xl bg-green-50 border border-green-100">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-green-700">Checkout Speed</span>
                      <span className="text-lg font-bold text-green-800">10s</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-50 border border-blue-100">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-blue-700">Basket Increase</span>
                      <span className="text-lg font-bold text-blue-800">+6%</span>
                    </div>
                  </div>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-100 p-4">
            <Link to={createPageUrl("Dashboard?export=report")} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 hover:bg-amber-50 transition-colors">
              <div className="w-8 h-8 bg-amber-600 rounded-full flex items-center justify-center">
                <FileText className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-900 text-sm">Executive Brief</p>
                <p className="text-xs text-slate-500">Click to download</p>
              </div>
              <Download className="w-4 h-4 text-slate-400" />
            </Link>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col bg-slate-50">
          {isOffline && (
            <div className="sticky top-0 z-50 bg-amber-50 border-b border-amber-200 text-amber-800 text-sm px-4 py-2">
              <div className="max-w-7xl mx-auto">
                You’re offline. Some data may be unavailable. Changes will sync when you’re back online.
              </div>
            </div>
          )}
          <header className="bg-white border-b border-slate-200 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg" />
              <h1 className="text-xl font-bold text-slate-900">Qlub Product Brief</h1>
            </div>
          </header>
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

