
import React, { useState } from "react";
import { ProductModule, PricingStructure, CompetitiveAnalysis, IntegrationRequirement, Customer, CustomerFeedback, Order } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Package, DollarSign, Users, Zap, MessageSquare, Receipt, Loader2 } from "lucide-react";

export default function Exports() {
  const [isExporting, setIsExporting] = useState(false);
  const [status, setStatus] = useState("");

  const toCSVAndDownload = (filename, headers, rows) => {
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    // Prepend UTF-8 BOM to ensure Excel renders Unicode and separators correctly
    const csvWithBom = '\uFEFF' + csv;
    const blob = new Blob([csvWithBom], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportModules = async () => {
    setIsExporting(true); setStatus("Exporting Product Modules...");
    const data = await ProductModule.list("-created_date", 2000);
    const headers = ["Name","Category","Description","Key Features","Value Propositions","Technical Enablers","Partnerships","Created At"];
    const rows = (data || []).map(m => ([
      m.name || "",
      m.category || "",
      m.description || "",
      Array.isArray(m.key_features) ? m.key_features.join(" | ") : "",
      Array.isArray(m.value_propositions) ? m.value_propositions.join(" | ") : "",
      Array.isArray(m.technical_enablers) ? m.technical_enablers.join(" | ") : "",
      Array.isArray(m.partnerships) ? m.partnerships.join(" | ") : "",
      m.created_date ? new Date(m.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("product_modules", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportPricing = async () => {
    setIsExporting(true); setStatus("Exporting Pricing...");
    const data = await PricingStructure.list("-created_date", 2000);
    const headers = ["Fee Type","Explicit Rate","Placeholder Rate","Benchmark Min","Benchmark Max","Currency","Frequency","Status","Created At"];
    const rows = (data || []).map(p => ([
      p.fee_type || "",
      p.explicit_rate || "",
      p.placeholder_rate || "",
      p.uae_benchmark_min ?? "",
      p.uae_benchmark_max ?? "",
      p.currency || "",
      p.frequency || "",
      p.status || "",
      p.created_date ? new Date(p.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("pricing", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportCompetitors = async () => {
    setIsExporting(true); setStatus("Exporting Competitors...");
    const data = await CompetitiveAnalysis.list("-created_date", 2000);
    const headers = ["Competitor","Region","Market Position","Strengths","Weaknesses","Differentiators","Created At"];
    const rows = (data || []).map(c => ([
      c.competitor_name || "",
      c.region || "",
      c.market_position || "",
      Array.isArray(c.strengths) ? c.strengths.join(" | ") : "",
      Array.isArray(c.weaknesses) ? c.weaknesses.join(" | ") : "",
      Array.isArray(c.differentiators) ? c.differentiators.join(" | ") : "",
      c.created_date ? new Date(c.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("competitors", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportIntegrations = async () => {
    setIsExporting(true); setStatus("Exporting Integrations...");
    const data = await IntegrationRequirement.list("-created_date", 2000);
    const headers = ["Integration","Priority","Status","Business Impact","Requirements","Technical Challenges","Target Customers","Timeline","Created At"];
    const rows = (data || []).map(i => ([
      i.integration_name || "",
      i.priority || "",
      i.status || "",
      i.business_impact || "",
      Array.isArray(i.requirements) ? i.requirements.join(" | ") : "",
      Array.isArray(i.technical_challenges) ? i.technical_challenges.join(" | ") : "",
      Array.isArray(i.target_customers) ? i.target_customers.join(" | ") : "",
      i.timeline || "",
      i.created_date ? new Date(i.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("integrations", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportCustomers = async () => {
    setIsExporting(true); setStatus("Exporting Customers...");
    const data = await Customer.list("-created_date", 5000);
    const headers = ["Name","Email","Phone","Total Spent","Order Count","Last Visit","Tags","Created At"];
    const rows = (data || []).map(c => ([
      c.name || "",
      c.email || "",
      c.phone || "",
      c.total_spent ?? 0,
      c.order_count ?? 0,
      c.last_visit_date ? new Date(c.last_visit_date).toISOString() : "",
      Array.isArray(c.tags) ? c.tags.join(" | ") : "",
      c.created_date ? new Date(c.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("customers", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportFeedback = async () => {
    setIsExporting(true); setStatus("Exporting Feedback...");
    const data = await CustomerFeedback.list("-created_date", 5000);
    const headers = ["Restaurant ID","Order ID","Name","Email","Rating","Food","Service","Atmosphere","Comment","Highlights","Improvements","Recommend","Visit Frequency","Created At"];
    const rows = (data || []).map(f => ([
      f.restaurant_id || "",
      f.order_id || "",
      f.customer_name || "",
      f.customer_email || "",
      f.rating ?? "",
      f.food_rating ?? "",
      f.service_rating ?? "",
      f.atmosphere_rating ?? "",
      (f.comment || "").replace(/\n/g, " "),
      Array.isArray(f.experience_highlights) ? f.experience_highlights.join(" | ") : "",
      Array.isArray(f.improvement_areas) ? f.improvement_areas.join(" | ") : "",
      f.would_recommend ? "Yes" : "No",
      f.visit_frequency || "",
      f.created_date ? new Date(f.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("feedback", headers, rows);
    setIsExporting(false); setStatus("");
  };

  const exportOrders = async () => {
    setIsExporting(true); setStatus("Exporting Orders...");
    const data = await Order.list("-created_date", 5000);
    const headers = ["Restaurant ID","Table ID","Status","Payment Status","Subtotal","Tax","Service Charge","Tip","Total","Items Count","Customer Name","Notes","Created At"];
    const rows = (data || []).map(o => ([
      o.restaurant_id || "",
      o.table_id || "",
      o.status || "",
      o.payment_status || "",
      o.subtotal ?? 0,
      o.tax_amount ?? 0,
      o.service_charge ?? 0,
      o.tip_amount ?? 0,
      o.total ?? 0,
      Array.isArray(o.items) ? o.items.length : 0,
      o.customer_name || "",
      (o.notes || "").replace(/\n/g, " "),
      o.created_date ? new Date(o.created_date).toISOString() : ""
    ]));
    toCSVAndDownload("orders", headers, rows);
    setIsExporting(false); setStatus("");
  };

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Data Export</h1>
            <p className="text-slate-600">Download CSVs of your key datasets.</p>
          </div>
          <div className="text-sm text-slate-500">{isExporting ? status : ""}</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" /> Product Modules
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportModules} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600" /> Pricing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportPricing} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" /> Competitors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportCompetitors} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-600" /> Integrations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportIntegrations} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-slate-700" /> Customers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportCustomers} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-rose-600" /> Feedback
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportFeedback} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-slate-600" /> Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button onClick={exportOrders} disabled={isExporting} className="flex items-center gap-2 w-full">
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} Export CSV
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
