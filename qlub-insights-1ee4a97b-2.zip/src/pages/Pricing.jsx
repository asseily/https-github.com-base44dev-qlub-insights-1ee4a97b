
import React, { useState, useEffect } from "react";
import { PricingStructure } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, DollarSign, Plus, Eye, EyeOff, RefreshCw, Download } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

import PricingTable from "../components/pricing/PricingTable";
import PricingForm from "../components/pricing/PricingForm";
import BenchmarkComparison from "../components/pricing/BenchmarkComparison";

export default function PricingPage() {
  const [pricingData, setPricingData] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingPrice, setEditingPrice] = useState(null);
  const [showBenchmarks, setShowBenchmarks] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPricing();
  }, []);

  const loadPricing = async () => {
    setIsLoading(true);
    const data = await PricingStructure.list('-created_date');
    setPricingData(data);
    setIsLoading(false);
  };

  const handleSubmit = async (priceData) => {
    setIsLoading(true); // Set loading true while submitting
    if (editingPrice) {
      await PricingStructure.update(editingPrice.id, priceData);
    } else {
      await PricingStructure.create(priceData);
    }
    setShowForm(false);
    setEditingPrice(null);
    await loadPricing(); // Reload data after submit
    setIsLoading(false); // Set loading false after reload
  };

  const handleEdit = (price) => {
    setEditingPrice(price);
    setShowForm(true);
  };

  const exportPricingCSV = () => {
    const headers = [
      "Fee Type",
      "Qlub Rate",
      "Benchmark Min",
      "Benchmark Max",
      "Currency",
      "Frequency",
      "Status",
      "Created At"
    ];
    const rows = (pricingData || []).map(p => ([
      p.fee_type || "",
      p.explicit_rate || p.placeholder_rate || "Not disclosed",
      p.uae_benchmark_min ?? "",
      p.uae_benchmark_max ?? "",
      p.currency || "",
      p.frequency || "",
      p.status || "",
      p.created_date || ""
    ]));
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pricing_export_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const missingPricing = pricingData.filter(p => p.status === 'missing').length;
  const totalPricing = pricingData.length;

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              Pricing & Fees Structure
            </h1>
            <p className="text-slate-600 text-lg">
              Analysis of Qlub's pricing model and UAE market benchmarks
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={loadPricing}
              className="flex items-center gap-2"
              disabled={isLoading} // Disable button while loading
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              onClick={exportPricingCSV}
              className="flex items-center gap-2"
              disabled={isLoading || (pricingData || []).length === 0}
            >
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowBenchmarks(!showBenchmarks)}
              className="flex items-center gap-2"
            >
              {showBenchmarks ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showBenchmarks ? 'Hide' : 'Show'} Benchmarks
            </Button>
            <Button
              onClick={() => setShowForm(!showForm)}
              className="bg-emerald-600 hover:bg-emerald-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Pricing Data
            </Button>
          </div>
        </div>

        {/* Transparency Alert */}
        {missingPricing > 0 && (
          <Alert className="border-amber-200 bg-amber-50">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              <strong>Pricing Transparency Gap:</strong> {missingPricing} out of {totalPricing} pricing points are not publicly disclosed by Qlub.
              This creates a competitive disadvantage compared to transparent competitors. All rates below are estimates based on UAE market benchmarks.
            </AlertDescription>
          </Alert>
        )}

        {/* Key Insights */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-amber-200 bg-amber-50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-amber-800">
                <DollarSign className="w-5 h-5" />
                Missing Rates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-900 mb-1">
                {missingPricing}/{totalPricing}
              </div>
              <p className="text-sm text-amber-700">Pricing points not disclosed</p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <DollarSign className="w-5 h-5" />
                Est. MDR Range
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900 mb-1">1.8-3.0%</div>
              <p className="text-sm text-blue-700">UAE market benchmark</p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-green-800">
                <DollarSign className="w-5 h-5" />
                Est. SaaS Fee
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900 mb-1">AED 150-300</div>
              <p className="text-sm text-green-700">Monthly subscription</p>
            </CardContent>
          </Card>
        </div>

        {/* Pricing Form */}
        {showForm && (
          <PricingForm
            price={editingPrice}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingPrice(null);
            }}
          />
        )}

        {/* Main Content */}
        <div className="grid gap-8">
          <PricingTable
            pricingData={pricingData}
            onEdit={handleEdit}
            isLoading={isLoading}
          />

          {showBenchmarks && (
            <BenchmarkComparison pricingData={pricingData} />
          )}
        </div>
      </div>
    </div>
  );
}
