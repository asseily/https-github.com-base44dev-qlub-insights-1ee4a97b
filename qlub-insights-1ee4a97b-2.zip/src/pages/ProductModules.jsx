
import React, { useState, useEffect } from "react";
import { ProductModule } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Package, Search, Filter, Download, RefreshCw } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import ModuleCard from "../components/modules/ModuleCard";
import ModuleForm from "../components/modules/ModuleForm";

export default function ProductModulesPage() {
  const [modules, setModules] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingModule, setEditingModule] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadModules();
  }, []);

  const loadModules = async () => {
    setIsLoading(true);
    const data = await ProductModule.list('-created_date');
    setModules(data);
    setIsLoading(false);
  };

  const handleSubmit = async (moduleData) => {
    if (editingModule) {
      await ProductModule.update(editingModule.id, moduleData);
    } else {
      await ProductModule.create(moduleData);
    }
    setShowForm(false);
    setEditingModule(null);
    loadModules();
  };

  const handleEdit = (module) => {
    setEditingModule(module);
    setShowForm(true);
  };

  const resetFilters = () => {
    setSearchTerm("");
    setActiveCategory("all");
  };

  const filteredModules = modules.filter(module => {
    const matchesSearch = module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "all" || module.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const exportModulesCSV = () => {
    const headers = [
      "Name",
      "Category",
      "Description",
      "Key Features",
      "Value Props",
      "Technical Enablers",
      "Partnerships"
    ];
    const rowsOut = (filteredModules || []).map(m => ([
      m.name || "",
      m.category || "",
      m.description || "",
      Array.isArray(m.key_features) ? m.key_features.join(" | ") : "",
      Array.isArray(m.value_propositions) ? m.value_propositions.join(" | ") : "",
      Array.isArray(m.technical_enablers) ? m.technical_enablers.join(" | ") : "",
      Array.isArray(m.partnerships) ? m.partnerships.join(" | ") : ""
    ]));
    const csv = [headers, ...rowsOut]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `product_modules_export_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">Product Modules</h1>
            <p className="text-slate-600 text-lg">
              Comprehensive analysis of Qlub's product offerings
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={loadModules}
              disabled={isLoading}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              onClick={exportModulesCSV}
              disabled={isLoading || (filteredModules || []).length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" /> Export CSV
            </Button>
            <Button 
              onClick={() => setShowForm(!showForm)}
              className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add New Module
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search modules..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Tabs value={activeCategory} onValueChange={setActiveCategory}>
                <TabsList className="bg-slate-100">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="core">Core</TabsTrigger>
                  <TabsTrigger value="addon">Add-on</TabsTrigger>
                  <TabsTrigger value="integration">Integration</TabsTrigger>
                </TabsList>
              </Tabs>
              <Button
                variant="ghost"
                size="sm"
                onClick={resetFilters}
                disabled={searchTerm === "" && activeCategory === "all"}
                className="flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Reset
              </Button>
            </div>
          </div>
        </Card>

        {/* Module Form */}
        {showForm && (
          <ModuleForm
            module={editingModule}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingModule(null);
            }}
          />
        )}

        {/* Modules Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredModules.map((module) => (
            <ModuleCard
              key={module.id}
              module={module}
              onEdit={handleEdit}
            />
          ))}
        </div>

        {filteredModules.length === 0 && !isLoading && (
          <Card className="text-center py-12">
            <Package className="w-12 h-12 mx-auto text-slate-400 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No modules found</h3>
            <p className="text-slate-600 mb-4">
              {searchTerm || activeCategory !== "all" 
                ? "Try adjusting your search or filters" 
                : "Add your first product module to get started"
              }
            </p>
            <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Module
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
