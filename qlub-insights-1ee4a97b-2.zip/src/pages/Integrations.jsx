
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { IntegrationRequirement } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, Loader2, Download, RefreshCw } from "lucide-react";
import IntegrationKanban from "@/components/integrations/IntegrationKanban";
import IntegrationRequirementForm from "@/components/integrations/IntegrationRequirementForm";

export default function Integrations() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const [q, setQ] = useState("");
  const [priority, setPriority] = useState("all");
  const [status, setStatus] = useState("all");

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await IntegrationRequirement.list("-updated_date", 500);
    setItems(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    return (items || []).filter((it) => {
      const matchesQ = !q || (it.integration_name || "").toLowerCase().includes(q.toLowerCase());
      const matchesPriority = priority === "all" || it.priority === priority;
      const matchesStatus = status === "all" || it.status === status;
      return matchesQ && matchesPriority && matchesStatus;
    });
  }, [items, q, priority, status]);

  const resetFilters = () => {
    setQ("");
    setPriority("all");
    setStatus("all");
  };

  const exportIntegrationsCSV = () => {
    const headers = [
      "Integration",
      "Priority",
      "Status",
      "Business Impact",
      "Requirements",
      "Technical Challenges",
      "Target Customers",
      "Timeline"
    ];
    const rowsOut = (filtered || []).map(i => ([
      i.integration_name || "",
      i.priority || "",
      i.status || "",
      i.business_impact || "",
      Array.isArray(i.requirements) ? i.requirements.join(" | ") : "",
      Array.isArray(i.technical_challenges) ? i.technical_challenges.join(" | ") : "",
      Array.isArray(i.target_customers) ? i.target_customers.join(" | ") : "",
      i.timeline || ""
    ]));
    const csv = [headers, ...rowsOut]
      .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `integrations_export_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAdd = () => { setEditing(null); setFormOpen(true); };
  const handleEdit = (item) => { setEditing(item); setFormOpen(true); };

  const handleSave = async (payload) => {
    if (editing) {
      await IntegrationRequirement.update(editing.id, payload);
    } else {
      await IntegrationRequirement.create(payload);
    }
    setFormOpen(false);
    setEditing(null);
    load();
  };

  const handleStatusChange = async (item, newStatus) => {
    await IntegrationRequirement.update(item.id, { ...item, status: newStatus });
    // Optimistic update
    setItems((prev) => prev.map((p) => (p.id === item.id ? { ...p, status: newStatus } : p)));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Integration Roadmap</h1>
            <p className="text-slate-600">Plan and track integrations — clean, simple, and focused.</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={exportIntegrationsCSV}
              disabled={loading || (filtered || []).length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" /> Export CSV
            </Button>
            <Button onClick={handleAdd} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" /> Add Integration
            </Button>
          </div>
        </div>

        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col xl:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input placeholder="Search integrations..." value={q} onChange={(e) => setQ(e.target.value)} className="pl-10" />
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-slate-500 text-sm">
                  <Filter className="w-4 h-4" /> Filters
                </div>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger className="w-44">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="w-44">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="planned">Planned</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="on-hold">On Hold</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={resetFilters}
                  disabled={loading || (q === "" && priority === "all" && status === "all")}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Reset
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex items-center justify-center py-16 text-slate-500">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Loading integrations...
          </div>
        ) : (
          <IntegrationKanban items={filtered} onStatusChange={handleStatusChange} onEdit={handleEdit} />
        )}
      </div>

      <IntegrationRequirementForm
        open={formOpen}
        onOpenChange={setFormOpen}
        initialData={editing}
        onSubmit={handleSave}
      />
    </div>
  );
}
