import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Order } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

function KDSOrderTicket({ order, onStatusChange }) {
  const [time, setTime] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeSinceOrder = formatDistanceToNow(new Date(order.created_date), { addSuffix: true });
  const timeElapsedMinutes = Math.floor((time - new Date(order.created_date).getTime()) / 60000);

  const cardColor = timeElapsedMinutes > 10 ? 'bg-red-200 border-red-500' 
                  : timeElapsedMinutes > 5 ? 'bg-amber-100 border-amber-400' 
                  : 'bg-white border-slate-200';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 50, scale: 0.8 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.5 }}
      transition={{ duration: 0.5, type: 'spring' }}
      className={`rounded-lg shadow-lg border-t-8 ${cardColor} flex flex-col`}
    >
      <div className="p-4 border-b">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-bold">Table {order.table?.table_number || 'N/A'}</h3>
          <span className="font-bold text-lg">{timeSinceOrder}</span>
        </div>
        <p className="text-sm text-slate-600">Order #{order.id.slice(-6)}</p>
      </div>
      <ul className="p-4 space-y-2 flex-grow overflow-y-auto">
        {order.items.map((item, index) => (
          <li key={index} className="flex items-start justify-between">
            <div className="flex-shrink-0 font-bold text-lg mr-3">{item.quantity}x</div>
            <div className="flex-grow">
              <p className="font-semibold">{item.name}</p>
              {item.selected_modifiers?.length > 0 && (
                <p className="text-xs text-slate-500 pl-2">
                  {item.selected_modifiers.map(m => m.option_name).join(', ')}
                </p>
              )}
               {item.special_instructions && (
                <p className="text-xs text-rose-600 pl-2 font-semibold">
                  NOTE: {item.special_instructions}
                </p>
              )}
            </div>
          </li>
        ))}
      </ul>
      <div className="p-3 bg-slate-50 rounded-b-lg">
        {order.status === 'confirmed' && (
          <button
            onClick={() => onStatusChange(order.id, 'preparing')}
            className="w-full bg-blue-600 text-white font-bold py-3 rounded-md hover:bg-blue-700 transition-colors"
          >
            Start Preparing
          </button>
        )}
        {order.status === 'preparing' && (
          <button
            onClick={() => onStatusChange(order.id, 'ready')}
            className="w-full bg-green-600 text-white font-bold py-3 rounded-md hover:bg-green-700 transition-colors"
          >
            Mark as Ready
          </button>
        )}
      </div>
    </motion.div>
  );
}


export default function KDS() {
  const [searchParams] = useSearchParams();
  const restaurantId = searchParams.get('restaurant_id');
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState(null);

  const fetchOrders = useCallback(async () => {
    if (!restaurantId) {
      setError("Restaurant ID is missing.");
      return;
    }
    try {
      const activeOrders = await Order.filter({
        restaurant_id: restaurantId,
        status: { in: ['confirmed', 'preparing', 'ready'] }
      }, '-created_date', 50, ['table']);
      setOrders(activeOrders);
      setError(null);
    } catch (err) {
      console.error("Error fetching KDS orders:", err);
      setError("Failed to load orders.");
    }
  }, [restaurantId]);

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 7000); // Poll every 7 seconds
    return () => clearInterval(interval);
  }, [fetchOrders]);

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await Order.update(orderId, { status: newStatus });
      setOrders(prevOrders => 
        newStatus === 'ready' 
          ? prevOrders.filter(o => o.id !== orderId)
          : prevOrders.map(o => o.id === orderId ? { ...o, status: newStatus } : o)
      );
    } catch (err) {
      console.error("Error updating order status:", err);
    }
  };

  const newOrders = orders.filter(o => o.status === 'confirmed');
  const preparingOrders = orders.filter(o => o.status === 'preparing');
  const readyOrders = orders.filter(o => o.status === 'ready');

  return (
    <div className="fixed inset-0 bg-slate-800 text-slate-900 flex flex-col font-sans">
      <header className="bg-slate-900 text-white p-4 shadow-md flex justify-between items-center">
        <h1 className="text-3xl font-bold">Kitchen Display System</h1>
        <div className="text-3xl font-mono">{new Date().toLocaleTimeString()}</div>
      </header>
      
      {error && <div className="text-center text-red-400 py-4">{error}</div>}

      <div className="flex-grow grid grid-cols-1 md:grid-cols-3 gap-4 p-4 overflow-hidden">
        {/* New Column */}
        <div className="bg-slate-700 rounded-lg p-3 flex flex-col">
          <h2 className="text-xl font-bold text-white mb-3 text-center">New ({newOrders.length})</h2>
          <div className="flex-grow space-y-4 overflow-y-auto">
            <AnimatePresence>
              {newOrders.map(order => (
                <KDSOrderTicket key={order.id} order={order} onStatusChange={handleStatusChange} />
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Preparing Column */}
        <div className="bg-slate-700 rounded-lg p-3 flex flex-col">
          <h2 className="text-xl font-bold text-white mb-3 text-center">Preparing ({preparingOrders.length})</h2>
          <div className="flex-grow space-y-4 overflow-y-auto">
            <AnimatePresence>
              {preparingOrders.map(order => (
                <KDSOrderTicket key={order.id} order={order} onStatusChange={handleStatusChange} />
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Ready Column */}
        <div className="bg-slate-700 rounded-lg p-3 flex flex-col">
          <h2 className="text-xl font-bold text-white mb-3 text-center">Ready ({readyOrders.length})</h2>
          <div className="flex-grow space-y-4 overflow-y-auto">
             <AnimatePresence>
              {readyOrders.map(order => (
                <KDSOrderTicket key={order.id} order={order} onStatusChange={handleStatusChange} />
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}