
import React, { useState, useEffect, useCallback } from "react";
import { Restaurant, MenuItem, Table, Order, User, Customer, Promotion, InventoryItem, Staff, PurchaseOrder, Reservation, Location, LoyaltyProgram, CustomerLoyalty } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3,
  TrendingUp,
  Users as UsersIcon,
  Clock,
  DollarSign,
  QrCode,
  Settings,
  Plus,
  Eye,
  Bell,
  TicketPercent,
  Package,
  UserCheck,
  ChefHat,
  Brain,
  Truck,
  Calendar as CalendarIcon,
  ClipboardList,
  Building2,
  Mail,
  Crown,
  Share2,
  Link as LinkIcon,
  AlertTriangle
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import RestaurantOverview from "../components/restaurant/RestaurantOverview";
import MenuManagement from "../components/restaurant/MenuManagement";
import TableManagement from "../components/restaurant/TableManagement";
import OrderManagement from "../components/restaurant/OrderManagement";
import QRCodeGenerator from "../components/restaurant/QRCodeGenerator";
import RestaurantSettings from "../components/restaurant/RestaurantSettings";
import AdvancedAnalytics from "../components/analytics/AdvancedAnalytics";
import CustomerManagement from "../components/restaurant/CustomerManagement";
import PromotionManagement from "../components/restaurant/PromotionManagement";
import InventoryManagement from "../components/restaurant/InventoryManagement";
import StaffManagement from "../components/restaurant/StaffManagement";
import SupplyChainManagement from "../components/restaurant/SupplyChainManagement";
import ReservationManagement from "../components/restaurant/ReservationManagement";
import FinancialReporting from "../components/restaurant/FinancialReporting";
import NotificationsCenter from "../components/restaurant/NotificationsCenter";
import LocationManagement from "../components/restaurant/LocationManagement";
import EmailMarketing from "../components/restaurant/EmailMarketing";
import LoyaltyProgramSettings from "../components/restaurant/LoyaltyProgramSettings";
import LoyaltyMembers from "../components/restaurant/LoyaltyMembers";
import PaymentLinksManager from "../components/restaurant/PaymentLinksManager";
import DailyBriefing from "../components/restaurant/DailyBriefing";

export default function RestaurantDashboard() {
  // Read URL params for deep-linking
  const urlParams = new URLSearchParams(window.location.search);
  const initialTab = urlParams.get('tab') || "overview";
  const preselectedTableId = urlParams.get('table_id') || "all";

  const [restaurant, setRestaurant] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [tables, setTables] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [promotions, setPromotions] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [staff, setStaff] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [activeTab, setActiveTab] = useState(initialTab);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [locations, setLocations] = useState([]);
  const [loyaltyProgram, setLoyaltyProgram] = useState(null);
  const [loyaltyMembers, setLoyaltyMembers] = useState([]);
  const [lastRefreshed, setLastRefreshed] = useState(null);

  const currency = restaurant?.settings?.currency || 'AED';

  // NEW: copied link blink state
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedMenuLink, setCopiedMenuLink] = useState(false);

  // NEW: error handling and offline detection
  const [lastError, setLastError] = useState(null);
  const [isOffline, setIsOffline] = useState(typeof navigator !== "undefined" ? !navigator.onLine : false);

  // NEW: small retry helper with backoff
  const withRetry = async (fn, retries = 3, baseDelayMs = 700) => {
    let attempt = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      try {
        return await fn();
      } catch (e) {
        attempt += 1;
        if (attempt >= retries) throw e;
        const delay = baseDelayMs * attempt;
        await new Promise((res) => setTimeout(res, delay));
      }
    }
  };

  // Memoize loadDashboardData to ensure it's stable across renders
  const loadDashboardData = useCallback(async (isInitialLoad = false, currentTab = "overview") => {
    // Skip network calls if offline to avoid error spam
    if (isOffline) {
      setLastError("Offline");
      if (isInitialLoad) setIsLoading(false);
      return;
    }

    if (isInitialLoad) setIsLoading(true);
    setLastError(null);

    // Decide which datasets to load for current tab
    const needs = {
      menu: ["overview", "menu", "qrcodes"].includes(currentTab),
      tables: ["overview", "tables", "qrcodes", "reservations"].includes(currentTab),
      orders: ["overview", "orders", "financials", "analytics", "payments"].includes(currentTab),
      customers: ["overview", "customers", "marketing", "loyalty", "analytics"].includes(currentTab),
      promotions: ["promotions", "customers", "overview"].includes(currentTab),
      inventory: ["inventory", "supply-chain", "financials"].includes(currentTab),
      staff: ["staff"].includes(currentTab),
      purchaseOrders: ["financials", "supply-chain"].includes(currentTab),
      reservations: ["reservations"].includes(currentTab),
      locations: ["locations"].includes(currentTab),
      loyalty: ["loyalty"].includes(currentTab),
    };

    try {
      const currentUser = await withRetry(() => User.me());
      if (isInitialLoad) setUser(currentUser);
      
      // Get restaurant owned by current user
      const restaurants = await withRetry(() => Restaurant.filter({ created_by: currentUser.email }));
      const userRestaurant = restaurants[0];
      
      if (userRestaurant) {
        if (isInitialLoad) setRestaurant(userRestaurant);
        
        // Build calls per need
        const calls = [];
        if (needs.menu) calls.push(withRetry(() => MenuItem.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "menu", d })));
        if (needs.tables) calls.push(withRetry(() => Table.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "tables", d })));
        if (needs.orders) calls.push(withRetry(() => Order.filter({ restaurant_id: userRestaurant.id }, '-created_date', 500)).then(d => ({ k: "orders", d })));
        if (needs.customers) calls.push(withRetry(() => Customer.filter({ restaurant_id: userRestaurant.id }, '-last_visit_date', 100)).then(d => ({ k: "customers", d })));
        if (needs.promotions) calls.push(withRetry(() => Promotion.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "promotions", d })));
        if (needs.inventory) calls.push(withRetry(() => InventoryItem.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "inventory", d })));
        if (needs.staff) calls.push(withRetry(() => Staff.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "staff", d })));
        if (needs.purchaseOrders) calls.push(withRetry(() => PurchaseOrder.filter({ restaurant_id: userRestaurant.id, status: 'delivered' }, '-delivery_date', 200)).then(d => ({ k: "purchaseOrders", d })));
        if (needs.reservations) calls.push(withRetry(() => Reservation.filter({ restaurant_id: userRestaurant.id }, '-reservation_date', 100)).then(d => ({ k: "reservations", d })));
        if (needs.locations) calls.push(withRetry(() => Location.filter({ restaurant_id: userRestaurant.id })).then(d => ({ k: "locations", d })));

        const results = await Promise.allSettled(calls);

        // Apply fulfilled results only
        results.forEach(r => {
          if (r.status === "fulfilled") {
            const { k, d } = r.value || {};
            if (k === "menu") setMenuItems(d);
            if (k === "tables") setTables(d);
            if (k === "orders") setOrders(d);
            if (k === "customers") setCustomers(d);
            if (k === "promotions") setPromotions(d);
            if (k === "inventory") setInventory(d);
            if (k === "staff") setStaff(d);
            if (k === "purchaseOrders") setPurchaseOrders(d);
            if (k === "reservations") setReservations(d);
            if (k === "locations") setLocations(d);
          }
        });

        // Loyalty program (optional) - fetch only on Loyalty tab; keep errors local
        if (needs.loyalty) {
          try {
            const programs = await withRetry(() => LoyaltyProgram.filter({ restaurant_id: userRestaurant.id }));
            const program = (programs && programs[0]) || null;
            setLoyaltyProgram(program);
            if (program) {
              try {
                const members = await withRetry(() => CustomerLoyalty.filter({ loyalty_program_id: program.id }, '-last_activity', 500));
                setLoyaltyMembers(members);
              } catch (e) {
                console.warn("CustomerLoyalty fetch failed:", e);
                setLoyaltyMembers([]);
              }
            } else {
              setLoyaltyMembers([]);
            }
          } catch (e) {
            console.warn("LoyaltyProgram fetch failed:", e);
            setLoyaltyProgram(null);
            setLoyaltyMembers([]);
          }
        }

      }
    } catch (error) {
      console.error("Error loading dashboard data:", error);
      setLastError(error?.message || "Network Error"); // NEW: store error
    }
    setLastRefreshed(new Date());
    if (isInitialLoad) setIsLoading(false);
  }, [isOffline]);

  // Initial load
  useEffect(() => {
    loadDashboardData(true, activeTab);
  }, [loadDashboardData, activeTab]);

  // Polling for real-time updates
  useEffect(() => {
    if (isOffline) return; // Skip polling when offline
    const pollInterval = setInterval(() => {
      loadDashboardData(false, activeTab); // Subsequent loads are not "initial"
    }, 15000); // Refresh data every 15 seconds

    return () => clearInterval(pollInterval); // Cleanup on unmount
  }, [loadDashboardData, activeTab, isOffline]);

  // Memoize refreshData, which depends on loadDashboardData
  const refreshData = useCallback(() => {
    loadDashboardData(true, activeTab); // A manual refresh should show loading state
  }, [loadDashboardData, activeTab]);

  // NEW: online/offline listeners
  useEffect(() => {
    const onOnline = () => {
      setIsOffline(false);
      // Optionally auto-refresh when back online
      loadDashboardData(true, activeTab);
    };
    const onOffline = () => setIsOffline(true);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, [loadDashboardData, activeTab]);

  // NEW: keep URL in sync with active tab
  useEffect(() => {
    const url = new URL(window.location.href);
    url.searchParams.set('tab', activeTab);
    // preserve existing table_id if present
    if (preselectedTableId && preselectedTableId !== "all") { // Only add if it's not the default "all"
      url.searchParams.set('table_id', preselectedTableId);
    } else {
      url.searchParams.delete('table_id'); // Remove if default
    }
    window.history.replaceState({}, "", url.toString());
  }, [activeTab, preselectedTableId]);

  // NEW: copy current dashboard link
  const copyDashboardLink = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('tab', activeTab);
    if (preselectedTableId && preselectedTableId !== "all") { // Only add if it's not the default "all"
      url.searchParams.set('table_id', preselectedTableId);
    } else {
      url.searchParams.delete('table_id'); // Remove if default
    }
    navigator.clipboard.writeText(url.toString());
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // NEW: copy live menu link
  const copyMenuLink = () => {
    if (!restaurant?.id) return;
    const url = window.location.origin + createPageUrl(`CustomerMenu?restaurant_id=${restaurant.id}`);
    navigator.clipboard.writeText(url);
    setCopiedMenuLink(true);
    setTimeout(() => setCopiedMenuLink(false), 2000);
  };

  // Enhanced metrics with AI insights
  const calculateAdvancedMetrics = () => {
    const todayOrders = orders.filter(order => {
      const today = new Date().toDateString();
      return new Date(order.created_date).toDateString() === today;
    });

    const todayRevenue = todayOrders.reduce((sum, order) => sum + (order.total || 0), 0);
    const activeOrders = orders.filter(order => 
      ['pending', 'confirmed', 'preparing', 'ready'].includes(order.status)
    );
    const occupiedTables = tables.filter(table => table.status === 'occupied').length;

    // Calculate low stock alerts
    const lowStockItems = inventory.filter(item => item.current_stock <= item.minimum_stock).length;
    const activeStaff = staff.filter(member => member.status === 'active').length;

    // Estimate Gross Profit
    const totalCost = purchaseOrders.filter(po => {
        const poDate = new Date(po.actual_delivery || po.expected_delivery);
        const today = new Date();
        return poDate.toDateString() === today.toDateString();
    }).reduce((sum, po) => sum + (po.total_amount || 0), 0); // FIX: default 0
    const grossProfit = todayRevenue - totalCost;

    return {
      todayOrders: todayOrders.length,
      todayRevenue,
      activeOrders: activeOrders.length,
      occupiedTables,
      lowStockItems,
      activeStaff,
      grossProfit
    };
  };

  const metrics = calculateAdvancedMetrics();

  // NEW: compute alert count for bell
  const today = new Date();
  const pendingReservationsToday = reservations.filter(r => {
    const d = new Date(r.reservation_date);
    return d.toDateString() === today.toDateString() && r.status === "pending";
  }).length;
  const promotionsExpiringSoon = promotions.filter(p => {
    if (!p.is_active || !p.valid_to) return false;
    const end = new Date(p.valid_to);
    const in7 = new Date(Date.now() + 7*24*60*60*1000); // 7 days from now
    return end >= today && end <= in7;
  }).length;
  const alertCount = metrics.lowStockItems + metrics.activeOrders + pendingReservationsToday + promotionsExpiringSoon;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600 text-lg">Loading your restaurant dashboard...</p>
          {/* NEW: small hint when offline */}
          {isOffline && (
            <p className="text-amber-600 text-sm mt-2">You appear to be offline. Reconnect to load the latest data.</p>
          )}
        </div>
      </div>
    );
  }

  // NEW: graceful error screen if we couldn't load anything
  if (!restaurant && lastError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8 flex items-center justify-center">
        <Card className="w-full max-w-2xl shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              We couldn't load your data
            </CardTitle>
            <p className="text-slate-600">Reason: {lastError}. {isOffline ? "You appear to be offline." : "Please try again."}</p>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Button onClick={() => loadDashboardData(true, activeTab)} className="bg-purple-600 hover:bg-purple-700">Retry</Button>
              <Button variant="outline" onClick={() => window.location.reload()}>Hard Refresh</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8 flex items-center justify-center">
        <Card className="w-full max-w-2xl shadow-xl">
          <CardHeader>
            <CardTitle className="text-3xl text-slate-900">Welcome to Your Restaurant Dashboard</CardTitle>
            <p className="text-slate-600 text-lg">Let's get your restaurant set up and ready for customers.</p>
          </CardHeader>
          <CardContent>
            <RestaurantSettings restaurant={null} onSave={refreshData} />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* NEW: connectivity/error banner */}
      {(isOffline || lastError) && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-800 text-sm px-4 py-2 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>
                {isOffline ? "You're offline. Some data may be unavailable." : "We had trouble loading fresh data. You can retry."}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => loadDashboardData(true, activeTab)} className="bg-white hover:bg-amber-100 text-amber-800 border-amber-300">Retry</Button>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Premium Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-40 backdrop-blur-sm bg-white/95 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              {restaurant.settings?.logo_url ? (
                  <img src={restaurant.settings.logo_url} alt="Logo" className="w-10 h-10 object-contain" />
              ) : (
                <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl flex items-center justify-center shadow-lg" style={{backgroundColor: restaurant.settings?.brand_color}}>
                  <span className="text-white font-bold text-lg">{restaurant.name[0]}</span>
                </div>
              )}
              <div>
                <h1 className="text-xl font-bold text-slate-900">{restaurant.name}</h1>
                <Badge variant="outline" className="text-xs">Live</Badge>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {/* Notifications Bell */}
              <button
                onClick={() => setShowNotifications(true)}
                className="relative w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition"
                aria-label="Open notifications"
                title="Notifications"
              >
                <Bell className="w-5 h-5 text-slate-700" />
                {alertCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-purple-600 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                    {alertCount}
                  </span>
                )}
              </button>

              <Button asChild variant="outline" size="sm" className="hidden md:flex items-center gap-2" style={{borderColor: restaurant.settings?.brand_color, color: restaurant.settings?.brand_color}}>
                  <Link to={createPageUrl(`CustomerMenu?restaurant_id=${restaurant.id}`)} target="_blank">
                    <Eye className="w-4 h-4" />
                    View Live Menu
                  </Link>
              </Button>
              {/* NEW: Copy Menu Link */}
              <Button
                variant="outline"
                size="sm"
                onClick={copyMenuLink}
                className="hidden md:flex items-center gap-2"
              >
                <LinkIcon className="w-4 h-4" />
                {copiedMenuLink ? "Menu Link Copied" : "Copy Menu Link"}
              </Button>
              <Button asChild variant="default" size="sm" className="hidden md:flex items-center gap-2" style={{backgroundColor: restaurant.settings?.brand_color}}>
                 <Link to={createPageUrl(`KDS?restaurant_id=${restaurant.id}`)} target="_blank">
                    <ChefHat className="w-4 h-4" />
                    Kitchen Display
                 </Link>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={copyDashboardLink}
                className="hidden md:flex items-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                {copiedLink ? "Link Copied" : "Share"}
              </Button>
              {lastRefreshed && (
                <div className="hidden md:block text-xs text-slate-500">
                  Updated {lastRefreshed.toLocaleTimeString()}
                </div>
              )}
              <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                 <span className="font-semibold text-slate-600">{(user?.email?.[0] || 'U').toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Enhanced Quick Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-xl hover:shadow-2xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Today's Revenue</p>
                  <p className="text-2xl font-bold">{currency} {metrics.todayRevenue.toFixed(2)}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3 text-blue-200" />
                    <span className="text-xs text-blue-200">+5.2%</span>
                  </div>
                </div>
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-xl hover:shadow-2xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-sm">Gross Profit (Today)</p>
                  <p className="text-2xl font-bold">{currency} {metrics.grossProfit.toFixed(2)}</p>
                   <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3 text-emerald-200" />
                    <span className="text-xs text-emerald-200">vs yesterday</span>
                  </div>
                </div>
                <BarChart3 className="w-8 h-8 text-emerald-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-xl hover:shadow-2xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-amber-100 text-sm">Active Orders</p>
                  <p className="text-2xl font-bold">{metrics.activeOrders}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Clock className="w-3 h-3 text-amber-200" />
                    <span className="text-xs text-amber-200">Real-time</span>
                  </div>
                </div>
                <Clock className="w-8 h-8 text-amber-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-xl hover:shadow-2xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Occupied Tables</p>
                  <p className="text-2xl font-bold">{metrics.occupiedTables}/{tables.length}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <UsersIcon className="w-3 h-3 text-purple-200" />
                    <span className="text-xs text-purple-200">{tables.length > 0 ? Math.round((metrics.occupiedTables/tables.length)*100) : 0}% full</span>
                  </div>
                </div>
                <UsersIcon className="w-8 h-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white p-1 shadow-sm border border-slate-200 rounded-lg flex flex-wrap h-auto">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Overview
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Orders
            </TabsTrigger>
             <TabsTrigger value="financials" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <ClipboardList className="w-4 h-4" /> Financials
            </TabsTrigger>
            <TabsTrigger value="menu" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Menu
            </TabsTrigger>
            <TabsTrigger value="tables" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Tables
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Brain className="w-4 h-4" /> Advanced Analytics
            </TabsTrigger>
            <TabsTrigger value="supply-chain" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Truck className="w-4 h-4" /> Supply Chain
            </TabsTrigger>
            <TabsTrigger value="reservations" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <CalendarIcon className="w-4 h-4" /> Reservations
            </TabsTrigger>
            <TabsTrigger value="customers" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <UsersIcon className="w-4 h-4" /> Customers
            </TabsTrigger>
             <TabsTrigger value="promotions" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <TicketPercent className="w-4 h-4" /> Promotions
            </TabsTrigger>
            {/* NEW Loyalty tab trigger */}
            <TabsTrigger value="loyalty" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Crown className="w-4 h-4" /> Loyalty
            </TabsTrigger>
            <TabsTrigger value="inventory" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Package className="w-4 h-4" /> Inventory
            </TabsTrigger>
            <TabsTrigger value="staff" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4" /> Staff
            </TabsTrigger>
            <TabsTrigger value="locations" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4" /> Locations
            </TabsTrigger>
            <TabsTrigger value="marketing" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2">
              <Mail className="w-4 h-4" /> Marketing
            </TabsTrigger>
            <TabsTrigger value="payments" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Payment Links
            </TabsTrigger>
            <TabsTrigger value="qrcodes" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              QR Generator
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid lg:grid-cols-2 gap-6">
              <DailyBriefing
                restaurant={restaurant}
                orders={orders}
                onRefresh={refreshData}
              />
              <RestaurantOverview 
                restaurant={restaurant}
                orders={orders}
                menuItems={menuItems}
                tables={tables}
                customers={customers}
                refreshData={refreshData}
              />
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <OrderManagement 
              restaurant={restaurant}
              orders={orders}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="financials">
            <FinancialReporting 
              restaurant={restaurant}
              orders={orders}
              purchaseOrders={purchaseOrders}
            />
          </TabsContent>
          
          <TabsContent value="menu">
            <MenuManagement 
              restaurant={restaurant}
              menuItems={menuItems}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="tables">
            <TableManagement 
              restaurant={restaurant}
              tables={tables}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="analytics">
            <AdvancedAnalytics 
              restaurant={restaurant}
              orders={orders}
              customers={customers}
            />
          </TabsContent>

          <TabsContent value="supply-chain">
            <SupplyChainManagement
              restaurant={restaurant}
              inventory={inventory}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="reservations">
            <ReservationManagement
              restaurant={restaurant}
              tables={tables}
              refreshData={refreshData}
            />
          </TabsContent>

           <TabsContent value="customers">
            <CustomerManagement 
              restaurant={restaurant}
              customers={customers}
              promotions={promotions}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="promotions">
            <PromotionManagement
              restaurant={restaurant}
              promotions={promotions}
              refreshData={refreshData}
            />
          </TabsContent>

          {/* NEW Loyalty content */}
          <TabsContent value="loyalty">
            <div className="space-y-6">
              <LoyaltyProgramSettings
                restaurant={restaurant}
                program={loyaltyProgram}
                onSaved={refreshData}
              />
              <LoyaltyMembers
                restaurant={restaurant}
                program={loyaltyProgram}
                members={loyaltyMembers}
                customers={customers}
                onChanged={refreshData}
              />
            </div>
          </TabsContent>

          <TabsContent value="inventory">
            <InventoryManagement
              restaurant={restaurant}
              inventory={inventory}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="staff">
            <StaffManagement
              restaurant={restaurant}
              staff={staff}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="locations">
            <LocationManagement
              restaurant={restaurant}
              locations={locations}
              refreshData={refreshData}
            />
          </TabsContent>

          <TabsContent value="marketing">
            <EmailMarketing
              restaurant={restaurant}
              customers={customers}
            />
          </TabsContent>

          <TabsContent value="payments">
            <PaymentLinksManager restaurant={restaurant} />
          </TabsContent>

          <TabsContent value="qrcodes">
            <QRCodeGenerator 
              restaurant={restaurant}
              tables={tables}
              defaultSelectedTable={preselectedTableId}
            />
          </TabsContent>

          <TabsContent value="settings">
            <RestaurantSettings 
              restaurant={restaurant}
              onSave={refreshData}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Notifications Center Sheet */}
      <NotificationsCenter
        open={showNotifications}
        onOpenChange={setShowNotifications}
        restaurant={restaurant}
        orders={orders}
        inventory={inventory}
        reservations={reservations}
        promotions={promotions}
        purchaseOrders={purchaseOrders}
        staff={staff}
      />
    </div>
  );
}
