
import React, { useState, useEffect, useCallback } from "react";
import { Order, MenuItem, CustomerFeedback } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { addDays, format, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import { 
  DollarSign,
  ShoppingCart,
  Users,
  Star,
  Download,
  Calendar as CalendarIcon
} from "lucide-react";

import AnalyticsMetricCard from "../components/analytics/AnalyticsMetricCard";
import RevenueChart from "../components/analytics/RevenueChart";
import PopularItemsChart from "../components/analytics/PopularItemsChart";
import PeakHoursChart from "../components/analytics/PeakHoursChart";
import FeedbackSummary from "../components/analytics/FeedbackSummary";

export default function RestaurantAnalyticsPage({ restaurant }) {
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    from: startOfWeek(new Date()),
    to: endOfWeek(new Date()),
  });

  const loadAnalyticsData = useCallback(async () => {
    if (!restaurant) return;
    setIsLoading(true);
    try {
      const [orderData, menuData, feedbackData] = await Promise.all([
        Order.filter({ restaurant_id: restaurant.id, status: 'paid' }, '-created_date', 500),
        MenuItem.filter({ restaurant_id: restaurant.id }),
        CustomerFeedback.filter({ restaurant_id: restaurant.id }, '-created_date', 200)
      ]);
      setOrders(orderData);
      setMenuItems(menuData);
      setFeedback(feedbackData);
    } catch (error) {
      console.error("Error loading analytics data:", error);
    }
    setIsLoading(false);
  }, [restaurant]); // Dependency: restaurant

  useEffect(() => {
    loadAnalyticsData();
  }, [loadAnalyticsData]); // Dependency: loadAnalyticsData

  const filteredOrders = orders.filter(order => {
    const orderDate = new Date(order.created_date);
    return orderDate >= dateRange.from && orderDate <= dateRange.to;
  });

  const filteredFeedback = feedback.filter(fb => {
    const feedbackDate = new Date(fb.created_date);
    return feedbackDate >= dateRange.from && feedbackDate <= dateRange.to;
  });

  const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.total, 0);
  const totalOrders = filteredOrders.length;
  const uniqueCustomers = new Set(filteredOrders.map(o => o.customer_name)).size;
  const averageRating = filteredFeedback.length > 0 
    ? filteredFeedback.reduce((sum, fb) => sum + fb.rating, 0) / filteredFeedback.length
    : 0;

  return (
    <div className="space-y-8">
      {/* Header & Date Picker */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Analytics & Reports</h2>
          <p className="text-slate-600 text-lg">Insights into your restaurant's performance</p>
        </div>
        <div className="flex items-center gap-3">
          <DateRangePicker 
            date={dateRange} 
            onDateChange={setDateRange}
            presets={[
              { label: 'Today', value: { from: new Date(), to: new Date() } },
              { label: 'Last 7 Days', value: { from: addDays(new Date(), -6), to: new Date() } },
              { label: 'This Week', value: { from: startOfWeek(new Date()), to: endOfWeek(new Date()) } },
              { label: 'This Month', value: { from: startOfMonth(new Date()), to: endOfMonth(new Date()) } },
            ]}
          />
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnalyticsMetricCard
          title="Total Revenue"
          value={`AED ${totalRevenue.toFixed(2)}`}
          icon={DollarSign}
          color="emerald"
          change="+5.2%"
        />
        <AnalyticsMetricCard
          title="Total Orders"
          value={totalOrders}
          icon={ShoppingCart}
          color="blue"
          change="+12"
        />
        <AnalyticsMetricCard
          title="Unique Customers"
          value={uniqueCustomers}
          icon={Users}
          color="purple"
          change="+8"
        />
        <AnalyticsMetricCard
          title="Average Rating"
          value={`${averageRating.toFixed(1)} / 5`}
          icon={Star}
          color="amber"
          change="-0.1"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3">
          <RevenueChart orders={filteredOrders} />
        </div>
        <div className="lg:col-span-2">
          <PopularItemsChart orders={filteredOrders} menuItems={menuItems} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3">
          <PeakHoursChart orders={filteredOrders} />
        </div>
        <div className="lg:col-span-2">
          <FeedbackSummary feedback={filteredFeedback} />
        </div>
      </div>
    </div>
  );
}
