import { base44 } from './base44Client';


export const ProductModule = base44.entities.ProductModule;

export const PricingStructure = base44.entities.PricingStructure;

export const CompetitiveAnalysis = base44.entities.CompetitiveAnalysis;

export const IntegrationRequirement = base44.entities.IntegrationRequirement;

export const Restaurant = base44.entities.Restaurant;

export const MenuItem = base44.entities.MenuItem;

export const Table = base44.entities.Table;

export const Order = base44.entities.Order;

export const Payment = base44.entities.Payment;

export const CustomerFeedback = base44.entities.CustomerFeedback;

export const Customer = base44.entities.Customer;

export const Promotion = base44.entities.Promotion;

export const InventoryItem = base44.entities.InventoryItem;

export const Staff = base44.entities.Staff;

export const StockTransaction = base44.entities.StockTransaction;

export const Location = base44.entities.Location;

export const LoyaltyProgram = base44.entities.LoyaltyProgram;

export const CustomerLoyalty = base44.entities.CustomerLoyalty;

export const Supplier = base44.entities.Supplier;

export const PurchaseOrder = base44.entities.PurchaseOrder;

export const Reservation = base44.entities.Reservation;

export const EmailCampaign = base44.entities.EmailCampaign;

export const FinancialReport = base44.entities.FinancialReport;

export const PaymentLink = base44.entities.PaymentLink;



// auth sdk:
export const User = base44.auth;