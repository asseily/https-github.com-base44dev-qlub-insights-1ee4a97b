import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68cfa2f74a4a078c1ee4a97b", 
  requiresAuth: true // Ensure authentication is required for all operations
});
